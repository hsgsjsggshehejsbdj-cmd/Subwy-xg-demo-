// enemies.js — Smart Cover-Seeking Tactical Enemy & Allied Squad AI with Skeletal GLB Animations
import * as THREE from 'three';
import * as SkeletonUtils from './lib/SkeletonUtils.js';

const DIFFICULTY_PRESETS = {
  RECRUIT: { hpMult: 0.85, dmgMult: 0.65, accuracy: 0.55, reactionTime: 0.65 },
  VETERAN: { hpMult: 1.0,  dmgMult: 1.0,  accuracy: 0.76, reactionTime: 0.38 },
  ELITE:   { hpMult: 1.28, dmgMult: 1.32, accuracy: 0.90, reactionTime: 0.20 },
};

export class SoldierAgent {
  constructor({ id, team = 'enemy', role = 'rifleman', pos, assets, scene, difficulty = 'VETERAN' }) {
    this.id = id;
    this.team = team; // 'enemy' | 'ally'
    this.role = role; // 'rifleman' | 'sniper' | 'heavy' | 'rpg'
    this.diff = DIFFICULTY_PRESETS[difficulty] || DIFFICULTY_PRESETS.VETERAN;

    this.position = pos.clone();
    this.spawnOrigin = pos.clone();
    this.velocity = new THREE.Vector3();
    this.yaw = team === 'enemy' ? 0 : Math.PI;

    const baseHp = role === 'heavy' ? 165 : role === 'sniper' ? 85 : 105;
    this.maxHp = Math.round(baseHp * (team === 'enemy' ? this.diff.hpMult : 1.15));
    this.hp = this.maxHp;
    this.dead = false;
    this.deathCleanupTimer = 9.0;

    // AI Tactical State Machine
    this.state = 'PATROL'; // 'PATROL' | 'INVESTIGATE' | 'SEEK_COVER' | 'COMBAT' | 'CROUCH_COVER'
    this.alerted = team === 'ally';
    this.stationary = role === 'sniper';
    this.patrolTarget = pos.clone();
    this.coverTarget = null;
    this.investigatePos = null;
    this.stateTimer = Math.random() * 2.0;
    this.fireCooldown = 0.6 + Math.random() * 0.8;
    this.burstRemaining = 0;
    this.ammoInMag = role === 'heavy' ? 45 : role === 'sniper' ? 5 : 24;
    this.reloadTimer = 0;
    this.hitStaggerTimer = 0;
    this.aiTickTimer = Math.random() * 0.2;

    // Instantiate Skinned 3D Soldier GLB
    const gltfKey = team === 'ally' ? 'soldier_ally' : 'soldier_enemy';
    const gltf = assets.models.get(gltfKey);
    this.root = gltf ? SkeletonUtils.clone(gltf.scene) : new THREE.Group();
    this.root.position.copy(this.position);
    this.root.traverse((c) => {
      if (c.isMesh) {
        c.castShadow = true;
        c.receiveShadow = true;
      }
    });

    // Overhead subtle tactical diamond for Allies (cyan) or Alerted Sniper Glint (red)
    if (team === 'ally') {
      const tag = new THREE.Mesh(
        new THREE.OctahedronGeometry(0.11, 0),
        new THREE.MeshBasicMaterial({ color: 0x38bdf8 })
      );
      tag.position.set(0, 2.02, 0);
      this.root.add(tag);
    } else if (role === 'sniper') {
      this.glintSprite = new THREE.Mesh(
        new THREE.SphereGeometry(0.075, 6, 6),
        new THREE.MeshBasicMaterial({ color: 0xff2a2a })
      );
      this.glintSprite.position.set(-0.04, 1.56, 0.35);
      this.root.add(this.glintSprite);
    }

    scene.add(this.root);

    // Skeletal Animations
    this.mixer = null;
    this.actions = {};
    this.currentAnim = '';
    if (gltf && gltf.animations && gltf.animations.length > 0) {
      this.mixer = new THREE.AnimationMixer(this.root);
      for (const clip of gltf.animations) {
        const act = this.mixer.clipAction(clip);
        if (['Shoot', 'Reload', 'Hit', 'Death'].includes(clip.name)) {
          act.setLoop(THREE.LoopOnce, 1);
          act.clampWhenFinished = clip.name === 'Death';
        }
        this.actions[clip.name] = act;
      }
      this.playAnim('Idle');
    }
  }

  playAnim(name, force = false) {
    if (!this.mixer || !this.actions[name]) return;
    if (this.currentAnim === name && !force) return;
    const next = this.actions[name];
    const prev = this.actions[this.currentAnim];
    if (prev && prev !== next) prev.fadeOut(0.15);
    next.reset().fadeIn(0.15).play();
    this.currentAnim = name;
  }
}

export class AIManager {
  constructor(scene, assets, audio, world) {
    this.scene = scene;
    this.assets = assets;
    this.audio = audio;
    this.world = world;

    this.difficulty = 'VETERAN';
    this.enemies = [];
    this.allies = [];
    this._nextId = 1;
    this._radioCallCooldown = 0;

    this.onEnemyKilled = null;
    this.onAllyKilled = null;
  }

  setDifficulty(diff) {
    if (DIFFICULTY_PRESETS[diff]) this.difficulty = diff;
  }

  clearAll() {
    for (const s of [...this.enemies, ...this.allies]) {
      this.scene.remove(s.root);
    }
    this.enemies = [];
    this.allies = [];
  }

  spawnEnemy({ x, z, y = null, role = 'rifleman' }) {
    const fy = y !== null ? y : this.world.getFloorHeightAt(x, z, 10);
    const agent = new SoldierAgent({
      id: this._nextId++,
      team: 'enemy',
      role,
      pos: new THREE.Vector3(x, fy, z),
      assets: this.assets,
      scene: this.scene,
      difficulty: this.difficulty,
    });
    this.enemies.push(agent);
    return agent;
  }

  spawnAlly({ x, z, role = 'rifleman' }) {
    const fy = this.world.getFloorHeightAt(x, z, 10);
    const agent = new SoldierAgent({
      id: this._nextId++,
      team: 'ally',
      role,
      pos: new THREE.Vector3(x, fy, z),
      assets: this.assets,
      scene: this.scene,
      difficulty: this.difficulty,
    });
    this.allies.push(agent);
    return agent;
  }

  get aliveEnemyCount() {
    let n = 0;
    for (const e of this.enemies) if (!e.dead) n++;
    return n;
  }

  /** Acoustic sound perception — gunshots & explosions alert nearby enemies! */
  notifySound(soundPos, radius = 75) {
    const rSq = radius * radius;
    for (const e of this.enemies) {
      if (e.dead) continue;
      if (e.position.distanceToSquared(soundPos) <= rSq) {
        e.alerted = true;
        e.investigatePos = soundPos.clone();
        if (e.state === 'PATROL') {
          e.state = e.stationary ? 'COMBAT' : 'INVESTIGATE';
        }
      }
    }
  }

  alertSquadNear(originPos, targetPos, radius = 36) {
    const rSq = radius * radius;
    if (this._radioCallCooldown <= 0) {
      this._radioCallCooldown = 7.5;
      this.audio.playSpatial('radio_chatter', originPos, { volume: 0.55, refDist: 14, maxDist: 95 });
    }
    for (const e of this.enemies) {
      if (e.dead) continue;
      if (e.position.distanceToSquared(originPos) <= rSq) {
        e.alerted = true;
        e.investigatePos = targetPos.clone();
        if (e.state === 'PATROL') e.state = e.stationary ? 'COMBAT' : 'SEEK_COVER';
      }
    }
  }

  /** Fast ray-vs-capsule + headshot sphere intersection against all living enemies */
  raycastEnemies(origin, dir, maxDist = 300) {
    let closest = null;
    let bestT = maxDist;
    const hitPt = new THREE.Vector3();

    for (let i = 0; i < this.enemies.length; i++) {
      const e = this.enemies[i];
      if (e.dead) continue;

      const crouchOffset = e.state === 'CROUCH_COVER' ? -0.38 : 0;
      const bodyHeight = 1.78 + crouchOffset;

      // Project enemy center onto ray
      const toCenterX = e.position.x - origin.x;
      const toCenterZ = e.position.z - origin.z;
      const tProj = toCenterX * dir.x + (e.position.y + 0.9 - origin.y) * dir.y + toCenterZ * dir.z;
      if (tProj < 0.2 || tProj > bestT) continue;

      const px = origin.x + dir.x * tProj;
      const py = origin.y + dir.y * tProj;
      const pz = origin.z + dir.z * tProj;

      if (py < e.position.y - 0.05 || py > e.position.y + bodyHeight + 0.12) continue;

      const dx = px - e.position.x;
      const dz = pz - e.position.z;
      const horizDistSq = dx * dx + dz * dz;
      const hitRadius = 0.44;
      if (horizDistSq <= hitRadius * hitRadius) {
        bestT = tProj;
        const headThreshold = e.position.y + (e.state === 'CROUCH_COVER' ? 1.05 : 1.44);
        const isHeadshot = py >= headThreshold;
        hitPt.set(px, py, pz);
        closest = {
          enemy: this._wrapDamageable(e),
          distance: tProj,
          point: hitPt.clone(),
          isHeadshot,
        };
      }
    }
    return closest;
  }

  _wrapDamageable(agent) {
    return {
      agent,
      takeDamage: (dmg, attackerPos, isHeadshot = false) =>
        this.damageSoldier(agent, dmg, attackerPos, isHeadshot),
    };
  }

  damageSoldier(agent, dmg, attackerPos = null, isHeadshot = false) {
    if (agent.dead) return false;
    agent.hp -= dmg;
    agent.alerted = true;
    if (attackerPos) {
      agent.investigatePos = attackerPos.clone();
      if (agent.team === 'enemy') this.alertSquadNear(agent.position, attackerPos, 34);
    }

    if (agent.hp <= 0) {
      agent.hp = 0;
      agent.dead = true;
      agent.playAnim('Death', true);
      if (agent.glintSprite) agent.glintSprite.visible = false;
      if (agent.team === 'enemy' && this.onEnemyKilled) {
        this.onEnemyKilled(agent, isHeadshot);
      } else if (agent.team === 'ally' && this.onAllyKilled) {
        this.onAllyKilled(agent);
      }
      return true;
    }

    // Stagger & seek cover if wounded!
    agent.hitStaggerTimer = 0.25;
    agent.playAnim('Hit', true);
    if (!agent.stationary && agent.state !== 'SEEK_COVER') {
      agent.state = 'SEEK_COVER';
      agent.stateTimer = 2.4;
    }
    return false;
  }

  applyExplosionDamage(center, radius, maxDamage, creditedToPlayer = true) {
    let enemyKills = 0;
    for (const e of this.enemies) {
      if (e.dead) continue;
      const d = e.position.distanceTo(center);
      if (d <= radius) {
        const dmg = maxDamage * (1.0 - (d / radius) * 0.75);
        // Knockback away from blast
        const push = e.position.clone().sub(center).setY(0).normalize().multiplyScalar(2.4);
        e.position.add(push);
        if (this.damageSoldier(e, dmg, center, false) && creditedToPlayer) {
          enemyKills++;
        }
      }
    }
    return enemyKills;
  }

  update(dt, player) {
    if (this._radioCallCooldown > 0) this._radioCallCooldown -= dt;
    if (!player) return;

    // Update Enemies
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];
      if (e.dead) {
        if (e.mixer) e.mixer.update(dt);
        e.deathCleanupTimer -= dt;
        if (e.deathCleanupTimer <= 0) {
          this.scene.remove(e.root);
          this.enemies.splice(i, 1);
        }
        continue;
      }
      this._updateAgent(e, dt, player);
    }

    // Update Friendly Squadmates
    for (let i = this.allies.length - 1; i >= 0; i--) {
      const a = this.allies[i];
      if (a.dead) {
        if (a.mixer) a.mixer.update(dt);
        a.deathCleanupTimer -= dt;
        if (a.deathCleanupTimer <= 0) {
          this.scene.remove(a.root);
          this.allies.splice(i, 1);
        }
        continue;
      }
      this._updateAlly(a, dt, player);
    }
  }

  _updateAgent(e, dt, player) {
    const distToPlayer = e.position.distanceTo(player.position);

    // Distance-based animation & AI throttling for smooth mobile 60 FPS
    if (e.mixer && distToPlayer < 135) {
      e.mixer.update(dt);
    }

    if (e.hitStaggerTimer > 0) {
      e.hitStaggerTimer -= dt;
      return;
    }

    if (e.reloadTimer > 0) {
      e.reloadTimer -= dt;
      if (e.reloadTimer <= 0) {
        e.ammoInMag = e.role === 'heavy' ? 45 : e.role === 'sniper' ? 5 : 24;
      }
      return;
    }

    // Pick closest target (Player or nearby Allied Soldier)
    let targetPos = player.position;
    let targetIsPlayer = true;
    let bestTargetDist = player.dead ? Infinity : distToPlayer;

    for (const ally of this.allies) {
      if (ally.dead) continue;
      const d = e.position.distanceTo(ally.position);
      if (d < bestTargetDist * 0.85) {
        bestTargetDist = d;
        targetPos = ally.position;
        targetIsPlayer = false;
      }
    }

    const sightRange = e.role === 'sniper' ? 145 : 85;
    e.aiTickTimer -= dt;
    if (e.aiTickTimer <= 0) {
      e.aiTickTimer = distToPlayer > 75 ? 0.32 : 0.14;
      if (bestTargetDist < sightRange) {
        const eyeA = { x: e.position.x, y: e.position.y + 1.45, z: e.position.z };
        const eyeB = { x: targetPos.x, y: targetPos.y + 1.25, z: targetPos.z };
        e.canSeeTarget = this.world.hasLineOfSight(eyeA, eyeB);
        if (e.canSeeTarget && !e.alerted) {
          e.alerted = true;
          this.alertSquadNear(e.position, targetPos, 32);
          e.state = e.stationary ? 'COMBAT' : 'SEEK_COVER';
          e.stateTimer = 2.0;
        }
      } else {
        e.canSeeTarget = false;
      }
    }

    e.stateTimer -= dt;
    let moveGoal = null;
    let moveSpeed = 0;

    if (!e.alerted) {
      // PATROL
      if (e.stationary) {
        e.playAnim('Idle');
      } else {
        if (e.stateTimer <= 0 || e.position.distanceTo(e.patrolTarget) < 1.2) {
          e.stateTimer = 3.5 + Math.random() * 3.0;
          e.patrolTarget.set(
            e.spawnOrigin.x + (Math.random() - 0.5) * 14,
            e.spawnOrigin.y,
            e.spawnOrigin.z + (Math.random() - 0.5) * 14
          );
        }
        moveGoal = e.patrolTarget;
        moveSpeed = 2.1;
      }
    } else if (e.stationary) {
      // Sniper / Tower Guard holds high-ground perch
      e.state = 'COMBAT';
    } else if (e.state === 'SEEK_COVER') {
      if (!e.coverTarget) {
        e.coverTarget = this.world.findNearestCover(e.position, targetPos, 24);
      }
      if (e.coverTarget && e.position.distanceTo(e.coverTarget) > 1.05 && e.stateTimer > -2.5) {
        moveGoal = e.coverTarget;
        moveSpeed = 4.9;
      } else {
        e.state = 'CROUCH_COVER';
        e.stateTimer = 1.2 + Math.random() * 1.1;
        e.coverTarget = null;
      }
    } else if (e.state === 'CROUCH_COVER') {
      e.playAnim('Crouch');
      if (e.stateTimer <= 0) {
        e.state = 'COMBAT';
        e.stateTimer = 2.4 + Math.random() * 1.6;
      }
    } else if (e.state === 'INVESTIGATE') {
      if (e.canSeeTarget) {
        e.state = 'COMBAT';
        e.stateTimer = 2.5;
      } else if (e.investigatePos && e.position.distanceTo(e.investigatePos) > 4.5) {
        moveGoal = e.investigatePos;
        moveSpeed = 3.6;
      } else {
        e.state = 'COMBAT';
        e.stateTimer = 2.0;
      }
    } else {
      // COMBAT: Strafe / Flank or Advance into effective weapon range
      if (!e.canSeeTarget && bestTargetDist > 14) {
        moveGoal = targetPos;
        moveSpeed = 3.8;
      } else if (bestTargetDist > 42) {
        moveGoal = targetPos;
        moveSpeed = 3.4;
      } else if (e.stateTimer <= 0) {
        e.state = Math.random() < 0.55 ? 'SEEK_COVER' : 'COMBAT';
        e.stateTimer = 2.2 + Math.random() * 1.5;
      }
    }

    // Apply Locomotion
    if (moveGoal && moveSpeed > 0.1) {
      const dx = moveGoal.x - e.position.x;
      const dz = moveGoal.z - e.position.z;
      const len = Math.hypot(dx, dz) || 1;
      e.position.x += (dx / len) * moveSpeed * dt;
      e.position.z += (dz / len) * moveSpeed * dt;
      this.world.resolveHorizontalCollision(e.position, 0.42, e.position.y, 1.7);
      e.position.y = this.world.getFloorHeightAt(e.position.x, e.position.z, e.position.y);
      e.yaw = Math.atan2(dx, dz);
      e.playAnim(moveSpeed > 4.0 ? 'Run' : 'Walk');
    } else if (e.alerted) {
      // Face target
      const dx = targetPos.x - e.position.x;
      const dz = targetPos.z - e.position.z;
      e.yaw = Math.atan2(dx, dz);
      if (e.state !== 'CROUCH_COVER' && e.currentAnim !== 'Shoot') {
        e.playAnim('Idle');
      }
    }

    e.root.position.copy(e.position);
    e.root.rotation.y = e.yaw;

    // Firing bursts when target is in line-of-sight!
    if (e.alerted && e.canSeeTarget && e.state !== 'CROUCH_COVER' && bestTargetDist < sightRange) {
      e.fireCooldown -= dt;
      if (e.fireCooldown <= 0) {
        this._fireAgentWeapon(e, targetPos, targetIsPlayer ? player : null);
      }
    }
  }

  _updateAlly(a, dt, player) {
    if (a.mixer) a.mixer.update(dt);
    if (a.reloadTimer > 0) {
      a.reloadTimer -= dt;
      if (a.reloadTimer <= 0) a.ammoInMag = 30;
      return;
    }

    // Find closest living enemy within 80m
    let nearestEnemy = null;
    let bestD = 80;
    for (const e of this.enemies) {
      if (e.dead) continue;
      const d = a.position.distanceTo(e.position);
      if (d < bestD) {
        bestD = d;
        nearestEnemy = e;
      }
    }

    // Follow player squad formation when out of combat or too far behind player
    const distPlayer = a.position.distanceTo(player.position);
    if (distPlayer > 16 || (!nearestEnemy && distPlayer > 7.5)) {
      const offsetAngle = (a.id % 3 - 1) * 0.65;
      const goalX = player.position.x + Math.sin(player.yaw + offsetAngle) * 5.5;
      const goalZ = player.position.z + Math.cos(player.yaw + offsetAngle) * 5.5;
      const dx = goalX - a.position.x;
      const dz = goalZ - a.position.z;
      const len = Math.hypot(dx, dz) || 1;
      const spd = distPlayer > 20 ? 5.6 : 3.8;
      a.position.x += (dx / len) * spd * dt;
      a.position.z += (dz / len) * spd * dt;
      this.world.resolveHorizontalCollision(a.position, 0.42, a.position.y, 1.7);
      a.position.y = this.world.getFloorHeightAt(a.position.x, a.position.z, a.position.y);
      a.yaw = Math.atan2(dx, dz);
      a.playAnim(spd > 4.5 ? 'Run' : 'Walk');
    } else if (nearestEnemy) {
      const dx = nearestEnemy.position.x - a.position.x;
      const dz = nearestEnemy.position.z - a.position.z;
      a.yaw = Math.atan2(dx, dz);
      a.fireCooldown -= dt;
      if (a.fireCooldown <= 0) {
        a.fireCooldown = 0.35 + Math.random() * 0.45;
        const eyeA = { x: a.position.x, y: a.position.y + 1.4, z: a.position.z };
        const eyeE = { x: nearestEnemy.position.x, y: nearestEnemy.position.y + 1.2, z: nearestEnemy.position.z };
        if (this.world.hasLineOfSight(eyeA, eyeE)) {
          a.playAnim('Shoot', true);
          const muz = a.position.clone().add(new THREE.Vector3(0, 1.3, 0));
          const end = nearestEnemy.position.clone().add(new THREE.Vector3(0, 1.15, 0));
          this.world.spawnTracer(muz, end, 0x7dd3fc);
          this.audio.playSpatial('rifle_shot', muz, { volume: 0.45, refDist: 10 });
          if (Math.random() < 0.48) {
            this.damageSoldier(nearestEnemy, 18, a.position, false);
          }
        }
      } else if (a.currentAnim !== 'Shoot') {
        a.playAnim('Idle');
      }
    } else {
      a.playAnim('Idle');
    }

    a.root.position.copy(a.position);
    a.root.rotation.y = a.yaw;
  }

  _fireAgentWeapon(e, targetPos, playerRef) {
    e.ammoInMag--;
    if (e.ammoInMag <= 0) {
      e.reloadTimer = 1.65;
      e.playAnim('Reload', true);
      return;
    }

    if (e.role === 'sniper') {
      e.fireCooldown = 2.4 + Math.random() * 0.9;
    } else if (e.role === 'rpg') {
      e.fireCooldown = 4.2 + Math.random() * 1.2;
    } else if (e.burstRemaining > 0) {
      e.burstRemaining--;
      e.fireCooldown = 0.13;
    } else {
      e.burstRemaining = e.role === 'heavy' ? 5 : 2;
      e.fireCooldown = 0.85 + Math.random() * 0.65;
    }

    e.playAnim('Shoot', true);
    const muzzle = e.position.clone().add(new THREE.Vector3(0, 1.32, 0));
    const soundKey = e.role === 'sniper' ? 'sniper_shot' : e.role === 'rpg' ? 'rpg_launch' : 'rifle_shot';
    this.audio.playSpatial(soundKey, muzzle, { volume: 0.72, refDist: 16, maxDist: 240 });

    const dist = muzzle.distanceTo(targetPos);
    const spread = (1.0 - e.diff.accuracy) * 0.12 * Math.min(2.0, dist / 28);
    const aimPoint = targetPos.clone().add(
      new THREE.Vector3(
        (Math.random() - 0.5) * spread * dist,
        1.05 + (Math.random() - 0.5) * spread * dist,
        (Math.random() - 0.5) * spread * dist
      )
    );

    this.world.spawnTracer(muzzle, aimPoint, 0xff6b4a);

    if (playerRef && !playerRef.dead) {
      const missDist = aimPoint.distanceTo(
        new THREE.Vector3(playerRef.position.x, playerRef.position.y + 1.0, playerRef.position.z)
      );
      if (missDist < 0.78) {
        const baseDmg = e.role === 'sniper' ? 24 : e.role === 'rpg' ? 32 : 8.5;
        playerRef.takeDamage(baseDmg * e.diff.dmgMult, e.position);
      } else if (missDist < 2.6) {
        // Bullet supersonic whiz past player's head!
        this.audio.playSpatial('bullet_whiz', aimPoint, { volume: 0.45, refDist: 4 });
      }
    }
  }
}
