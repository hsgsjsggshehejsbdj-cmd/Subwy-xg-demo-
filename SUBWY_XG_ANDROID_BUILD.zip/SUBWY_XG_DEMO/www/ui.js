// ui.js — Bilingual (AR/EN) Main Menu, 3D Armory Inspector, Tactical Radar HUD, Optics & Settings
import * as THREE from 'three';
import { CAMPAIGN_MISSIONS } from './missions.js';
import { WEAPON_CATALOG } from './weapons.js';
import { SOLDIER_OPERATORS } from './player.js';
import { VEHICLE_CATALOG } from './vehicles.js';

const I18N = {
  en: {
    menu_subtitle: 'AAA 3D TACTICAL WARFARE // FPS & TPS',
    btn_play: 'PLAY',
    btn_play_sub: 'INSTANT COMBAT DEPLOYMENT',
    btn_campaign: 'CAMPAIGN',
    btn_campaign_sub: '3 WAR STORY OPERATIONS',
    btn_loadout: 'LOADOUT',
    btn_loadout_sub: '3D WEAPON ARMORY (6)',
    btn_soldiers: 'SOLDIERS',
    btn_soldiers_sub: 'OPERATORS & 3D RIGS',
    btn_vehicles: 'VEHICLES',
    btn_vehicles_sub: 'TANKS, JEEPS & AIRCRAFT',
    btn_settings: 'SETTINGS',
    btn_settings_sub: 'LOW/MED/HIGH, AUDIO & TOUCH',
    btn_exit: 'EXIT',
    btn_exit_sub: 'SAVE & STANDBY',
    live_warzone: 'LIVE 3D BATTLEFIELD FEED',
    menu_intel_desc:
      'Dual FPS & TPS war simulation featuring explorable destroyed city buildings, drivable M1A3 Abrams battle tanks, smart cover AI, and 3D spatial audio.',
    controls_quick_hint:
      'Android/iOS: Left Stick + Touch Aim + FPS/TPS | Windows: WASD + Mouse + V (FPS/TPS) + R/C/Space/F',
    back: 'BACK',
    skip_intro: 'SKIP INTRO ⏭',
    veh_exit_hint: '[F / INTERACT] EXIT VEHICLE • FIRE: CANNON / MG',
    sprint: '▲ SPRINT',
    drag_buttons_hint: 'DRAG ANY TOUCH BUTTON TO REPOSITION',
    reset: 'RESET',
    save: 'SAVE LAYOUT',
    game_paused: 'TACTICAL PAUSE',
    resume: 'RESUME COMBAT',
    customize_touch: 'CUSTOMIZE TOUCH CONTROLS',
    restart_mission: 'RESTART MISSION',
    quit_menu: 'MAIN MENU',
    stat_kills: 'HOSTILES ELIMINATED',
    stat_headshots: 'HEADSHOTS',
    stat_vehicles: 'ARMOR DESTROYED',
    stat_time: 'OPERATION TIME',
    next_mission: 'NEXT MISSION →',
    retry: 'REPLAY',
    rotate_title: 'ROTATE DEVICE TO LANDSCAPE',
    rotate_desc: 'Rotate your phone horizontally for the optimal tactical HUD layout.',
    continue_anyway: 'CONTINUE',
    exit_title: 'EXIT OPERATION?',
    exit_desc: 'Progress, graphics & loadout settings are saved on this device.',
    exit_confirm: 'ENTER STANDBY MODE',
    cancel: 'RETURN TO MENU',
  },
  ar: {
    menu_subtitle: 'لعبة حرب ثلاثية الأبعاد واقعية // منظور أول وثالث',
    btn_play: 'ابدأ اللعب (PLAY)',
    btn_play_sub: 'انتشار قتالي فوري في الميدان',
    btn_campaign: 'طور القصة (CAMPAIGN)',
    btn_campaign_sub: '3 مهمات حربية سينمائية',
    btn_loadout: 'العتاد والأسلحة (LOADOUT)',
    btn_loadout_sub: 'ترسانة أسلحة ثلاثية الأبعاد (6)',
    btn_soldiers: 'الجنود (SOLDIERS)',
    btn_soldiers_sub: 'الشخصيات والتجهيزات القتالية',
    btn_vehicles: 'المركبات والدبابات (VEHICLES)',
    btn_vehicles_sub: 'دبابات، مدرعات، طائرات ومروحيات',
    btn_settings: 'الإعدادات (SETTINGS)',
    btn_settings_sub: 'الرسومات، الصوت، والتحكم باللمس',
    btn_exit: 'خروج (EXIT)',
    btn_exit_sub: 'حفظ البيانات وإيقاف المحرك',
    live_warzone: 'بث حي من ساحة المعركة ثلاثية الأبعاد',
    menu_intel_desc:
      'منظور مزدوج (FPS و TPS) مع مدينة مدمرة قابلة للاستكشاف، دبابات أبرامز قابلة للقيادة، ذكاء اصطناعي يحتمي بالسواتر، وصوت مكاني ثلاثي الأبعاد.',
    controls_quick_hint:
      'الهاتف: عصا يسارية + تصويب باللمس + زر المنظور | الكمبيوتر: WASD + الماوس + V لتبديل المنظور + F للمركبات',
    back: 'رجوع',
    skip_intro: 'تخطي المقدمة ⏭',
    veh_exit_hint: '[F / زر التفاعل] للنزول من المركبة • إطلاق: المدفع الرئيسي',
    sprint: '▲ ركض سريع',
    drag_buttons_hint: 'اسحب أي زر تحكم لتغيير موقعه على الشاشة',
    reset: 'استعادة الافتراضي',
    save: 'حفظ المواقع',
    game_paused: 'إيقاف مؤقت',
    resume: 'استئناف القتال',
    customize_touch: 'تخصيص أزرار الهاتف',
    restart_mission: 'إعادة المهمة',
    quit_menu: 'القائمة الرئيسية',
    stat_kills: 'الأعداء المقضي عليهم',
    stat_headshots: 'إصابات الرأس (Headshots)',
    stat_vehicles: 'المدرعات المدمرة',
    stat_time: 'زمن العملية',
    next_mission: 'المهمة التالية ←',
    retry: 'إعادة اللعب',
    rotate_title: 'يرجى تدوير الهاتف للوضع الأفقي',
    rotate_desc: 'تم تصميم واجهة اللعب للوضع الأفقي Landscape لأفضل تحكم.',
    continue_anyway: 'متابعة على أي حال',
    exit_title: 'الخروج من اللعبة؟',
    exit_desc: 'تم حفظ إعدادات الرسومات والأسلحة تلقائياً على جهازك.',
    exit_confirm: 'إيقاف المحرك (وضع الاستعداد)',
    cancel: 'العودة للقائمة',
  },
};

const SETTINGS_STORAGE_KEY = 'subwy_xg_settings_v1';

export class UIManager {
  constructor(app) {
    this.app = app; // reference to main SubwyGame instance
    this.lang = 'ar';
    this.selectedCampaignId = 'mission1';
    this.selectedWeaponPreview = 'ar';
    this.selectedVehiclePreview = 'tank';

    this.settings = {
      quality: 'HIGH',      // LOW | MEDIUM | HIGH
      shadows: 'HIGH',      // OFF | MEDIUM | HIGH
      resScale: 1.0,        // 0.6 | 0.8 | 1.0
      masterVol: 0.85,
      sfxVol: 0.90,
      musicVol: 0.65,
      sensitivity: 1.0,
      touchScale: 1.0,
      touchOpacity: 0.75,
      hudVisible: true,
      vibration: true,
      defaultPerspective: 'FPS',
      difficulty: 'VETERAN',
    };

    this._loadSavedSettings();

    this.minimapCanvas = document.getElementById('minimap-canvas');
    this.minimapCtx = this.minimapCanvas ? this.minimapCanvas.getContext('2d') : null;
    this._hitmarkerTimeout = null;
    this._damageArcTimeout = null;
    this._radioTimeout = null;
    this._projVec = new THREE.Vector3();

    this._bindCoreButtons();
    this.applyLanguage(this.lang);
    this.applyTouchVisualSettings();
    this._checkOrientation();
    window.addEventListener('resize', () => this._checkOrientation());
  }

  _loadSavedSettings() {
    try {
      const raw = localStorage.getItem(SETTINGS_STORAGE_KEY);
      if (raw) {
        Object.assign(this.settings, JSON.parse(raw));
      }
    } catch (_) {}
  }

  saveSettings() {
    try {
      localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(this.settings));
    } catch (_) {}
  }

  applyLanguage(lang) {
    this.lang = lang === 'ar' ? 'ar' : 'en';
    document.documentElement.lang = this.lang;
    document.documentElement.dir = this.lang === 'ar' ? 'rtl' : 'ltr';

    const dict = I18N[this.lang];
    document.querySelectorAll('[data-i18n]').forEach((el) => {
      const key = el.getAttribute('data-i18n');
      if (dict[key]) el.textContent = dict[key];
    });
  }

  applyTouchVisualSettings() {
    document.documentElement.style.setProperty('--touch-btn-scale', String(this.settings.touchScale));
    document.documentElement.style.setProperty('--touch-btn-opacity', String(this.settings.touchOpacity));
  }

  _checkOrientation() {
    const prompt = document.getElementById('landscape-prompt');
    if (!prompt || prompt.dataset.dismissed === '1') return;
    const isSmallPortrait = window.innerWidth < 620 && window.innerHeight > window.innerWidth * 1.15;
    prompt.classList.toggle('hidden', !isSmallPortrait);
  }

  updateBootProgress(pct, detailText = '') {
    const bar = document.getElementById('load-bar-fill');
    const pctLabel = document.getElementById('load-pct-text');
    const det = document.getElementById('load-detail-text');
    const clamped = Math.min(100, Math.round(pct * 100));
    if (bar) bar.style.width = `${clamped}%`;
    if (pctLabel) pctLabel.textContent = `${clamped}%`;
    if (det && detailText) det.textContent = detailText;
  }

  finishBootToMainMenu() {
    document.getElementById('loading-screen')?.classList.add('hidden');
    this.showMainMenu();
  }

  showMainMenu() {
    document.getElementById('main-menu')?.classList.remove('hidden');
    document.getElementById('game-hud')?.classList.add('hidden');
    document.getElementById('pause-modal')?.classList.add('hidden');
    document.getElementById('result-modal')?.classList.add('hidden');
    document.getElementById('cutscene-overlay')?.classList.add('hidden');
    this.closeSubpanel();
    this.refreshMenuHeaderBadges();
  }

  refreshMenuHeaderBadges() {
    const opEl = document.getElementById('active-soldier-label');
    const wpEl = document.getElementById('active-weapon-label');
    if (opEl && this.app.player) {
      opEl.textContent = this.app.player.operatorId.toUpperCase();
    }
    if (wpEl && this.app.weaponSys) {
      wpEl.textContent = this.app.weaponSys.loadoutIds[0].toUpperCase();
    }
  }

  _bindCoreButtons() {
    // Portrait orientation dismiss
    document.getElementById('btn-dismiss-rotate')?.addEventListener('click', () => {
      const p = document.getElementById('landscape-prompt');
      if (p) {
        p.dataset.dismissed = '1';
        p.classList.add('hidden');
      }
    });

    // Topbar quick actions
    document.getElementById('btn-lang-quick')?.addEventListener('click', () => {
      this.app.audio.playUIClick(true);
      this.applyLanguage(this.lang === 'ar' ? 'en' : 'ar');
    });

    document.getElementById('btn-fullscreen')?.addEventListener('click', () => {
      this.app.audio.playUIClick();
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen?.().catch(() => {});
        screen.orientation?.lock?.('landscape').catch(() => {});
      } else {
        document.exitFullscreen?.().catch(() => {});
      }
    });

    document.getElementById('btn-audio-toggle')?.addEventListener('click', (e) => {
      const on = this.app.audio.toggleMute();
      e.currentTarget.classList.toggle('active', on);
      e.currentTarget.textContent = on ? 'AUDIO: ON' : 'MUTED';
    });

    // Main Menu 7 Buttons
    document.querySelectorAll('[data-menu-action]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const action = btn.getAttribute('data-menu-action');
        this.app.audio.playUIClick(action === 'play');
        this.handleMenuAction(action);
      });
    });

    document.getElementById('btn-subpanel-back')?.addEventListener('click', () => {
      this.app.audio.playUIClick();
      this.closeSubpanel();
    });

    // Cutscene Skip
    document.getElementById('btn-skip-cutscene')?.addEventListener('click', () => {
      this.app.audio.playUIClick();
      this.app.missions.finishCutscene();
      this.app.controls.setEnabled(true);
    });

    // In-Game HUD Top-Right Utility Buttons
    document.getElementById('btn-hud-view')?.addEventListener('click', (e) => {
      e.stopPropagation();
      this.app.togglePerspectiveMode();
    });

    document.getElementById('btn-hud-nvg')?.addEventListener('click', (e) => {
      e.stopPropagation();
      const on = this.app.player.toggleNightVision();
      e.currentTarget.classList.toggle('active', on);
      document.body.style.filter = on ? 'sepia(0.35) hue-rotate(72deg) saturate(1.8) brightness(1.22)' : '';
    });

    document.getElementById('btn-hud-weather')?.addEventListener('click', (e) => {
      e.stopPropagation();
      this.app.cycleAtmospherePreset();
    });

    document.getElementById('btn-hud-pause')?.addEventListener('click', (e) => {
      e.stopPropagation();
      this.app.setPaused(true);
    });

    // Pause Modal Buttons
    document.getElementById('btn-pause-resume')?.addEventListener('click', () => {
      this.app.setPaused(false);
    });
    document.getElementById('btn-pause-settings')?.addEventListener('click', () => {
      this.app.returnToMenuAndOpen('settings');
    });
    document.getElementById('btn-pause-customize-hud')?.addEventListener('click', () => {
      document.getElementById('pause-modal')?.classList.add('hidden');
      this.enterTouchLayoutEditor();
    });
    document.getElementById('btn-pause-restart')?.addEventListener('click', () => {
      document.getElementById('pause-modal')?.classList.add('hidden');
      this.app.restartCurrentMission();
    });
    document.getElementById('btn-pause-quit')?.addEventListener('click', () => {
      this.app.quitToMainMenu();
    });

    // Touch Layout Drag Editor Save / Reset
    document.getElementById('btn-save-touch-layout')?.addEventListener('click', () => {
      this.app.controls.saveTouchLayout();
      this.exitTouchLayoutEditor();
    });
    document.getElementById('btn-reset-touch-layout')?.addEventListener('click', () => {
      this.app.controls.resetTouchLayout();
    });

    // Mission Result Screen Buttons
    document.getElementById('btn-result-next')?.addEventListener('click', () => {
      this.app.launchNextMission();
    });
    document.getElementById('btn-result-retry')?.addEventListener('click', () => {
      document.getElementById('result-modal')?.classList.add('hidden');
      this.app.restartCurrentMission();
    });
    document.getElementById('btn-result-menu')?.addEventListener('click', () => {
      this.app.quitToMainMenu();
    });

    // Exit Confirmation Modal
    document.getElementById('btn-exit-cancel')?.addEventListener('click', () => {
      document.getElementById('exit-modal')?.classList.add('hidden');
    });
    document.getElementById('btn-exit-confirm')?.addEventListener('click', () => {
      this.saveSettings();
      this.app.enterStandbyExit();
    });
  }

  handleMenuAction(action) {
    switch (action) {
      case 'play':
        this.app.startCampaignMission(this.selectedCampaignId);
        break;
      case 'campaign':
        this.openCampaignPanel();
        break;
      case 'loadout':
        this.openLoadoutPanel();
        break;
      case 'soldiers':
        this.openSoldiersPanel();
        break;
      case 'vehicles':
        this.openVehiclesPanel();
        break;
      case 'settings':
        this.openSettingsPanel();
        break;
      case 'exit':
        document.getElementById('exit-modal')?.classList.remove('hidden');
        break;
      default:
        break;
    }
  }

  openSubpanel(titleText, split3D = false) {
    document.getElementById('menu-home-nav')?.classList.add('hidden');
    document.getElementById('menu-home-intel')?.classList.add('hidden');
    const sp = document.getElementById('menu-subpanel');
    const title = document.getElementById('subpanel-title');
    if (title) title.textContent = titleText;
    if (sp) {
      sp.classList.remove('hidden');
      sp.classList.toggle('showcase-split', split3D);
    }
    const extra = document.getElementById('subpanel-extra-actions');
    if (extra) extra.innerHTML = '';
    return document.getElementById('subpanel-body');
  }

  closeSubpanel() {
    document.getElementById('menu-subpanel')?.classList.add('hidden');
    document.getElementById('menu-home-nav')?.classList.remove('hidden');
    document.getElementById('menu-home-intel')?.classList.remove('hidden');
    if (this.app.cameraSys) this.app.cameraSys.setMenuFocus('HOME');
    this.refreshMenuHeaderBadges();
  }

  // =========================================================
  // 1. CAMPAIGN PANEL (3 War Missions + Difficulty)
  // =========================================================
  openCampaignPanel() {
    const isAr = this.lang === 'ar';
    const body = this.openSubpanel(isAr ? 'طور القصة // العمليات الحربية' : 'CAMPAIGN // WAR OPERATIONS', false);
    const extra = document.getElementById('subpanel-extra-actions');
    if (extra) {
      extra.innerHTML = `
        <select id="camp-diff-select" style="background:#0f1722;color:#f8fafc;border:1px solid #f59e0b;padding:5px 10px;font-family:inherit;font-weight:700;">
          <option value="RECRUIT" ${this.settings.difficulty === 'RECRUIT' ? 'selected' : ''}>${isAr ? 'صعوبة: مبتدئ' : 'DIFFICULTY: RECRUIT'}</option>
          <option value="VETERAN" ${this.settings.difficulty === 'VETERAN' ? 'selected' : ''}>${isAr ? 'صعوبة: محترف' : 'DIFFICULTY: VETERAN'}</option>
          <option value="ELITE" ${this.settings.difficulty === 'ELITE' ? 'selected' : ''}>${isAr ? 'صعوبة: نخبة' : 'DIFFICULTY: ELITE'}</option>
        </select>
      `;
      extra.querySelector('#camp-diff-select')?.addEventListener('change', (e) => {
        this.settings.difficulty = e.target.value;
        this.app.enemyMgr.setDifficulty(this.settings.difficulty);
        this.saveSettings();
      });
    }

    body.innerHTML = `<div class="cards-grid-3">
      ${CAMPAIGN_MISSIONS.map((m) => `
        <div class="mission-card ${this.selectedCampaignId === m.id ? 'selected' : ''}" data-mid="${m.id}">
          <span class="mc-badge">${m.code}</span>
          <h3>${isAr ? m.titleAr : m.title}</h3>
          <p>${isAr ? m.descAr : m.desc}</p>
          <button class="tac-btn primary sm btn-deploy-mission" data-deploy="${m.id}" style="margin-top:auto;">
            ${isAr ? 'ابدأ المهمة الآن ▶' : 'DEPLOY MISSION ▶'}
          </button>
        </div>
      `).join('')}
    </div>`;

    body.querySelectorAll('.mission-card').forEach((card) => {
      card.addEventListener('click', () => {
        this.selectedCampaignId = card.dataset.mid;
        body.querySelectorAll('.mission-card').forEach((c) => c.classList.remove('selected'));
        card.classList.add('selected');
      });
    });

    body.querySelectorAll('.btn-deploy-mission').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.app.audio.playUIClick(true);
        this.selectedCampaignId = btn.dataset.deploy;
        this.app.startCampaignMission(this.selectedCampaignId);
      });
    });
  }

  // =========================================================
  // 2. LOADOUT PANEL (Live 3D Weapon Armory for All 6 GLB Weapons!)
  // =========================================================
  openLoadoutPanel() {
    const isAr = this.lang === 'ar';
    const body = this.openSubpanel(isAr ? 'ترسانة الأسلحة ثلاثية الأبعاد' : '3D WEAPON LOADOUT', true);
    this.app.cameraSys.setMenuFocus('LOADOUT');
    this.app.world.showcaseWeaponModel(this.selectedWeaponPreview);

    const weapons = Object.values(WEAPON_CATALOG);
    const curPrimary = this.app.weaponSys.loadoutIds[0];

    body.innerHTML = `
      <p style="margin:0 0 10px;font-size:0.78rem;color:#94a3b8;">
        ${isAr
          ? 'اختر سلاحك الأساسي لمعاينته بشكل ثلاثي الأبعاد حي وتجهيزه للمعركة (مع المسدس وقاذف الصواريخ RPG-7X):'
          : 'Inspect real-time 3D Blender GLB weapons & equip your Primary Combat Weapon (carried alongside P226 & RPG-7X):'}
      </p>
      <div class="cards-grid-3">
        ${weapons.map((w) => `
          <div class="armory-card ${this.selectedWeaponPreview === w.id ? 'selected' : ''}" data-wid="${w.id}">
            <span class="mc-badge">${w.category.toUpperCase()}</span>
            <h3>${isAr ? w.nameAr : w.name}</h3>
            <div class="stat-bars">
              <div class="stat-bar-row"><span>DMG</span><div class="stat-bar-bg"><div class="stat-bar-val" style="width:${w.stats.dmg}%"></div></div><span>${w.stats.dmg}</span></div>
              <div class="stat-bar-row"><span>RPM</span><div class="stat-bar-bg"><div class="stat-bar-val" style="width:${w.stats.rate}%"></div></div><span>${w.rpm}</span></div>
              <div class="stat-bar-row"><span>RNG</span><div class="stat-bar-bg"><div class="stat-bar-val" style="width:${w.stats.range}%"></div></div><span>${w.range}m</span></div>
            </div>
            <button class="tac-btn ${curPrimary === w.id ? 'primary' : ''} sm btn-equip-wpn" data-equip="${w.id}" style="margin-top:8px;">
              ${curPrimary === w.id ? (isAr ? '✓ مجهز حالياً' : '✓ EQUIPPED') : (isAr ? 'تجهيز كسلاح رئيسي' : 'EQUIP PRIMARY')}
            </button>
          </div>
        `).join('')}
      </div>
    `;

    body.querySelectorAll('.armory-card').forEach((card) => {
      card.addEventListener('click', () => {
        const wid = card.dataset.wid;
        this.selectedWeaponPreview = wid;
        this.app.audio.playUIClick();
        this.app.world.showcaseWeaponModel(wid);
        body.querySelectorAll('.armory-card').forEach((c) => c.classList.remove('selected'));
        card.classList.add('selected');
      });
    });

    body.querySelectorAll('.btn-equip-wpn').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const wid = btn.dataset.equip;
        this.selectedWeaponPreview = wid;
        const secondary = wid === 'pistol' ? 'ar' : 'pistol';
        const heavy = wid === 'rpg' ? 'sniper' : 'rpg';
        this.app.weaponSys.applyLoadout([wid, secondary, heavy]);
        this.app.world.showcaseWeaponModel(wid);
        this.openLoadoutPanel();
      });
    });
  }

  // =========================================================
  // 3. SOLDIERS PANEL (Live 3D Rigged Operator Selection)
  // =========================================================
  openSoldiersPanel() {
    const isAr = this.lang === 'ar';
    const body = this.openSubpanel(isAr ? 'اختيار الجندي والتجهيز' : 'SOLDIERS // 3D OPERATORS', true);
    this.app.cameraSys.setMenuFocus('SOLDIERS');

    const ops = Object.values(SOLDIER_OPERATORS);
    const activeOp = this.app.player.operatorId;

    body.innerHTML = `<div class="cards-grid-3">
      ${ops.map((op) => `
        <div class="armory-card ${activeOp === op.id ? 'selected' : ''}" data-op="${op.id}">
          <span class="mc-badge">HP ${op.maxHp} • ARMOR ${op.maxArmor}</span>
          <h3>${isAr ? op.nameAr : op.name}</h3>
          <p>${isAr ? op.roleAr : op.role}</p>
          <button class="tac-btn ${activeOp === op.id ? 'primary' : ''} sm" style="margin-top:auto;">
            ${activeOp === op.id ? (isAr ? '✓ الجندي المختار' : '✓ ACTIVE OPERATOR') : (isAr ? 'اختيار الجندي' : 'SELECT OPERATOR')}
          </button>
        </div>
      `).join('')}
    </div>`;

    body.querySelectorAll('.armory-card').forEach((card) => {
      card.addEventListener('click', () => {
        const opId = card.dataset.op;
        this.app.audio.playUIClick(true);
        this.app.player.setOperator(opId);
        this.app.world.showcaseSoldierTint(SOLDIER_OPERATORS[opId].vestColor);
        this.openSoldiersPanel();
      });
    });
  }

  // =========================================================
  // 4. VEHICLES PANEL (Live 3D Hangar + Instant Test Drive!)
  // =========================================================
  openVehiclesPanel() {
    const isAr = this.lang === 'ar';
    const body = this.openSubpanel(isAr ? 'المركبات والدبابات الحربية' : 'MILITARY VEHICLES & ARMOR', true);
    this.app.cameraSys.setMenuFocus('VEHICLES');
    this.app.world.showcaseVehicleModel(this.selectedVehiclePreview);

    const vehicles = Object.values(VEHICLE_CATALOG);
    body.innerHTML = `<div class="cards-grid-3">
      ${vehicles.map((v) => `
        <div class="armory-card ${this.selectedVehiclePreview === v.id ? 'selected' : ''}" data-vid="${v.id}">
          <span class="mc-badge">${v.drivable ? (isAr ? 'قابلة للقيادة' : 'DRIVABLE') : (isAr ? 'دعم جوي' : 'AIRCRAFT')}</span>
          <h3>${isAr ? v.nameAr : v.name}</h3>
          <p>${isAr ? v.roleAr : v.role}</p>
          <div class="stat-bars">
            <div class="stat-bar-row"><span>ARMOR</span><div class="stat-bar-bg"><div class="stat-bar-val" style="width:${v.stats.armor}%"></div></div><span>${v.maxHp}</span></div>
            <div class="stat-bar-row"><span>SPEED</span><div class="stat-bar-bg"><div class="stat-bar-val" style="width:${v.stats.speed}%"></div></div><span>${v.stats.speed}</span></div>
          </div>
          <button class="tac-btn primary sm btn-test-veh" data-drive="${v.id}" style="margin-top:8px;">
            ${isAr ? 'تجربة في الميدان ▶' : 'DEPLOY & TEST ▶'}
          </button>
        </div>
      `).join('')}
    </div>`;

    body.querySelectorAll('.armory-card').forEach((card) => {
      card.addEventListener('click', () => {
        const vid = card.dataset.vid;
        this.selectedVehiclePreview = vid;
        this.app.audio.playUIClick();
        this.app.world.showcaseVehicleModel(vid);
        body.querySelectorAll('.armory-card').forEach((c) => c.classList.remove('selected'));
        card.classList.add('selected');
      });
    });

    body.querySelectorAll('.btn-test-veh').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.app.audio.playUIClick(true);
        this.app.startVehicleTest(btn.dataset.drive);
      });
    });
  }

  // =========================================================
  // 5. SETTINGS PANEL (Graphics LOW/MED/HIGH, FPS/TPS, Audio, Touch)
  // =========================================================
  openSettingsPanel() {
    const isAr = this.lang === 'ar';
    const s = this.settings;
    const body = this.openSubpanel(isAr ? 'إعدادات اللعبة والأداء' : 'SETTINGS & MOBILE OPTIMIZATION', false);

    body.innerHTML = `
      <div class="settings-grid">
        <div class="setting-group">
          <h4>${isAr ? 'الرسومات والأداء' : 'GRAPHICS & PERFORMANCE'}</h4>
          <div class="setting-row">
            <span>${isAr ? 'جودة الرسومات' : 'Graphics Quality'}</span>
            <select id="set-quality">
              <option value="LOW" ${s.quality === 'LOW' ? 'selected' : ''}>LOW (30-60 FPS Mobile)</option>
              <option value="MEDIUM" ${s.quality === 'MEDIUM' ? 'selected' : ''}>MEDIUM</option>
              <option value="HIGH" ${s.quality === 'HIGH' ? 'selected' : ''}>HIGH (PBR + Soft Shadows)</option>
            </select>
          </div>
          <div class="setting-row">
            <span>${isAr ? 'جودة الظلال' : 'Shadows'}</span>
            <select id="set-shadows">
              <option value="OFF" ${s.shadows === 'OFF' ? 'selected' : ''}>OFF</option>
              <option value="MEDIUM" ${s.shadows === 'MEDIUM' ? 'selected' : ''}>MEDIUM</option>
              <option value="HIGH" ${s.shadows === 'HIGH' ? 'selected' : ''}>HIGH</option>
            </select>
          </div>
          <div class="setting-row">
            <span>${isAr ? 'دقة الرندر' : 'Resolution Scale'}</span>
            <select id="set-res">
              <option value="0.65" ${s.resScale === 0.65 ? 'selected' : ''}>65% (Battery Saver)</option>
              <option value="0.85" ${s.resScale === 0.85 ? 'selected' : ''}>85% (Balanced)</option>
              <option value="1" ${s.resScale === 1 ? 'selected' : ''}>100% (Native Crisp)</option>
            </select>
          </div>
          <div class="setting-row">
            <span>${isAr ? 'منظور اللعب الافتراضي' : 'Default Perspective'}</span>
            <select id="set-persp">
              <option value="FPS" ${s.defaultPerspective === 'FPS' ? 'selected' : ''}>FPS (First Person)</option>
              <option value="TPS" ${s.defaultPerspective === 'TPS' ? 'selected' : ''}>TPS (Third Person)</option>
            </select>
          </div>
        </div>

        <div class="setting-group">
          <h4>${isAr ? 'الصوت واللغة' : 'AUDIO & LANGUAGE'}</h4>
          <div class="setting-row">
            <span>${isAr ? 'مستوى الصوت العام' : 'Master Volume'}</span>
            <input type="range" id="set-vol-master" min="0" max="1" step="0.05" value="${s.masterVol}" />
          </div>
          <div class="setting-row">
            <span>${isAr ? 'المؤثرات القتالية' : 'Combat SFX'}</span>
            <input type="range" id="set-vol-sfx" min="0" max="1" step="0.05" value="${s.sfxVol}" />
          </div>
          <div class="setting-row">
            <span>${isAr ? 'الموسيقى العسكرية' : 'Menu Music'}</span>
            <input type="range" id="set-vol-music" min="0" max="1" step="0.05" value="${s.musicVol}" />
          </div>
          <div class="setting-row">
            <span>${isAr ? 'اللغة / Language' : 'Language / اللغة'}</span>
            <select id="set-lang">
              <option value="ar" ${this.lang === 'ar' ? 'selected' : ''}>العربية</option>
              <option value="en" ${this.lang === 'en' ? 'selected' : ''}>English</option>
            </select>
          </div>
        </div>

        <div class="setting-group">
          <h4>${isAr ? 'التحكم بالهاتف والماوس' : 'TOUCH & CAMERA CONTROLS'}</h4>
          <div class="setting-row">
            <span>${isAr ? 'حساسية الكاميرا' : 'Camera Sensitivity'}</span>
            <input type="range" id="set-sens" min="0.4" max="2.2" step="0.1" value="${s.sensitivity}" />
          </div>
          <div class="setting-row">
            <span>${isAr ? 'حجم أزرار اللمس' : 'Touch Button Size'}</span>
            <input type="range" id="set-tscale" min="0.75" max="1.35" step="0.05" value="${s.touchScale}" />
          </div>
          <div class="setting-row">
            <span>${isAr ? 'شفافية الأزرار' : 'Button Opacity'}</span>
            <input type="range" id="set-topacity" min="0.35" max="1.0" step="0.05" value="${s.touchOpacity}" />
          </div>
          <div class="setting-row">
            <span>${isAr ? 'اهتزاز الهاتف عند الانفجار' : 'Haptic Vibration'}</span>
            <input type="checkbox" id="set-vib" ${s.vibration ? 'checked' : ''} />
          </div>
          <button id="btn-open-hud-editor" class="tac-btn sm" style="width:100%;margin-top:6px;">
            ${isAr ? 'تخصيص مواقع أزرار الهاتف' : 'CUSTOMIZE TOUCH BUTTON POSITIONS'}
          </button>
        </div>
      </div>
    `;

    const applyAll = () => {
      s.quality = body.querySelector('#set-quality').value;
      s.shadows = body.querySelector('#set-shadows').value;
      s.resScale = parseFloat(body.querySelector('#set-res').value);
      s.defaultPerspective = body.querySelector('#set-persp').value;
      s.masterVol = parseFloat(body.querySelector('#set-vol-master').value);
      s.sfxVol = parseFloat(body.querySelector('#set-vol-sfx').value);
      s.musicVol = parseFloat(body.querySelector('#set-vol-music').value);
      s.sensitivity = parseFloat(body.querySelector('#set-sens').value);
      s.touchScale = parseFloat(body.querySelector('#set-tscale').value);
      s.touchOpacity = parseFloat(body.querySelector('#set-topacity').value);
      s.vibration = body.querySelector('#set-vib').checked;

      this.applyTouchVisualSettings();
      this.app.applySettings(s);
      this.saveSettings();
    };

    body.querySelectorAll('select, input').forEach((el) => {
      el.addEventListener('change', (e) => {
        if (e.target.id === 'set-lang') {
          this.applyLanguage(e.target.value);
          this.openSettingsPanel();
          return;
        }
        applyAll();
      });
      if (el.type === 'range') el.addEventListener('input', applyAll);
    });

    body.querySelector('#btn-open-hud-editor')?.addEventListener('click', () => {
      document.getElementById('main-menu')?.classList.add('hidden');
      this.showGameHud(true);
      this.enterTouchLayoutEditor();
    });
  }

  enterTouchLayoutEditor() {
    this.app.controls.editLayoutMode = true;
    document.body.classList.add('hud-editing');
    document.getElementById('hud-edit-banner')?.classList.remove('hidden');
  }

  exitTouchLayoutEditor() {
    this.app.controls.editLayoutMode = false;
    document.body.classList.remove('hud-editing');
    document.getElementById('hud-edit-banner')?.classList.add('hidden');
    if (!this.app.isPlaying) {
      this.showMainMenu();
    } else {
      this.app.setPaused(false);
    }
  }

  // =========================================================
  // CUTSCENE, RADIO, IN-GAME HUD & MINIMAP UPDATES
  // =========================================================
  showCutscene(missionDef) {
    document.getElementById('main-menu')?.classList.add('hidden');
    document.getElementById('game-hud')?.classList.add('hidden');
    const ov = document.getElementById('cutscene-overlay');
    if (ov) ov.classList.remove('hidden');
    const isAr = this.lang === 'ar';
    document.getElementById('cutscene-mission-code').textContent = missionDef.code;
    document.getElementById('cutscene-title').textContent = isAr ? missionDef.titleAr : missionDef.title;
    document.getElementById('cutscene-subtitle').textContent = isAr
      ? missionDef.cutscene.subtitleAr
      : missionDef.cutscene.subtitle;
  }

  hideCutscene() {
    document.getElementById('cutscene-overlay')?.classList.add('hidden');
  }

  showGameHud(visible) {
    const hud = document.getElementById('game-hud');
    if (hud) hud.classList.toggle('hidden', !visible || !this.settings.hudVisible);
    this._renderWeaponSlotButtons();
    this.syncPerspectiveBadges(this.app.cameraSys.perspective);
  }

  syncPerspectiveBadges(mode) {
    const topBtn = document.getElementById('btn-hud-view');
    const touchLbl = document.getElementById('tbtn-view-label');
    if (topBtn) topBtn.textContent = `VIEW: ${mode}`;
    if (touchLbl) touchLbl.textContent = mode;
  }

  _renderWeaponSlotButtons() {
    const row = document.getElementById('hud-weapon-slots');
    if (!row || !this.app.weaponSys) return;
    const active = this.app.weaponSys.activeSlotIndex;
    row.innerHTML = this.app.weaponSys.slots
      .map(
        (s, idx) =>
          `<button class="wslot-btn ${idx === active ? 'active' : ''}" data-slot="${idx}">[${idx + 1}] ${s.def.id.toUpperCase()}</button>`
      )
      .join('');
    row.querySelectorAll('.wslot-btn').forEach((btn) => {
      const selectSlot = (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.app.weaponSys.equipSlot(parseInt(btn.dataset.slot, 10));
        this._renderWeaponSlotButtons();
      };
      btn.addEventListener('click', selectSlot);
      btn.addEventListener('touchstart', selectSlot, { passive: false });
    });
  }

  showHitmarker(isHeadshot = false) {
    const hm = document.getElementById('hitmarker');
    if (!hm) return;
    hm.classList.remove('hidden');
    hm.classList.toggle('headshot', isHeadshot);
    clearTimeout(this._hitmarkerTimeout);
    this._hitmarkerTimeout = setTimeout(() => hm.classList.add('hidden'), 130);
  }

  showDamageDirection(player, attackerPos) {
    const arc = document.getElementById('damage-arc');
    if (!arc) return;
    if (attackerPos && player) {
      const dx = attackerPos.x - player.position.x;
      const dz = attackerPos.z - player.position.z;
      const worldAngle = Math.atan2(dx, -dz); // 0 = North (-Z)
      const relDeg = THREE.MathUtils.radToDeg(worldAngle + player.yaw);
      arc.style.transform = `rotate(${relDeg.toFixed(0)}deg)`;
    }
    arc.style.opacity = '1';
    clearTimeout(this._damageArcTimeout);
    this._damageArcTimeout = setTimeout(() => {
      arc.style.opacity = '0';
    }, 650);
  }

  showRadio(sender, message) {
    const banner = document.getElementById('radio-banner');
    if (!banner) return;
    document.getElementById('radio-sender').textContent = sender;
    document.getElementById('radio-text').textContent = message;
    banner.classList.remove('hidden');
    this.app.audio.play2D('radio_chatter', { volume: 0.6 });
    clearTimeout(this._radioTimeout);
    this._radioTimeout = setTimeout(() => banner.classList.add('hidden'), 5200);
  }

  pushKillfeed(text, highlight = false) {
    const kf = document.getElementById('killfeed');
    if (!kf) return;
    const item = document.createElement('div');
    item.className = 'kf-item';
    if (highlight) item.style.borderColor = '#ef4444';
    item.textContent = text;
    kf.prepend(item);
    while (kf.children.length > 4) kf.lastElementChild.remove();
    setTimeout(() => item.remove(), 4200);
  }

  showMissionResult(victory, missionDef, stats, elapsedSec) {
    this.app.controls.setEnabled(false);
    const modal = document.getElementById('result-modal');
    if (!modal) return;
    modal.classList.remove('hidden');

    const isAr = this.lang === 'ar';
    const badge = document.getElementById('result-badge');
    badge.className = `result-badge ${victory ? 'victory' : 'defeat'}`;
    badge.textContent = victory
      ? isAr ? 'اكتملت المهمة بنجاح' : 'MISSION ACCOMPLISHED'
      : isAr ? 'فشلت العملية — قُتل الجندي' : 'KIA // OPERATION FAILED';

    document.getElementById('result-title').textContent = victory
      ? isAr ? 'نصر عسكري ساحق!' : 'VICTORY'
      : isAr ? 'هزيمة' : 'DEFEAT';
    document.getElementById('result-subtitle').textContent = missionDef
      ? isAr ? missionDef.titleAr : missionDef.title
      : '';

    document.getElementById('stat-kills-val').textContent = String(stats.kills);
    document.getElementById('stat-hs-val').textContent = String(stats.headshots);
    document.getElementById('stat-veh-val').textContent = String(stats.vehiclesDestroyed);
    const mm = String(Math.floor(elapsedSec / 60)).padStart(2, '0');
    const ss = String(elapsedSec % 60).padStart(2, '0');
    document.getElementById('stat-time-val').textContent = `${mm}:${ss}`;

    const nextBtn = document.getElementById('btn-result-next');
    if (nextBtn) nextBtn.classList.toggle('hidden', !victory);
  }

  updateHudFrame({ player, weaponSys, controls, missions, enemyMgr, vehicleMgr, cameraSys, fps }) {
    // 1. Health, Armor, Low-HP Vignette & Stance
    const hpPct = Math.max(0, (player.hp / player.maxHp) * 100);
    const armPct = Math.max(0, (player.armor / Math.max(1, player.maxArmor)) * 100);
    document.getElementById('hud-hp-num').textContent = String(Math.ceil(player.hp));
    document.getElementById('hud-hp-fill').style.width = `${hpPct}%`;
    document.getElementById('hud-armor-fill').style.width = `${armPct}%`;
    document.getElementById('hud-stance-tag').textContent = player.getStanceLabel();

    const vig = document.getElementById('low-hp-vignette');
    if (vig) vig.style.opacity = hpPct < 45 ? String(((45 - hpPct) / 45) * 0.9) : '0';

    // 2. Active Weapon, Ammo & Pips
    const slot = weaponSys.activeSlot;
    if (slot) {
      document.getElementById('hud-weapon-name').textContent =
        this.lang === 'ar' ? slot.def.nameAr : slot.def.name;
      document.getElementById('hud-fire-mode').textContent = weaponSys.reloading
        ? this.lang === 'ar' ? 'جاري التلقيم...' : 'RELOADING...'
        : slot.def.fireMode;
      document.getElementById('hud-ammo-mag').textContent = String(slot.mag);
      document.getElementById('hud-ammo-res').textContent = String(slot.reserve);

      const pipsEl = document.getElementById('hud-ammo-pips');
      if (pipsEl) {
        const totalPips = Math.min(20, slot.def.magSize);
        const filled = Math.round((slot.mag / slot.def.magSize) * totalPips);
        if (pipsEl.dataset.key !== `${totalPips}_${filled}`) {
          pipsEl.dataset.key = `${totalPips}_${filled}`;
          let html = '';
          for (let i = 0; i < totalPips; i++) {
            html += `<span class="ammo-pip ${i >= filled ? 'spent' : ''}"></span>`;
          }
          pipsEl.innerHTML = html;
        }
      }

      // 8x Sniper Scope Overlay
      const scopeEl = document.getElementById('sniper-scope-overlay');
      const chWrap = document.getElementById('crosshair-wrap');
      const showScope = controls.ads && slot.def.scopeOverlay && !weaponSys.reloading && !player.activeVehicle;
      if (scopeEl) scopeEl.classList.toggle('hidden', !showScope);
      if (chWrap) {
        chWrap.classList.toggle('hidden', showScope);
        const speed = Math.hypot(player.velocity.x, player.velocity.z);
        const gap = controls.ads ? 3 : Math.round(7 + speed * 1.4 + weaponSys.kickZ * 95);
        chWrap.style.setProperty('--ch-gap', `${gap}px`);
      }
    }

    // Check if active weapon slot button needs highlight sync
    const wslots = document.querySelectorAll('.wslot-btn');
    wslots.forEach((b, i) => b.classList.toggle('active', i === weaponSys.activeSlotIndex));

    // 3. Context-Sensitive Vehicle Board / Exit Button & Vehicle Armor Bar!
    const nearVeh = !player.activeVehicle ? vehicleMgr.findNearestDrivable(player.position, 6.0) : null;
    const interBtn = document.getElementById('tbtn-interact');
    const interLbl = document.getElementById('tbtn-interact-label');
    if (interBtn && interLbl) {
      if (player.activeVehicle) {
        interBtn.classList.remove('hidden');
        interLbl.textContent = 'EXIT';
      } else if (nearVeh) {
        interBtn.classList.remove('hidden');
        interLbl.textContent = 'DRIVE';
      } else {
        interBtn.classList.add('hidden');
      }
    }

    const vehHud = document.getElementById('vehicle-hud-bar');
    if (vehHud) {
      if (player.activeVehicle) {
        vehHud.classList.remove('hidden');
        document.getElementById('hud-veh-name').textContent = player.activeVehicle.spec.name;
        const vPct = (player.activeVehicle.hp / player.activeVehicle.maxHp) * 100;
        document.getElementById('hud-veh-hp-fill').style.width = `${vPct}%`;
      } else {
        vehHud.classList.add('hidden');
      }
    }

    // 4. Compass Bearing & FPS Badge
    const deg = (((-THREE.MathUtils.radToDeg(player.yaw)) % 360) + 360) % 360;
    const dirs = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
    const cardinal = dirs[Math.round(deg / 45) % 8];
    document.getElementById('compass-deg').textContent = `${String(Math.round(deg)).padStart(3, '0')}° ${cardinal}`;
    document.getElementById('compass-strip').textContent = `W · NW · N · NE · E · SE · S · SW · W`;
    document.getElementById('hud-fps-badge').textContent = `${fps} FPS`;

    // 5. Mission Tracker + 3D World-to-Screen Floating Objective Diamond
    const m = missions.activeMission;
    const st = missions.currentStage;
    if (m) {
      document.getElementById('hud-mission-name').textContent =
        this.lang === 'ar' ? m.titleAr : `${m.code}: ${m.title}`;
    }
    if (st) {
      document.getElementById('hud-objective-text').textContent =
        this.lang === 'ar' ? st.objectiveAr : st.objectiveEn;
      document.getElementById('hud-objective-progress').textContent =
        this.lang === 'ar'
          ? `الأعداء المتبقون: ${enemyMgr.aliveEnemyCount}`
          : `HOSTILES REMAINING: ${enemyMgr.aliveEnemyCount}`;

      const wpEl = document.getElementById('world-waypoint');
      if (wpEl && st.waypoint) {
        this._projVec.copy(st.waypoint);
        this._projVec.y += 2.2;
        const dist = Math.round(player.position.distanceTo(st.waypoint));
        this._projVec.project(cameraSys.camera);
        if (this._projVec.z < 1.0) {
          const sx = (this._projVec.x * 0.5 + 0.5) * window.innerWidth;
          const sy = (-this._projVec.y * 0.5 + 0.5) * window.innerHeight;
          wpEl.classList.remove('hidden');
          wpEl.style.left = `${THREE.MathUtils.clamp(sx, 36, window.innerWidth - 36)}px`;
          wpEl.style.top = `${THREE.MathUtils.clamp(sy, 48, window.innerHeight - 48)}px`;
          document.getElementById('wp-label').textContent = `OBJ ${dist}m`;
        } else {
          wpEl.classList.add('hidden');
        }
      }
    }

    // 6. Rotating Tactical Radar Minimap
    this._drawMinimap(player, enemyMgr, vehicleMgr, st ? st.waypoint : null);
  }

  _drawMinimap(player, enemyMgr, vehicleMgr, waypoint) {
    const ctx = this.minimapCtx;
    if (!ctx) return;
    const W = this.minimapCanvas.width;
    const H = this.minimapCanvas.height;
    const cx = W / 2;
    const cy = H / 2;
    const scale = 0.72; // pixels per world meter (~100m radar radius)

    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = '#09131c';
    ctx.fillRect(0, 0, W, H);

    // Radar range rings
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.18)';
    ctx.lineWidth = 1;
    for (const r of [24, 48, 68]) {
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.stroke();
    }

    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(player.yaw);

    // North-South Central Highway & Canyon Bridge
    const rx = -player.position.x * scale;
    const rz = -player.position.z * scale;
    ctx.fillStyle = 'rgba(148, 163, 184, 0.22)';
    ctx.fillRect(rx - 4, rz - 130, 8, 260);

    // Ruined Buildings Footprints
    ctx.fillStyle = 'rgba(203, 213, 225, 0.35)';
    for (const b of this.app.world.buildingFootprints) {
      const bx = (b.x - player.position.x) * scale;
      const bz = (b.z - player.position.z) * scale;
      ctx.fillRect(bx - (b.w * scale) / 2, bz - (b.d * scale) / 2, b.w * scale, b.d * scale);
    }

    // Vehicles (Gold = Ally/Drivable, Orange = Enemy Armor)
    for (const v of vehicleMgr.vehicles) {
      if (v.destroyed) continue;
      const vx = (v.root.position.x - player.position.x) * scale;
      const vz = (v.root.position.z - player.position.z) * scale;
      ctx.fillStyle = v.team === 'ally' ? '#fbbf24' : '#f97316';
      ctx.fillRect(vx - 3.5, vz - 3.5, 7, 7);
    }

    // Allied Squadmates (Cyan dots)
    ctx.fillStyle = '#38bdf8';
    for (const a of enemyMgr.allies) {
      if (a.dead) continue;
      const ax = (a.position.x - player.position.x) * scale;
      const az = (a.position.z - player.position.z) * scale;
      ctx.beginPath();
      ctx.arc(ax, az, 3, 0, Math.PI * 2);
      ctx.fill();
    }

    // Enemy Soldiers (Red blips)
    ctx.fillStyle = '#ef4444';
    for (const e of enemyMgr.enemies) {
      if (e.dead) continue;
      const ex = (e.position.x - player.position.x) * scale;
      const ez = (e.position.z - player.position.z) * scale;
      ctx.beginPath();
      ctx.arc(ex, ez, 3.2, 0, Math.PI * 2);
      ctx.fill();
    }

    // Objective Waypoint Diamond
    if (waypoint) {
      const wx = THREE.MathUtils.clamp((waypoint.x - player.position.x) * scale, -62, 62);
      const wz = THREE.MathUtils.clamp((waypoint.z - player.position.z) * scale, -62, 62);
      ctx.fillStyle = '#facc15';
      ctx.beginPath();
      ctx.arc(wx, wz, 4.5, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.restore();

    // Player Center FOV Cone & White Arrow (always pointing UP on rotating radar)
    ctx.fillStyle = 'rgba(56, 189, 248, 0.13)';
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.arc(cx, cy, 46, -Math.PI * 0.72, -Math.PI * 0.28);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.moveTo(cx, cy - 5);
    ctx.lineTo(cx - 4, cy + 4);
    ctx.lineTo(cx + 4, cy + 4);
    ctx.closePath();
    ctx.fill();
  }
}
