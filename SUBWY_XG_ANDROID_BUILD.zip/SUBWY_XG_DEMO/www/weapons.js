// weapons.js — 3D GLB Weapon System (6 Classes), FPS Arms Rig, ADS Optics, Ballistics & Rockets
import * as THREE from 'three';

export const WEAPON_CATALOG = {
  ar: {
    id: 'ar',
    name: 'XM4-XG CARBINE',
    nameAr: 'بندقية هجومية XM4-XG',
    category: 'Assault Rifle',
    fireMode: 'AUTO',
    rpm: 700,
    damage: 32,
    headMult: 2.4,
    magSize: 30,
    reserveMax: 150,
    reloadTime: 1.55,
    spreadHip: 0.022,
    spreadAds: 0.0035,
    recoilPitch: 0.018,
    recoilYaw: 0.007,
    adsFov: 52,
    mobility: 1.0,
    range: 240,
    sound: 'rifle_shot',
    hipPos: [0.22, -0.22, -0.38],
    adsPos: [0.0, -0.105, -0.24],
    stats: { dmg: 64, rate: 82, range: 74, mob: 85 },
  },
  sniper: {
    id: 'sniper',
    name: 'SR-50 LYNX .50',
    nameAr: 'قناصة ثقيلة SR-50',
    category: 'Sniper Rifle',
    fireMode: 'BOLT',
    rpm: 54,
    damage: 125,
    headMult: 2.6,
    armorDamage: 95,
    magSize: 6,
    reserveMax: 30,
    reloadTime: 2.1,
    spreadHip: 0.065,
    spreadAds: 0.0004,
    recoilPitch: 0.068,
    recoilYaw: 0.014,
    adsFov: 16,
    scopeOverlay: true,
    mobility: 0.88,
    range: 380,
    sound: 'sniper_shot',
    hipPos: [0.24, -0.24, -0.44],
    adsPos: [0.0, -0.12, -0.26],
    stats: { dmg: 98, rate: 25, range: 100, mob: 64 },
  },
  lmg: {
    id: 'lmg',
    name: 'M249 TITAN LMG',
    nameAr: 'رشاش ثقيل M249 TITAN',
    category: 'Machine Gun',
    fireMode: 'AUTO',
    rpm: 660,
    damage: 29,
    headMult: 2.2,
    armorDamage: 16,
    magSize: 90,
    reserveMax: 180,
    reloadTime: 2.35,
    spreadHip: 0.034,
    spreadAds: 0.0075,
    recoilPitch: 0.020,
    recoilYaw: 0.011,
    adsFov: 54,
    mobility: 0.86,
    range: 230,
    sound: 'rifle_shot',
    hipPos: [0.25, -0.25, -0.40],
    adsPos: [0.0, -0.125, -0.26],
    stats: { dmg: 70, rate: 80, range: 72, mob: 58 },
  },
  shotgun: {
    id: 'shotgun',
    name: 'SG-12 BREACHER',
    nameAr: 'شوزن تكتيكي SG-12',
    category: 'Shotgun',
    fireMode: 'PUMP',
    rpm: 88,
    damage: 21,
    pellets: 8,
    headMult: 1.8,
    magSize: 8,
    reserveMax: 40,
    reloadTime: 1.85,
    spreadHip: 0.068,
    spreadAds: 0.042,
    recoilPitch: 0.055,
    recoilYaw: 0.018,
    adsFov: 58,
    mobility: 0.98,
    range: 65,
    sound: 'shotgun_shot',
    hipPos: [0.22, -0.23, -0.38],
    adsPos: [0.0, -0.092, -0.25],
    stats: { dmg: 92, rate: 34, range: 35, mob: 84 },
  },
  pistol: {
    id: 'pistol',
    name: 'P226 SPEC-OPS',
    nameAr: 'مسدس تكتيكي P226',
    category: 'Pistol',
    fireMode: 'SEMI',
    rpm: 400,
    damage: 28,
    headMult: 2.5,
    magSize: 15,
    reserveMax: 75,
    reloadTime: 1.15,
    spreadHip: 0.018,
    spreadAds: 0.004,
    recoilPitch: 0.022,
    recoilYaw: 0.006,
    adsFov: 60,
    mobility: 1.08,
    range: 130,
    sound: 'pistol_shot',
    hipPos: [0.18, -0.20, -0.32],
    adsPos: [0.0, -0.072, -0.24],
    stats: { dmg: 48, rate: 62, range: 48, mob: 100 },
  },
  rpg: {
    id: 'rpg',
    name: 'RPG-7X LAUNCHER',
    nameAr: 'قاذف صواريخ RPG-7X',
    category: 'Rocket Launcher',
    fireMode: 'ROCKET',
    rpm: 38,
    damage: 440,
    splashRadius: 9.5,
    isRocket: true,
    magSize: 1,
    reserveMax: 5,
    reloadTime: 2.25,
    spreadHip: 0.015,
    spreadAds: 0.003,
    recoilPitch: 0.085,
    recoilYaw: 0.02,
    adsFov: 54,
    mobility: 0.84,
    range: 300,
    sound: 'rpg_launch',
    hipPos: [0.25, -0.22, -0.34],
    adsPos: [0.032, -0.115, -0.22],
    stats: { dmg: 100, rate: 15, range: 86, mob: 52 },
  },
};

export class WeaponSystem {
  constructor(scene, camera, assets, audio, world) {
    this.scene = scene;
    this.camera = camera;
    this.assets = assets;
    this.audio = audio;
    this.world = world;

    // 3 Equipped Slots: Primary, Sidearm, Anti-Tank RPG
    this.loadoutIds = ['ar', 'pistol', 'rpg'];
    this.slots = [];
    this.activeSlotIndex = 0;

    // Viewmodel group attached to Camera (hidden until FPS combat starts!)
    this.viewmodelRoot = new THREE.Group();
    this.viewmodelRoot.visible = false;
    this.weaponPivot = new THREE.Group();
    this.viewmodelRoot.add(this.weaponPivot);
    this.camera.add(this.viewmodelRoot);

    // Muzzle Flash 3D Star + Dynamic PointLight
    this.muzzleFlashMesh = this._createMuzzleFlashMesh();
    this.muzzleLight = new THREE.PointLight(0xffa43b, 0, 9);
    this.weaponPivot.add(this.muzzleLight);
    this.muzzleFlashTimer = 0;

    // FPS Tactical Gloved Arms
    this.armL = null;
    this.armR = null;
    this._initFpsArms();

    // Animation & Fire State
    this.cooldown = 0;
    this.reloading = false;
    this.reloadTimer = 0;
    this.semiTriggerLocked = false;
    this.kickZ = 0;
    this.kickRotX = 0;
    this.boltKick = 0;
    this.adsBlend = 0;
    this.swayX = 0;
    this.swayY = 0;
    this.bobT = 0;

    // Active flying 3D Rockets & Tank Shells!
    this.projectiles = [];
    // Ejected spinning brass shell casings!
    this.casings = [];
    this._casingGeo = new THREE.CylinderGeometry(0.006, 0.006, 0.028, 6);
    this._casingMat = new THREE.MeshStandardMaterial({ color: 0xd4a437, metalness: 0.85, roughness: 0.25 });

    this._raycaster = new THREE.Raycaster();
    this._tmpOrigin = new THREE.Vector3();
    this._tmpDir = new THREE.Vector3();
    this._tmpMuzzle = new THREE.Vector3();

    // Callback for HUD hitmarkers & kill stats
    this.onHitEnemy = null;

    this.applyLoadout(this.loadoutIds);
  }

  _createMuzzleFlashMesh() {
    const group = new THREE.Group();
    const mat = new THREE.MeshBasicMaterial({
      color: 0xffd27a,
      transparent: true,
      opacity: 0.92,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    for (let i = 0; i < 3; i++) {
      const plane = new THREE.Mesh(new THREE.PlaneGeometry(0.24, 0.09), mat);
      plane.rotation.z = (i * Math.PI) / 3;
      if (i < 2) plane.rotation.y = Math.PI / 2;
      group.add(plane);
    }
    group.visible = false;
    return group;
  }

  _initFpsArms() {
    const armsGltf = this.assets.models.get('fps_arms');
    if (!armsGltf) return;
    const srcL = armsGltf.scene.getObjectByName('ArmL');
    const srcR = armsGltf.scene.getObjectByName('ArmR');
    if (srcL) {
      this.armL = srcL.clone(true);
      this.armL.traverse((c) => { if (c.isMesh) c.frustumCulled = false; });
      this.weaponPivot.add(this.armL);
    }
    if (srcR) {
      this.armR = srcR.clone(true);
      this.armR.traverse((c) => { if (c.isMesh) c.frustumCulled = false; });
      this.weaponPivot.add(this.armR);
    }
  }

  applyLoadout(ids = ['ar', 'pistol', 'rpg']) {
    this.loadoutIds = [...ids];
    // Clean old meshes
    for (const s of this.slots) {
      if (s.mesh) this.weaponPivot.remove(s.mesh);
    }
    this.slots = this.loadoutIds.map((id) => {
      const def = WEAPON_CATALOG[id] || WEAPON_CATALOG.ar;
      const gltf = this.assets.models.get(`weapon_${def.id}`);
      const mesh = gltf ? gltf.scene.clone(true) : new THREE.Group();
      mesh.visible = false;
      mesh.traverse((c) => {
        if (c.isMesh) {
          c.castShadow = false;
          c.frustumCulled = false;
        }
      });
      this.weaponPivot.add(mesh);

      const magNode = mesh.getObjectByName('Magazine');
      const boltNode = mesh.getObjectByName('Bolt');
      const muzzleNode = mesh.getObjectByName('MuzzlePoint');
      const gripL = mesh.getObjectByName('GripL');
      const gripR = mesh.getObjectByName('GripR');

      return {
        def,
        mesh,
        mag: def.magSize,
        reserve: def.reserveMax,
        magNode,
        magBasePos: magNode ? magNode.position.clone() : null,
        boltNode,
        boltBasePos: boltNode ? boltNode.position.clone() : null,
        muzzleNode,
        gripLPos: gripL ? gripL.position.clone() : new THREE.Vector3(-0.02, -0.03, -0.22),
        gripRPos: gripR ? gripR.position.clone() : new THREE.Vector3(0, -0.06, 0.04),
      };
    });

    this.equipSlot(0);
  }

  get activeSlot() {
    return this.slots[this.activeSlotIndex] || this.slots[0];
  }

  get currentWeapon() {
    return this.activeSlot ? this.activeSlot.def : WEAPON_CATALOG.ar;
  }

  equipSlot(idx) {
    if (idx < 0 || idx >= this.slots.length) return;
    this.reloading = false;
    this.reloadTimer = 0;
    this.activeSlotIndex = idx;

    this.slots.forEach((s, i) => {
      s.mesh.visible = i === idx;
      if (s.magNode && s.magBasePos) s.magNode.position.copy(s.magBasePos);
    });

    const cur = this.activeSlot;
    if (cur && cur.muzzleNode) {
      cur.muzzleNode.add(this.muzzleFlashMesh);
      this.muzzleFlashMesh.position.set(0, 0, 0);
    }
    this.kickZ = 0.08;
    this.kickRotX = -0.18;
    this.audio.play2D('reload_mech', { volume: 0.35, rate: 1.45 });
  }

  cycleWeapon() {
    const next = (this.activeSlotIndex + 1) % this.slots.length;
    this.equipSlot(next);
  }

  needsAmmo() {
    return this.slots.some((s) => s.mag < s.def.magSize || s.reserve < s.def.reserveMax);
  }

  refillAllAmmo() {
    for (const s of this.slots) {
      s.mag = s.def.magSize;
      s.reserve = s.def.reserveMax;
      if (s.magNode) s.magNode.visible = true;
    }
  }

  startReload(player) {
    const slot = this.activeSlot;
    if (!slot || this.reloading) return false;
    if (slot.mag >= slot.def.magSize || slot.reserve <= 0) return false;

    this.reloading = true;
    const speedFactor = player && player.operatorId === 'commando' ? 0.82 : 1.0;
    this.reloadTimer = slot.def.reloadTime * speedFactor;
    this.reloadDuration = this.reloadTimer;
    this.audio.play2D('reload_mech', { volume: 0.85, rate: 1.55 / this.reloadDuration });
    if (player) player.triggerActionAnim('Reload', this.reloadDuration);
    return true;
  }

  /** Spawns a physical flying 3D Rocket or Tank Shell that detonates on impact! */
  spawnExplosiveProjectile(origin, dir, { speed = 68, damage = 440, radius = 9.5, owner = 'player', scale = 1.35 } = {}) {
    const grp = new THREE.Group();
    const body = new THREE.Mesh(
      new THREE.CylinderGeometry(0.045, 0.06, 0.48, 8),
      new THREE.MeshStandardMaterial({ color: 0x5c6346, metalness: 0.5, roughness: 0.4 })
    );
    body.rotation.x = Math.PI / 2;
    const glow = new THREE.Mesh(
      new THREE.SphereGeometry(0.09, 8, 8),
      new THREE.MeshBasicMaterial({ color: 0xff7b1a })
    );
    glow.position.z = 0.25;
    grp.add(body, glow);
    grp.position.copy(origin);
    grp.lookAt(origin.clone().add(dir));
    this.scene.add(grp);

    this.projectiles.push({
      mesh: grp,
      pos: origin.clone(),
      vel: dir.clone().normalize().multiplyScalar(speed),
      damage,
      radius,
      owner,
      scale,
      age: 0,
      smokeAcc: 0,
    });
  }

  tryFire({ player, cameraSys, isAds, enemyMgr, vehicleMgr }) {
    const slot = this.activeSlot;
    if (!slot || this.reloading || this.cooldown > 0) return false;

    const def = slot.def;
    if ((def.fireMode === 'SEMI' || def.fireMode === 'BOLT' || def.fireMode === 'PUMP') && this.semiTriggerLocked) {
      return false;
    }

    if (slot.mag <= 0) {
      this.semiTriggerLocked = true;
      this.startReload(player);
      return false;
    }

    slot.mag--;
    this.cooldown = 60.0 / def.rpm;
    if (def.fireMode !== 'AUTO') this.semiTriggerLocked = true;

    // Hide RPG warhead on launcher until reloaded!
    if (def.isRocket && slot.magNode) {
      slot.magNode.visible = false;
    }

    // Audio + Recoil + Viewmodel/TPS Kick
    this.audio.play2D(def.sound, { volume: 0.92, rate: 0.96 + Math.random() * 0.08 });
    if (def.isRocket || def.id === 'sniper' || def.id === 'shotgun') {
      this.audio.vibrate(30);
    }

    const recMult = player ? player.operator.recoilMult : 1.0;
    cameraSys.addRecoil(
      def.recoilPitch * recMult * (isAds ? 0.72 : 1.0),
      (Math.random() - 0.5) * 2 * def.recoilYaw * recMult
    );
    this.kickZ = Math.min(0.11, this.kickZ + 0.055);
    this.kickRotX = Math.max(-0.22, this.kickRotX - 0.08);
    this.boltKick = 1.0;

    // Muzzle Flash & Gunbarrel Smoke
    this.muzzleFlashMesh.visible = true;
    this.muzzleFlashMesh.rotation.z = Math.random() * Math.PI;
    this.muzzleLight.intensity = 5.5;
    this.muzzleFlashTimer = 0.05;

    if (player) player.triggerActionAnim('Shoot', 0.22);

    // Alert enemy acoustic AI sensors!
    if (enemyMgr && player) {
      enemyMgr.notifySound(player.position, def.id === 'pistol' ? 42 : 88);
    }

    // Compute world muzzle position (for tracer origin & brass casing)
    if (cameraSys.perspective === 'TPS' && player && player.tpsModel && player.tpsModel.visible) {
      const fwd = new THREE.Vector3(-Math.sin(player.yaw), 0, -Math.cos(player.yaw));
      const right = new THREE.Vector3(Math.cos(player.yaw), 0, -Math.sin(player.yaw));
      this._tmpMuzzle
        .copy(player.position)
        .addScaledVector(fwd, 0.75)
        .addScaledVector(right, 0.16);
      this._tmpMuzzle.y += player.isCrouching ? 0.95 : 1.32;
    } else if (slot.muzzleNode) {
      slot.muzzleNode.getWorldPosition(this._tmpMuzzle);
    } else {
      this.camera.getWorldPosition(this._tmpMuzzle);
    }

    // Eject spinning brass shell casing (for cartridge firearms)
    if (!def.isRocket && this.world.quality !== 'LOW') {
      this._spawnShellCasing();
    }

    // Rocket Launcher fires physical 3D explosive warhead!
    this.camera.getWorldPosition(this._tmpOrigin);
    this.camera.getWorldDirection(this._tmpDir);

    if (def.isRocket) {
      const spawnPt = this._tmpMuzzle.clone().addScaledVector(this._tmpDir, 0.4);
      this.spawnExplosiveProjectile(spawnPt, this._tmpDir, {
        speed: 68,
        damage: def.damage,
        radius: def.splashRadius,
        owner: 'player',
        scale: 1.45,
      });
      if (slot.mag === 0 && slot.reserve > 0) {
        setTimeout(() => this.startReload(player), 280);
      }
      return true;
    }

    // Hitscan / Multi-Pellet Ballistics
    const pellets = def.pellets || 1;
    const baseSpread = isAds ? def.spreadAds : def.spreadHip * (player && player.isCrouching ? 0.7 : 1.0);

    for (let p = 0; p < pellets; p++) {
      const dir = this._tmpDir.clone();
      dir.x += (Math.random() - 0.5) * baseSpread * 2;
      dir.y += (Math.random() - 0.5) * baseSpread * 2;
      dir.z += (Math.random() - 0.5) * baseSpread * 2;
      dir.normalize();

      this._fireRay(this._tmpOrigin, dir, def, enemyMgr, vehicleMgr);
    }

    if (slot.mag === 0 && slot.reserve > 0) {
      setTimeout(() => this.startReload(player), 180);
    }
    return true;
  }

  _fireRay(origin, dir, def, enemyMgr, vehicleMgr) {
    this._raycaster.set(origin, dir);
    this._raycaster.far = def.range;

    // 1. Check static world distance first
    let bestDist = def.range;
    let worldHit = null;
    const envHits = this._raycaster.intersectObjects(this.world.staticCollidersMeshList, false);
    if (envHits.length > 0) {
      bestDist = envHits[0].distance;
      worldHit = envHits[0];
    }

    // 2. Check Enemy Soldiers
    const enemyHit = enemyMgr ? enemyMgr.raycastEnemies(origin, dir, bestDist) : null;
    if (enemyHit && enemyHit.distance < bestDist) {
      bestDist = enemyHit.distance;
      const dmg = def.damage * (enemyHit.isHeadshot ? def.headMult : 1.0);
      const killed = enemyHit.enemy.takeDamage(dmg, origin, enemyHit.isHeadshot);
      this.world.spawnImpact(enemyHit.point, dir.clone().negate(), { isBlood: true });
      this.world.spawnTracer(this._tmpMuzzle, enemyHit.point);
      this.audio.playHitmarker(enemyHit.isHeadshot || killed);
      if (this.onHitEnemy) {
        this.onHitEnemy({ isHeadshot: enemyHit.isHeadshot, killed, enemy: enemyHit.enemy });
      }
      return;
    }

    // 3. Check Enemy Vehicles / Helicopters
    const vehHit = vehicleMgr ? vehicleMgr.raycastVehicles(origin, dir, bestDist, 'enemy') : null;
    if (vehHit && vehHit.distance < bestDist) {
      const armorDmg = def.armorDamage || def.damage * 0.28;
      const destroyed = vehHit.vehicle.takeDamage(armorDmg);
      this.world.spawnImpact(vehHit.point, dir.clone().negate(), { isBlood: false });
      this.world.spawnTracer(this._tmpMuzzle, vehHit.point);
      this.audio.playHitmarker(destroyed);
      if (this.onHitEnemy) {
        this.onHitEnemy({ isHeadshot: false, killed: destroyed, isVehicle: true });
      }
      return;
    }

    // 4. World Surface Impact
    const endPoint = worldHit ? worldHit.point : origin.clone().addScaledVector(dir, def.range);
    this.world.spawnTracer(this._tmpMuzzle, endPoint);
    if (worldHit) {
      const n = worldHit.face ? worldHit.face.normal : new THREE.Vector3(0, 1, 0);
      this.world.spawnImpact(worldHit.point, n, { isBlood: false });
    }
  }

  _spawnShellCasing() {
    if (this.casings.length > 20) return;
    const mesh = new THREE.Mesh(this._casingGeo, this._casingMat);
    mesh.position.copy(this._tmpMuzzle);
    this.scene.add(mesh);
    const camRight = new THREE.Vector3(1, 0, 0).applyQuaternion(this.camera.quaternion);
    this.casings.push({
      mesh,
      vel: camRight.multiplyScalar(2.2 + Math.random()).add(new THREE.Vector3(0, 1.8 + Math.random(), 0)),
      age: 0,
    });
  }

  update(dt, { controls, player, cameraSys, enemyMgr, vehicleMgr, isPlaying }) {
    if (!controls.firing) {
      this.semiTriggerLocked = false;
    }

    // Update flying 3D Rockets & Tank Shells even if viewmodel is hidden
    this._updateProjectiles(dt, player, cameraSys, enemyMgr, vehicleMgr);
    this._updateCasings(dt);

    if (!isPlaying || !player || player.dead) {
      this.viewmodelRoot.visible = false;
      return;
    }

    if (this.cooldown > 0) this.cooldown -= dt;

    // Handle active Reload timer & 3D Magazine animation
    const slot = this.activeSlot;
    if (this.reloading && slot) {
      this.reloadTimer -= dt;
      if (slot.magNode && slot.magBasePos) {
        const progress = 1.0 - Math.max(0, this.reloadTimer / this.reloadDuration);
        // Drop mag down smoothly in first half, slap back up in second half!
        const drop = Math.sin(progress * Math.PI);
        slot.magNode.visible = true;
        slot.magNode.position.set(
          slot.magBasePos.x,
          slot.magBasePos.y - drop * 0.24,
          slot.magBasePos.z + drop * 0.05
        );
      }
      if (this.reloadTimer <= 0) {
        this.reloading = false;
        const needed = slot.def.magSize - slot.mag;
        const take = Math.min(needed, slot.reserve);
        slot.mag += take;
        slot.reserve -= take;
        if (slot.magNode && slot.magBasePos) {
          slot.magNode.position.copy(slot.magBasePos);
          slot.magNode.visible = slot.mag > 0 || !slot.def.isRocket;
        }
      }
    }

    // Muzzle flash decay
    if (this.muzzleFlashTimer > 0) {
      this.muzzleFlashTimer -= dt;
      if (this.muzzleFlashTimer <= 0) {
        this.muzzleFlashMesh.visible = false;
        this.muzzleLight.intensity = 0;
      }
    }

    // Fire input (when on foot — Vehicle weapons are handled by VehicleManager)
    if (!player.activeVehicle && controls.firing) {
      this.tryFire({ player, cameraSys, isAds: controls.ads, enemyMgr, vehicleMgr });
    }

    // Determine FPS Viewmodel visibility:
    // Hidden in TPS mode, inside vehicles, or when zoomed into full 8x Sniper Scope reticle!
    const inSniperScope = controls.ads && slot && slot.def.scopeOverlay && !this.reloading;
    const showFpsViewmodel =
      cameraSys.perspective === 'FPS' && !player.activeVehicle && !inSniperScope;
    this.viewmodelRoot.visible = showFpsViewmodel;

    if (!showFpsViewmodel || !slot) return;

    // Smooth ADS interpolation + Sway + Movement Bob + Recoil Kickback
    const targetAds = controls.ads && !this.reloading ? 1.0 : 0.0;
    this.adsBlend = THREE.MathUtils.lerp(this.adsBlend, targetAds, Math.min(1, dt * 14));

    const def = slot.def;
    const px = THREE.MathUtils.lerp(def.hipPos[0], def.adsPos[0], this.adsBlend);
    const py = THREE.MathUtils.lerp(def.hipPos[1], def.adsPos[1], this.adsBlend);
    const pz = THREE.MathUtils.lerp(def.hipPos[2], def.adsPos[2], this.adsBlend);

    const speed = Math.hypot(player.velocity.x, player.velocity.z);
    if (player.onGround && speed > 0.4) {
      this.bobT += dt * (player.isSprinting ? 13 : 8.5);
    } else {
      this.bobT += dt * 1.5;
    }
    const bobScale = (1.0 - this.adsBlend * 0.82) * (speed > 0.4 ? 0.012 : 0.0025);
    const bobX = Math.cos(this.bobT * 0.5) * bobScale;
    const bobY = Math.abs(Math.sin(this.bobT)) * bobScale;

    this.kickZ = THREE.MathUtils.lerp(this.kickZ, 0, Math.min(1, dt * 15));
    this.kickRotX = THREE.MathUtils.lerp(this.kickRotX, 0, Math.min(1, dt * 14));
    this.boltKick = THREE.MathUtils.lerp(this.boltKick, 0, Math.min(1, dt * 18));

    // Animate Bolt / Slide / Shotgun Pump
    if (slot.boltNode && slot.boltBasePos) {
      slot.boltNode.position.set(
        slot.boltBasePos.x,
        slot.boltBasePos.y,
        slot.boltBasePos.z + this.boltKick * 0.075
      );
    }

    // Reload tilt & sprint lower pose
    let rotX = -this.kickRotX;
    let rotZ = 0;
    let rotY = 0;
    if (this.reloading) {
      rotZ = 0.36;
      rotX = 0.18;
    } else if (player.isSprinting && this.adsBlend < 0.2) {
      rotX = -0.22;
      rotY = 0.32;
      rotZ = -0.15;
    }

    this.weaponPivot.position.set(px + bobX, py - bobY, pz + this.kickZ);
    this.weaponPivot.rotation.set(rotX, rotY, rotZ);

    // Position 1st-person Gloved Hands (`ArmL`, `ArmR`) onto active weapon grips!
    if (this.armR) {
      this.armR.position.copy(slot.gripRPos);
    }
    if (this.armL) {
      if (this.reloading && slot.magNode) {
        this.armL.position.copy(slot.magNode.position).add(new THREE.Vector3(-0.02, -0.05, 0.02));
      } else {
        this.armL.position.copy(slot.gripLPos);
      }
    }
  }

  _updateProjectiles(dt, player, cameraSys, enemyMgr, vehicleMgr) {
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const pr = this.projectiles[i];
      pr.age += dt;
      const step = pr.vel.clone().multiplyScalar(dt);
      const stepLen = step.length();
      const dir = pr.vel.clone().normalize();

      // Smoke trail behind flying rocket/shell
      pr.smokeAcc += dt;
      if (pr.smokeAcc >= 0.035) {
        pr.smokeAcc = 0;
        this.world.spawnPuff(pr.pos, {
          color: 0xd6cfc2,
          size: 0.45,
          vel: new THREE.Vector3((Math.random() - 0.5) * 0.6, 0.5, (Math.random() - 0.5) * 0.6),
          life: 0.65,
          grow: 2.0,
        });
      }

      // Check collision along step
      this._raycaster.set(pr.pos, dir);
      this._raycaster.far = stepLen + 0.4;
      let hitPoint = null;

      const envHits = this._raycaster.intersectObjects(this.world.staticCollidersMeshList, false);
      if (envHits.length > 0) hitPoint = envHits[0].point;

      if (!hitPoint && pr.owner === 'player' && vehicleMgr) {
        const vh = vehicleMgr.raycastVehicles(pr.pos, dir, stepLen + 0.8, 'enemy');
        if (vh) hitPoint = vh.point;
      }
      if (!hitPoint && pr.owner === 'player' && enemyMgr) {
        const eh = enemyMgr.raycastEnemies(pr.pos, dir, stepLen + 0.6);
        if (eh) hitPoint = eh.point;
      }

      pr.pos.add(step);
      pr.vel.y -= 2.8 * dt; // subtle ballistic drop
      pr.mesh.position.copy(pr.pos);

      const terrainY = this.world.getTerrainHeight(pr.pos.x, pr.pos.z);
      if (!hitPoint && pr.pos.y <= terrainY + 0.15) {
        hitPoint = new THREE.Vector3(pr.pos.x, terrainY, pr.pos.z);
      }

      if (hitPoint || pr.age > 5.5) {
        const boomPos = hitPoint || pr.pos;
        this.world.spawnExplosion(boomPos, pr.scale, true);

        // Camera screen shake scaled by distance
        if (player) {
          const distP = player.position.distanceTo(boomPos);
          if (distP < 42) {
            cameraSys.addShake((1.0 - distP / 42) * 0.85);
          }
          if (pr.owner !== 'player' && distP < pr.radius) {
            const falloff = 1.0 - distP / pr.radius;
            player.takeDamage(pr.damage * falloff, boomPos);
          }
        }

        if (enemyMgr) {
          const kills = enemyMgr.applyExplosionDamage(boomPos, pr.radius, pr.damage, pr.owner === 'player');
          if (kills > 0 && pr.owner === 'player' && this.onHitEnemy) {
            for (let k = 0; k < kills; k++) {
              this.onHitEnemy({ isHeadshot: false, killed: true });
            }
          }
        }
        if (vehicleMgr) {
          const vKills = vehicleMgr.applyExplosionDamage(boomPos, pr.radius + 2.0, pr.damage, pr.owner);
          if (vKills > 0 && pr.owner === 'player' && this.onHitEnemy) {
            for (let k = 0; k < vKills; k++) {
              this.onHitEnemy({ isHeadshot: false, killed: true, isVehicle: true });
            }
          }
        }

        this.scene.remove(pr.mesh);
        this.projectiles.splice(i, 1);
      }
    }
  }

  _updateCasings(dt) {
    for (let i = this.casings.length - 1; i >= 0; i--) {
      const c = this.casings[i];
      c.age += dt;
      c.vel.y -= 14 * dt;
      c.mesh.position.addScaledVector(c.vel, dt);
      c.mesh.rotation.x += dt * 16;
      c.mesh.rotation.z += dt * 12;
      if (c.age > 0.85) {
        this.scene.remove(c.mesh);
        this.casings.splice(i, 1);
      }
    }
  }
}
