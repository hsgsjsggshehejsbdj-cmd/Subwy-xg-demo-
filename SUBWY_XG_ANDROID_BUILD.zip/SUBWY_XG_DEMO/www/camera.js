// camera.js — Dual-Perspective (FPS & TPS), Vehicle Chase, Cutscene & Menu Camera Controller
import * as THREE from 'three';

export class CameraSystem {
  constructor(aspect = window.innerWidth / window.innerHeight) {
    this.camera = new THREE.PerspectiveCamera(72, aspect, 0.08, 520);
    this.camera.rotation.order = 'YXZ';

    // Modes: 'FPS' | 'TPS'
    this.perspective = 'FPS';
    // Active state override: 'MENU' | 'CUTSCENE' | 'GAME' | 'VEHICLE'
    this.state = 'MENU';

    this.baseFov = 72;
    this.targetFov = 72;

    // Camera recoil & screen-shake accumulators
    this.recoilPitch = 0;
    this.recoilYaw = 0;
    this.shakeAmount = 0;
    this.bobPhase = 0;

    // Menu / Armory smooth camera targets
    this.menuFocus = 'HOME'; // 'HOME' | 'LOADOUT' | 'SOLDIERS' | 'VEHICLES'
    this.menuTime = 0;
    this._menuPos = new THREE.Vector3(0, 2.2, 6.5);
    this._menuLook = new THREE.Vector3(0, 1.35, 0);
    this._desiredPos = new THREE.Vector3();
    this._desiredLook = new THREE.Vector3();

    // Cutscene spline state
    this.cutsceneFromPos = new THREE.Vector3();
    this.cutsceneToPos = new THREE.Vector3();
    this.cutsceneLookAt = new THREE.Vector3();
    this.cutsceneProgress = 0;

    // Temp vectors (zero GC allocation per frame)
    this._pivot = new THREE.Vector3();
    this._back = new THREE.Vector3();
    this._right = new THREE.Vector3();
    this._raycaster = new THREE.Raycaster();
  }

  onResize(width, height) {
    this.camera.aspect = Math.max(0.5, width / Math.max(1, height));
    this.camera.updateProjectionMatrix();
  }

  togglePerspective() {
    this.perspective = this.perspective === 'FPS' ? 'TPS' : 'FPS';
    return this.perspective;
  }

  setPerspective(mode) {
    if (mode === 'FPS' || mode === 'TPS') {
      this.perspective = mode;
    }
    return this.perspective;
  }

  addRecoil(pitchUp, yawSide) {
    this.recoilPitch += pitchUp;
    this.recoilYaw += yawSide;
  }

  addShake(intensity) {
    this.shakeAmount = Math.min(1.2, this.shakeAmount + intensity);
  }

  setMenuFocus(focusName) {
    if (this.menuFocus !== focusName) {
      this._snapMenuNext = true;
    }
    this.menuFocus = focusName;
  }

  startCutscene(fromPos, toPos, lookTarget) {
    this.state = 'CUTSCENE';
    this.cutsceneFromPos.copy(fromPos);
    this.cutsceneToPos.copy(toPos);
    this.cutsceneLookAt.copy(lookTarget);
    this.cutsceneProgress = 0;
  }

  update(dt, { player, world, activeVehicle, weaponDef, isAds }) {
    // Decay shake & recoil recovery
    this.shakeAmount = Math.max(0, this.shakeAmount - dt * 2.4);
    const shakeX = (Math.random() - 0.5) * 0.14 * this.shakeAmount;
    const shakeY = (Math.random() - 0.5) * 0.14 * this.shakeAmount;
    this.recoilPitch = THREE.MathUtils.lerp(this.recoilPitch, 0, Math.min(1, dt * 10));
    this.recoilYaw = THREE.MathUtils.lerp(this.recoilYaw, 0, Math.min(1, dt * 10));

    // 1. MAIN MENU & 3D ARMORY TURNTABLE CAMERA
    if (this.state === 'MENU') {
      this.menuTime += dt;
      const anchor = world ? world.menuAnchor : { x: 8, y: 0, z: 122 };
      const isRtl = document.documentElement.dir === 'rtl';
      const panelShift = isRtl ? 0.52 : -0.52;

      if (this.menuFocus === 'HOME') {
        const swayX = Math.sin(this.menuTime * 0.28) * 0.75;
        const swayY = Math.cos(this.menuTime * 0.22) * 0.12;
        this._desiredPos.set(anchor.x + swayX, anchor.y + 1.48 + swayY, anchor.z + 3.25);
        this._desiredLook.set(anchor.x + (isRtl ? 0.45 : -0.45), anchor.y + 1.28, anchor.z - 1.5);
        this.targetFov = 48;
      } else if (this.menuFocus === 'SOLDIERS') {
        this._desiredPos.set(anchor.x, anchor.y + 1.32, anchor.z + 2.55);
        this._desiredLook.set(anchor.x + panelShift * 1.1, anchor.y + 1.15, anchor.z);
        this.targetFov = 46;
      } else if (this.menuFocus === 'LOADOUT') {
        const ped = world ? world.pedestalPos : new THREE.Vector3(anchor.x + 5, anchor.y, anchor.z);
        this._desiredPos.set(ped.x, ped.y + 1.50, ped.z + 1.45);
        this._desiredLook.set(ped.x + panelShift * 0.55, ped.y + 1.36, ped.z);
        this.targetFov = 44;
      } else if (this.menuFocus === 'VEHICLES') {
        const vped = world ? world.vehicleStagePos : new THREE.Vector3(anchor.x + 14, anchor.y, anchor.z - 4);
        const orbit = this.menuTime * 0.32;
        this._desiredPos.set(
          vped.x + Math.sin(orbit) * 8.2,
          vped.y + 3.2,
          vped.z + Math.cos(orbit) * 8.2
        );
        this._desiredLook.set(vped.x + panelShift * 2.8, vped.y + 1.25, vped.z);
        this.targetFov = 50;
      } else {
        this._desiredPos.set(anchor.x + 1.5, anchor.y + 1.7, anchor.z + 3.8);
        this._desiredLook.set(anchor.x, anchor.y + 1.3, anchor.z);
        this.targetFov = 50;
      }

      if (this._snapMenuNext || this._menuPos.distanceToSquared(this._desiredPos) > 400) {
        this._menuPos.copy(this._desiredPos);
        this._menuLook.copy(this._desiredLook);
        this._snapMenuNext = false;
      } else {
        this._menuPos.lerp(this._desiredPos, Math.min(1, dt * 6.5));
        this._menuLook.lerp(this._desiredLook, Math.min(1, dt * 7.5));
      }
      this.camera.position.copy(this._menuPos);
      this.camera.position.x += shakeX * 0.3;
      this.camera.position.y += shakeY * 0.3;
      this.camera.lookAt(this._menuLook);
      this._smoothFov(dt);
      return;
    }

    // 2. CINEMATIC MISSION INTRO CAMERA
    if (this.state === 'CUTSCENE') {
      const t = THREE.MathUtils.smoothstep(this.cutsceneProgress, 0, 1);
      this.camera.position.lerpVectors(this.cutsceneFromPos, this.cutsceneToPos, t);
      this.camera.position.y += Math.sin(this.cutsceneProgress * Math.PI) * 1.2;
      this.camera.lookAt(this.cutsceneLookAt);
      this.targetFov = 56;
      this._smoothFov(dt);
      return;
    }

    // 3. DRIVABLE TANK / APC / JEEP 3RD-PERSON CHASE CAMERA
    if (activeVehicle && player) {
      const yaw = player.yaw;
      const pitch = THREE.MathUtils.clamp(player.pitch, -0.35, 0.48);
      const isHeavy = activeVehicle.type === 'tank' || activeVehicle.type === 'apc';
      const dist = isAds ? (isHeavy ? 5.2 : 4.2) : (isHeavy ? 10.2 : 7.6);
      const height = isHeavy ? 3.55 : 2.65;

      this._pivot.copy(activeVehicle.root.position);
      this._pivot.y += height;

      const cosP = Math.cos(pitch);
      this._back.set(Math.sin(yaw) * cosP, -Math.sin(pitch), Math.cos(yaw) * cosP);

      this._desiredPos.copy(this._pivot).addScaledVector(this._back, dist);
      if (world) {
        const groundH = world.getTerrainHeight(this._desiredPos.x, this._desiredPos.z) + 0.85;
        if (this._desiredPos.y < groundH) this._desiredPos.y = groundH;
      }
      this.camera.position.lerp(this._desiredPos, Math.min(1, dt * 14));
      this.camera.position.x += shakeX;
      this.camera.position.y += shakeY;

      // Aim point far forward along yaw/pitch
      this._desiredLook.copy(this._pivot).addScaledVector(this._back, -40);
      this.camera.lookAt(this._desiredLook);
      this.targetFov = isAds ? 44 : 68;
      this._smoothFov(dt);
      return;
    }

    if (!player) return;

    const effYaw = player.yaw + this.recoilYaw;
    const effPitch = THREE.MathUtils.clamp(player.pitch + this.recoilPitch, -1.38, 1.38);

    // 4. GAMEPLAY FIRST-PERSON (FPS) OR SNIPER FULL-SCOPE ADS
    const sniperScopeActive = isAds && weaponDef && weaponDef.scopeOverlay;
    if (this.perspective === 'FPS' || sniperScopeActive) {
      const speed = Math.hypot(player.velocity.x, player.velocity.z);
      if (player.onGround && speed > 0.35) {
        this.bobPhase += dt * (player.isSprinting ? 13.5 : 8.8);
      } else {
        this.bobPhase += dt * 1.4;
      }
      const bobAmp = player.onGround && speed > 0.35 ? (isAds ? 0.008 : 0.032) : 0.004;
      const bobY = Math.sin(this.bobPhase) * bobAmp;
      const bobX = Math.cos(this.bobPhase * 0.5) * bobAmp * 0.6;

      this.camera.position.set(
        player.position.x + bobX + shakeX,
        player.position.y + player.currentEyeHeight + bobY + shakeY,
        player.position.z
      );
      this.camera.rotation.set(effPitch, effYaw, 0, 'YXZ');

      if (isAds && weaponDef) {
        this.targetFov = weaponDef.adsFov || 50;
      } else {
        this.targetFov = player.isSprinting ? this.baseFov + 5 : this.baseFov;
      }
      this._smoothFov(dt);
      return;
    }

    // 5. GAMEPLAY THIRD-PERSON (TPS) OVER-THE-SHOULDER ORBIT CAMERA
    const pivotH = player.isCrouching ? 1.12 : 1.54;
    this._pivot.set(player.position.x, player.position.y + pivotH, player.position.z);

    // Right vector in Three.js for yaw around Y: (+cos(yaw), 0, -sin(yaw))
    this._right.set(Math.cos(effYaw), 0, -Math.sin(effYaw));
    const cosP = Math.cos(effPitch);
    // Camera looks along (-sin(yaw)*cosP, sin(pitch), -cos(yaw)*cosP), so vector BEHIND player is opposite:
    this._back.set(Math.sin(effYaw) * cosP, -Math.sin(effPitch), Math.cos(effYaw) * cosP).normalize();

    const shoulderOffset = isAds ? 0.54 : 0.64;
    const armDist = isAds ? 1.62 : 3.15;

    const shoulderOrigin = this._desiredLook.copy(this._pivot).addScaledVector(this._right, shoulderOffset);
    let safeDist = armDist;

    // Anti-wall clip raycast against buildings & terrain
    if (world && world.staticCollidersMeshList && world.staticCollidersMeshList.length > 0) {
      this._raycaster.set(shoulderOrigin, this._back);
      this._raycaster.far = armDist + 0.3;
      const hits = this._raycaster.intersectObjects(world.staticCollidersMeshList, false);
      if (hits.length > 0) {
        safeDist = Math.max(0.55, hits[0].distance - 0.25);
      }
    }

    this._desiredPos.copy(shoulderOrigin).addScaledVector(this._back, safeDist);
    if (world) {
      const floorH = world.getFloorHeightAt(this._desiredPos.x, this._desiredPos.z, this._desiredPos.y) + 0.28;
      if (this._desiredPos.y < floorH) this._desiredPos.y = floorH;
    }

    this.camera.position.lerp(this._desiredPos, Math.min(1, dt * 20));
    this.camera.position.x += shakeX;
    this.camera.position.y += shakeY;
    this.camera.rotation.set(effPitch, effYaw, 0, 'YXZ');

    this.targetFov = isAds ? 48 : (player.isSprinting ? 74 : 68);
    this._smoothFov(dt);
  }

  _smoothFov(dt) {
    if (Math.abs(this.camera.fov - this.targetFov) > 0.05) {
      this.camera.fov = THREE.MathUtils.lerp(this.camera.fov, this.targetFov, Math.min(1, dt * 12));
      this.camera.updateProjectionMatrix();
    }
  }
}
