// world.js — 3D Desert & Destroyed City Warzone, LOD/Instancing, Sky/Weather & VFX Pool
import * as THREE from 'three';
import * as SkeletonUtils from './lib/SkeletonUtils.js';

export class WarWorld {
  constructor(scene, renderer, assets, audio) {
    this.scene = scene;
    this.renderer = renderer;
    this.assets = assets; // { models: Map, textures: Map }
    this.audio = audio;

    this.quality = 'HIGH';
    this.timePreset = 'DAY'; // 'DAY' | 'SUNSET' | 'NIGHT'
    this.sandstorm = 0.0;    // 0.0 clear .. 1.0 full sandstorm

    // Collision & AI spatial registries
    this.aabbBoxes = [];               // { minX, maxX, minY, maxY, minZ, maxZ, blockBullets }
    this.elevatedWalkables = [];       // { minX, maxX, minZ, maxZ, yAt(x,z) } for bridge & 2nd-story building ramps/floors
    this.staticCollidersMeshList = []; // Meshes for fast bullet & LOS raycasting
    this.coverPoints = [];             // Vector3 tactical cover positions for AI
    this.ammoCrates = [];              // { pos: Vector3, mesh: Object3D, cooldown: 0 }
    this.buildingFootprints = [];      // For minimap rendering: { x, z, w, d }

    // Main Menu & Armory 3D Showcase anchors
    this.menuAnchor = new THREE.Vector3(8, 0, 122);
    this.pedestalPos = new THREE.Vector3(15.5, 0, 122);
    this.vehicleStagePos = new THREE.Vector3(26, 0, 118);
    this.menuDioramaGroup = new THREE.Group();
    this.armoryWeaponMount = new THREE.Group();
    this.armoryVehicleMount = new THREE.Group();
    this.menuMixers = [];
    this.menuTank = null;
    this.menuJet = null;
    this.menuHeli = null;
    this.menuArtilleryTimer = 1.5;

    // Pooled VFX
    this.tracers = [];
    this.particles = [];
    this.explosions = [];
    this.wreckFires = [];
    this.decalMesh = null;
    this.decalCursor = 0;
    this.maxDecals = 90;
    this._dummy = new THREE.Object3D();

    this._buildLightingAndSky();
    this._buildTerrainAndRoads();
    this._buildBridgeAndTrenches();
    this._buildMilitaryBaseAndDestroyedCity();
    this._buildInstancedPropsAndTrees();
    this._buildVFXPools();
    this._buildMenuDiorama();
  }

  /** Analytical heightmap matching the 3D terrain geometry (with carved trench & wadi ravine) */
  getTerrainHeight(x, z) {
    const roadBlend = THREE.MathUtils.smoothstep(Math.abs(x), 7.5, 18.0);
    const cityFlat = 1.0 - THREE.MathUtils.smoothstep(z, -145, -32) * (1.0 - THREE.MathUtils.smoothstep(Math.abs(x), 42, 68));
    const baseFlat = THREE.MathUtils.smoothstep(z, 86, 102) * (1.0 - THREE.MathUtils.smoothstep(Math.abs(x), 38, 58));
    const flatten = Math.max(1.0 - roadBlend, 1.0 - cityFlat, baseFlat);

    let h =
      Math.sin(x * 0.028) * Math.cos(z * 0.026) * 2.35 +
      Math.sin(x * 0.072 + z * 0.055) * 0.75 +
      Math.cos(x * 0.014 - z * 0.018) * 1.65;
    h *= 1.0 - flatten * 0.92;

    const edge = Math.max(Math.abs(x), Math.abs(z));
    if (edge > 148) {
      h += Math.pow((edge - 148) * 0.14, 1.65);
    }

    // Dry Wadi Canyon Ravine across z in [-13, +13]
    const wadiFactor = Math.exp(-(z * z) / 78.0);
    h -= wadiFactor * 3.4;

    // Dug-in Infantry Trench Network at z in [37, 45], x in [-34, -10] and [10, 34]
    if (Math.abs(z - 41) < 3.4 && Math.abs(x) > 9.5 && Math.abs(x) < 35) {
      h -= 1.35;
    }

    return h;
  }

  /** Returns highest walkable surface (terrain, canyon bridge deck, or 2nd-story building floor/ramp) */
  getFloorHeightAt(x, z, currentFootY = 0) {
    let bestY = this.getTerrainHeight(x, z);
    for (let i = 0; i < this.elevatedWalkables.length; i++) {
      const w = this.elevatedWalkables[i];
      if (x >= w.minX && x <= w.maxX && z >= w.minZ && z <= w.maxZ) {
        const wy = w.yAt(x, z);
        if (wy <= currentFootY + 1.05 && wy > bestY) {
          bestY = wy;
        }
      }
    }
    return bestY;
  }

  _buildLightingAndSky() {
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    const envScene = new THREE.Scene();
    envScene.add(new THREE.HemisphereLight(0x9ec9ff, 0xc29b68, 2.2));
    this.scene.environment = pmrem.fromScene(envScene, 0.04).texture;
    pmrem.dispose();

    this.hemiLight = new THREE.HemisphereLight(0xdbeafe, 0xb0895a, 0.85);
    this.scene.add(this.hemiLight);

    this.sunLight = new THREE.DirectionalLight(0xfff1d6, 2.35);
    this.sunLight.position.set(85, 115, 65);
    this.sunLight.castShadow = true;
    this.sunLight.shadow.mapSize.set(2048, 2048);
    this.sunLight.shadow.camera.near = 10;
    this.sunLight.shadow.camera.far = 340;
    const d = 115;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;
    this.sunLight.shadow.bias = -0.0006;
    this.scene.add(this.sunLight);
    this.scene.add(this.sunLight.target);

    this.scene.fog = new THREE.FogExp2(0xd7bfa0, 0.0038);

    const skyGeo = new THREE.SphereGeometry(440, 32, 20);
    this.skyUniforms = {
      uTopColor: { value: new THREE.Color(0x285a94) },
      uHorizonColor: { value: new THREE.Color(0xe5c89e) },
      uSunDir: { value: new THREE.Vector3(0.55, 0.65, 0.42).normalize() },
      uSunColor: { value: new THREE.Color(0xffe4b5) },
      uTime: { value: 0 },
      uCloudAlpha: { value: 0.34 },
    };
    const skyMat = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      uniforms: this.skyUniforms,
      vertexShader: `
        varying vec3 vWorldPos;
        void main() {
          vec4 wp = modelMatrix * vec4(position, 1.0);
          vWorldPos = wp.xyz;
          gl_Position = projectionMatrix * viewMatrix * wp;
        }
      `,
      fragmentShader: `
        uniform vec3 uTopColor;
        uniform vec3 uHorizonColor;
        uniform vec3 uSunDir;
        uniform vec3 uSunColor;
        uniform float uTime;
        uniform float uCloudAlpha;
        varying vec3 vWorldPos;

        float hash(vec2 p) {
          return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
        }
        float noise(vec2 p) {
          vec2 i = floor(p);
          vec2 f = fract(p);
          f = f * f * (3.0 - 2.0 * f);
          return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
                     mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);
        }
        void main() {
          vec3 dir = normalize(vWorldPos);
          float h = clamp(dir.y, 0.0, 1.0);
          vec3 col = mix(uHorizonColor, uTopColor, pow(h, 0.58));

          float sunAmt = max(dot(dir, normalize(uSunDir)), 0.0);
          col += uSunColor * pow(sunAmt, 14.0) * 0.42;
          col += uSunColor * smoothstep(0.9975, 0.9994, sunAmt) * 1.8;

          if (dir.y > 0.05) {
            vec2 uv = dir.xz / (dir.y + 0.18) * 1.45 + vec2(uTime * 0.015, uTime * 0.007);
            float c = noise(uv) * 0.6 + noise(uv * 2.3) * 0.3 + noise(uv * 5.0) * 0.1;
            float cloud = smoothstep(0.50, 0.82, c) * smoothstep(0.05, 0.25, dir.y);
            vec3 cloudCol = mix(uHorizonColor * 0.92, vec3(1.0, 0.97, 0.92), 0.65);
            col = mix(col, cloudCol, cloud * uCloudAlpha);
          }
          gl_FragColor = vec4(col, 1.0);
        }
      `,
    });
    this.skyDome = new THREE.Mesh(skyGeo, skyMat);
    this.scene.add(this.skyDome);

    const dustCount = 550;
    const dustPos = new Float32Array(dustCount * 3);
    for (let i = 0; i < dustCount; i++) {
      dustPos[i * 3] = (Math.random() - 0.5) * 90;
      dustPos[i * 3 + 1] = Math.random() * 14;
      dustPos[i * 3 + 2] = (Math.random() - 0.5) * 90;
    }
    const dustGeo = new THREE.BufferGeometry();
    dustGeo.setAttribute('position', new THREE.BufferAttribute(dustPos, 3));
    this.dustMat = new THREE.PointsMaterial({
      color: 0xe6c796,
      size: 0.42,
      map: this.assets.textures.get('smoke_puff'),
      transparent: true,
      opacity: 0.25,
      depthWrite: false,
    });
    this.dustPoints = new THREE.Points(dustGeo, this.dustMat);
    this.scene.add(this.dustPoints);

    this.applyAtmosphere('DAY', 0.05);
  }

  applyAtmosphere(preset = 'DAY', sandstormLevel = 0.0) {
    this.timePreset = preset;
    this.sandstorm = THREE.MathUtils.clamp(sandstormLevel, 0, 1);

    if (preset === 'SUNSET') {
      this.skyUniforms.uTopColor.value.setHex(0x1f2b4d);
      this.skyUniforms.uHorizonColor.value.setHex(0xe87b43);
      this.skyUniforms.uSunColor.value.setHex(0xff9248);
      this.skyUniforms.uSunDir.value.set(-0.72, 0.20, -0.58).normalize();
      this.sunLight.color.setHex(0xff9d5c);
      this.sunLight.intensity = 2.1;
      this.sunLight.position.set(-110, 38, -90);
      this.hemiLight.color.setHex(0xffb482);
      this.hemiLight.groundColor.setHex(0x523a28);
      this.hemiLight.intensity = 0.72;
      this.scene.fog.color.setHex(0xc97b52);
    } else if (preset === 'NIGHT') {
      this.skyUniforms.uTopColor.value.setHex(0x050914);
      this.skyUniforms.uHorizonColor.value.setHex(0x142238);
      this.skyUniforms.uSunColor.value.setHex(0x9ec5ff);
      this.skyUniforms.uSunDir.value.set(0.4, 0.75, -0.5).normalize();
      this.sunLight.color.setHex(0x8ab4f8);
      this.sunLight.intensity = 0.65;
      this.sunLight.position.set(60, 110, -75);
      this.hemiLight.color.setHex(0x3b5984);
      this.hemiLight.groundColor.setHex(0x1a1d24);
      this.hemiLight.intensity = 0.45;
      this.scene.fog.color.setHex(0x0f1826);
    } else {
      this.skyUniforms.uTopColor.value.setHex(0x285d9c);
      this.skyUniforms.uHorizonColor.value.setHex(0xe2c79c);
      this.skyUniforms.uSunColor.value.setHex(0xfff0cc);
      this.skyUniforms.uSunDir.value.set(0.55, 0.72, 0.42).normalize();
      this.sunLight.color.setHex(0xfff2d6);
      this.sunLight.intensity = 2.4;
      this.sunLight.position.set(85, 115, 65);
      this.hemiLight.color.setHex(0xdbeafe);
      this.hemiLight.groundColor.setHex(0xb38b59);
      this.hemiLight.intensity = 0.88;
      this.scene.fog.color.setHex(0xd6be99);
    }

    if (this.sandstorm > 0.15) {
      this.scene.fog.color.lerp(new THREE.Color(0xc99f67), this.sandstorm * 0.75);
    }
    this.scene.fog.density = 0.0032 + this.sandstorm * 0.0115;
    this.dustMat.opacity = 0.18 + this.sandstorm * 0.55;
    this.dustMat.size = 0.36 + this.sandstorm * 0.55;

    if (this.audio && this.audio.wantWindAmbience) {
      this.audio.startWindAmbience(this.sandstorm);
    }
  }

  setQuality(quality = 'HIGH', shadowMode = 'HIGH') {
    this.quality = quality;
    const shadowsOn = shadowMode !== 'OFF' && quality !== 'LOW';
    this.renderer.shadowMap.enabled = shadowsOn;
    if (shadowsOn) {
      const sz = shadowMode === 'HIGH' && quality === 'HIGH' ? 2048 : 1024;
      if (this.sunLight.shadow.mapSize.x !== sz) {
        this.sunLight.shadow.mapSize.set(sz, sz);
        if (this.sunLight.shadow.map) {
          this.sunLight.shadow.map.dispose();
          this.sunLight.shadow.map = null;
        }
      }
    }
    this.dustPoints.visible = quality !== 'LOW';
  }

  _buildTerrainAndRoads() {
    const sandDiff = this.assets.textures.get('desert_sand_diff');
    const sandNorm = this.assets.textures.get('desert_sand_norm');
    if (sandDiff) {
      sandDiff.wrapS = sandDiff.wrapT = THREE.RepeatWrapping;
      sandDiff.repeat.set(56, 56);
    }
    if (sandNorm) {
      sandNorm.wrapS = sandNorm.wrapT = THREE.RepeatWrapping;
      sandNorm.repeat.set(56, 56);
    }

    const size = 360;
    const segs = 136;
    const geo = new THREE.PlaneGeometry(size, size, segs, segs);
    geo.rotateX(-Math.PI / 2);

    const pos = geo.attributes.position;
    const colors = new Float32Array(pos.count * 3);
    const cSand = new THREE.Color(0xffffff);
    const cTrench = new THREE.Color(0x7a6244);
    const cCityDirt = new THREE.Color(0x91887c);
    const cRock = new THREE.Color(0x8d7053);
    const tmpCol = new THREE.Color();

    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = pos.getZ(i);
      const y = this.getTerrainHeight(x, z);
      pos.setY(i, y);

      tmpCol.copy(cSand);
      if (z < -35 && Math.abs(x) < 55) {
        tmpCol.lerp(cCityDirt, 0.68);
      } else if (Math.abs(z - 41) < 4.5 && Math.abs(x) > 9 && Math.abs(x) < 36) {
        tmpCol.lerp(cTrench, 0.8);
      } else if (y > 2.4 || y < -1.5) {
        tmpCol.lerp(cRock, 0.55);
      }
      colors[i * 3] = tmpCol.r;
      colors[i * 3 + 1] = tmpCol.g;
      colors[i * 3 + 2] = tmpCol.b;
    }
    geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    geo.computeVertexNormals();

    const terrainMat = new THREE.MeshStandardMaterial({
      map: sandDiff,
      normalMap: sandNorm,
      normalScale: new THREE.Vector2(1.1, 1.1),
      vertexColors: true,
      roughness: 0.92,
      metalness: 0.02,
    });
    this.terrainMesh = new THREE.Mesh(geo, terrainMat);
    this.terrainMesh.receiveShadow = true;
    this.scene.add(this.terrainMesh);
    this.staticCollidersMeshList.push(this.terrainMesh);

    const roadDiff = this.assets.textures.get('asphalt_road_diff');
    const roadNorm = this.assets.textures.get('asphalt_road_norm');
    if (roadDiff) {
      roadDiff.wrapS = roadDiff.wrapT = THREE.RepeatWrapping;
      roadDiff.repeat.set(1, 24);
    }
    if (roadNorm) {
      roadNorm.wrapS = roadNorm.wrapT = THREE.RepeatWrapping;
      roadNorm.repeat.set(1, 24);
    }
    const roadMat = new THREE.MeshStandardMaterial({
      map: roadDiff,
      normalMap: roadNorm,
      roughness: 0.84,
      metalness: 0.05,
      polygonOffset: true,
      polygonOffsetFactor: -2,
    });

    const addRoadStrip = (cx, cz, width, length, segZ = 40, rotY = 0) => {
      const rg = new THREE.PlaneGeometry(width, length, 4, segZ);
      rg.rotateX(-Math.PI / 2);
      if (rotY) rg.rotateY(rotY);
      const rp = rg.attributes.position;
      for (let i = 0; i < rp.count; i++) {
        const wx = cx + rp.getX(i);
        const wz = cz + rp.getZ(i);
        rp.setY(i, this.getTerrainHeight(wx, wz) + 0.06);
      }
      rg.computeVertexNormals();
      const rm = new THREE.Mesh(rg, roadMat);
      rm.position.set(cx, 0, cz);
      rm.receiveShadow = true;
      this.scene.add(rm);
    };

    addRoadStrip(0, 72, 10.5, 114, 34);
    addRoadStrip(0, -82, 11.5, 134, 40);
    addRoadStrip(0, -78, 10.0, 88, 26, Math.PI / 2);
  }

  _buildBridgeAndTrenches() {
    const concDiff = this.assets.textures.get('concrete_ruin_diff');
    const concNorm = this.assets.textures.get('concrete_ruin_norm');
    if (concDiff) {
      concDiff.wrapS = concDiff.wrapT = THREE.RepeatWrapping;
      concDiff.repeat.set(3, 6);
    }
    const bridgeMat = new THREE.MeshStandardMaterial({
      map: concDiff,
      normalMap: concNorm,
      roughness: 0.85,
      metalness: 0.1,
    });

    const bridgeDeckY = 0.45;
    const deck = new THREE.Mesh(new THREE.BoxGeometry(13.0, 0.65, 32.0), bridgeMat);
    deck.position.set(0, bridgeDeckY - 0.3, 0);
    deck.castShadow = true;
    deck.receiveShadow = true;
    this.scene.add(deck);
    this.staticCollidersMeshList.push(deck);

    this.elevatedWalkables.push({
      minX: -6.5,
      maxX: 6.5,
      minZ: -19.5,
      maxZ: 19.5,
      yAt: (x, z) => {
        const az = Math.abs(z);
        if (az <= 15.5) return bridgeDeckY;
        const t = 1.0 - (az - 15.5) / 4.0;
        const th = this.getTerrainHeight(x, z);
        return THREE.MathUtils.lerp(th, bridgeDeckY, THREE.MathUtils.clamp(t, 0, 1));
      },
    });

    for (const sx of [-6.05, 6.05]) {
      const rail = new THREE.Mesh(new THREE.BoxGeometry(0.75, 1.25, 31.5), bridgeMat);
      rail.position.set(sx, bridgeDeckY + 0.6, 0);
      rail.castShadow = true;
      rail.receiveShadow = true;
      this.scene.add(rail);
      this.staticCollidersMeshList.push(rail);
      this._addAABB(sx - 0.4, sx + 0.4, bridgeDeckY, bridgeDeckY + 1.3, -15.8, 15.8);
    }
    for (const pz of [-7.5, 7.5]) {
      for (const px of [-4.2, 4.2]) {
        const pier = new THREE.Mesh(new THREE.BoxGeometry(1.4, 5.2, 1.4), bridgeMat);
        pier.position.set(px, bridgeDeckY - 2.8, pz);
        pier.castShadow = true;
        this.scene.add(pier);
      }
    }

    const woodMat = new THREE.MeshStandardMaterial({ color: 0x5c4228, roughness: 0.9 });
    for (const tx of [-28, -20, -13, 13, 20, 28]) {
      const plank = new THREE.Mesh(new THREE.BoxGeometry(6.2, 0.12, 1.8), woodMat);
      const ty = this.getTerrainHeight(tx, 41);
      plank.position.set(tx, ty + 0.06, 41);
      plank.receiveShadow = true;
      this.scene.add(plank);
      this.coverPoints.push(new THREE.Vector3(tx, ty, 41.4));
    }
  }

  _buildMilitaryBaseAndDestroyedCity() {
    const barrierPositions = [
      [-14, 102, 0], [-9, 102, 0], [9, 102, 0], [14, 102, 0],
      [-22, 112, Math.PI / 2], [22, 112, Math.PI / 2],
      [-24, 37.5, 0], [-15, 37.5, 0], [15, 37.5, 0], [24, 37.5, 0],
      [-9, 20, 0.25], [9, 20, -0.25], [-9, -21, -0.2], [9, -21, 0.2],
      [-6, -52, 0.15], [7, -56, -0.2], [-10, -76, 0.4], [10, -76, -0.4],
      [-5, -96, 0], [5, -96, 0], [-14, -118, 0.2], [14, -118, -0.2],
    ];
    for (const [bx, bz, rotY] of barrierPositions) {
      this._placeBarrier(bx, bz, rotY);
    }

    const towers = [
      [-20, 106, 0],
      [17, -25, Math.PI * 0.15],
      [-26, -116, 0],
      [26, -116, 0],
    ];
    for (const [tx, tz, rotY] of towers) {
      this._placeWatchtower(tx, tz, rotY);
    }

    const buildings = [
      { type: 'env_building_ruin1', x: -19, z: -54, rotY: 0 },
      { type: 'env_building_ruin2', x: 19,  z: -54, rotY: Math.PI },
      { type: 'env_building_ruin1', x: 21,  z: -74, rotY: -Math.PI / 2 },
      { type: 'env_building_ruin2', x: -21, z: -74, rotY: Math.PI / 2 },
      { type: 'env_building_ruin1', x: -19, z: -98, rotY: 0 },
      { type: 'env_building_ruin2', x: 19,  z: -98, rotY: 0 },
      { type: 'env_building_ruin1', x: 0,   z: -132, rotY: 0 },
      { type: 'env_building_ruin2', x: -34, z: -124, rotY: 0.2 },
    ];
    for (const b of buildings) {
      this._placeRuinedBuilding(b.type, b.x, b.z, b.rotY);
    }

    const wrecks = [
      [-5.2, 26, 0.45],
      [6.4, -38, -0.65],
      [-8.5, -66, 1.1],
      [11.0, -88, -0.35],
      [-13.0, -112, 0.8],
    ];
    const wreckTpl = this.assets.models.get('env_wreck');
    for (const [wx, wz, rotY] of wrecks) {
      const wy = this.getTerrainHeight(wx, wz);
      if (wreckTpl) {
        const wm = wreckTpl.scene.clone(true);
        wm.position.set(wx, wy, wz);
        wm.rotation.y = rotY;
        wm.traverse((c) => {
          if (c.isMesh) {
            c.castShadow = true;
            c.receiveShadow = true;
            this.staticCollidersMeshList.push(c);
          }
        });
        this.scene.add(wm);
      }
      this._addAABB(wx - 1.3, wx + 1.3, wy, wy + 1.5, wz - 2.1, wz + 2.1);
      this.coverPoints.push(new THREE.Vector3(wx + 2.0, wy, wz));
      this.coverPoints.push(new THREE.Vector3(wx - 2.0, wy, wz));
      this.wreckFires.push(new THREE.Vector3(wx, wy + 0.9, wz));
    }

    const crateCoords = [
      [4.5, 114],
      [-4.5, 42],
      [4.2, -23],
      [-7.5, -72],
      [0, -108],
    ];
    const crateTpl = this.assets.models.get('env_crate');
    for (const [cx, cz] of crateCoords) {
      const cy = this.getTerrainHeight(cx, cz);
      if (crateTpl) {
        const cm = crateTpl.scene.clone(true);
        cm.position.set(cx, cy, cz);
        cm.traverse((c) => { if (c.isMesh) c.castShadow = true; });
        this.scene.add(cm);
        this.ammoCrates.push({ pos: new THREE.Vector3(cx, cy, cz), mesh: cm, cooldown: 0 });
      }
    }

    const truckTpl = this.assets.models.get('vehicle_truck');
    if (truckTpl) {
      const tr = truckTpl.scene.clone(true);
      const ty = this.getTerrainHeight(-13, 124);
      tr.position.set(-13, ty, 124);
      tr.rotation.y = 0.32;
      tr.traverse((c) => {
        if (c.isMesh) {
          c.castShadow = true;
          c.receiveShadow = true;
          this.staticCollidersMeshList.push(c);
        }
      });
      this.scene.add(tr);
      this._addAABB(-15.2, -10.8, ty, ty + 3.2, 120.2, 127.8);
    }
  }

  _placeBarrier(x, z, rotY = 0) {
    const tpl = this.assets.models.get('env_barrier');
    const y = this.getTerrainHeight(x, z);
    if (tpl) {
      const m = tpl.scene.clone(true);
      m.position.set(x, y, z);
      m.rotation.y = rotY;
      m.traverse((c) => {
        if (c.isMesh) {
          c.castShadow = true;
          c.receiveShadow = true;
          this.staticCollidersMeshList.push(c);
        }
      });
      this.scene.add(m);
    }
    const halfX = Math.abs(Math.cos(rotY)) * 1.75 + Math.abs(Math.sin(rotY)) * 0.6;
    const halfZ = Math.abs(Math.sin(rotY)) * 1.75 + Math.abs(Math.cos(rotY)) * 0.6;
    this._addAABB(x - halfX, x + halfX, y, y + 1.42, z - halfZ, z + halfZ);
    const nx = Math.sin(rotY) * 1.35;
    const nz = Math.cos(rotY) * 1.35;
    this.coverPoints.push(new THREE.Vector3(x + nx, y, z + nz));
    this.coverPoints.push(new THREE.Vector3(x - nx, y, z - nz));
  }

  _placeWatchtower(x, z, rotY = 0) {
    const tpl = this.assets.models.get('env_watchtower');
    const y = this.getTerrainHeight(x, z);
    if (tpl) {
      const lod = new THREE.LOD();
      const hi = tpl.scene.clone(true);
      hi.traverse((c) => {
        if (c.isMesh) {
          c.castShadow = true;
          c.receiveShadow = true;
          this.staticCollidersMeshList.push(c);
        }
      });
      const lo = new THREE.Mesh(
        new THREE.BoxGeometry(3.4, 9.0, 3.4),
        new THREE.MeshStandardMaterial({ color: 0x8a795d, roughness: 0.9 })
      );
      lo.position.y = 4.5;
      lod.addLevel(hi, 0);
      lod.addLevel(lo, 135);
      lod.position.set(x, y, z);
      lod.rotation.y = rotY;
      this.scene.add(lod);
    }
    this._addAABB(x - 1.75, x + 1.75, y, y + 7.5, z - 1.75, z + 1.75);
    this.buildingFootprints.push({ x, z, w: 3.8, d: 3.8 });
  }

  _placeRuinedBuilding(modelKey, x, z, rotY = 0) {
    const tpl = this.assets.models.get(modelKey);
    const y = this.getTerrainHeight(x, z);
    const isRuin1 = modelKey === 'env_building_ruin1';
    const w = isRuin1 ? 12.0 : 10.0;
    const d = isRuin1 ? 10.0 : 8.0;

    if (tpl) {
      const lod = new THREE.LOD();
      const hi = tpl.scene.clone(true);
      hi.traverse((c) => {
        if (c.isMesh) {
          c.castShadow = true;
          c.receiveShadow = true;
          this.staticCollidersMeshList.push(c);
        }
      });
      const lo = new THREE.Mesh(
        new THREE.BoxGeometry(w, 7.2, d),
        new THREE.MeshStandardMaterial({ color: 0x7b756c, roughness: 0.92 })
      );
      lo.position.y = 3.6;
      lod.addLevel(hi, 0);
      lod.addLevel(lo, 135);
      lod.position.set(x, y, z);
      lod.rotation.y = rotY;
      this.scene.add(lod);
    }

    const rot90 = Math.abs(Math.sin(rotY)) > 0.7;
    const bw = rot90 ? d : w;
    const bd = rot90 ? w : d;
    this.buildingFootprints.push({ x, z, w: bw, d: bd });

    this.elevatedWalkables.push({
      minX: x - bw * 0.48,
      maxX: x + bw * 0.48,
      minZ: z - bd * 0.48,
      maxZ: z + bd * 0.48,
      yAt: () => y + 0.36,
    });

    if (isRuin1 && !rot90) {
      this.elevatedWalkables.push({
        minX: x + 2.8,
        maxX: x + 5.5,
        minZ: z - 3.8,
        maxZ: z + 2.2,
        yAt: (_px, pz) => {
          const t = (pz - (z - 3.8)) / 6.0;
          return y + THREE.MathUtils.lerp(0.36, 4.16, THREE.MathUtils.clamp(t, 0, 1));
        },
      });
      this.elevatedWalkables.push({
        minX: x - 5.6,
        maxX: x + 2.8,
        minZ: z - 4.7,
        maxZ: z + 4.7,
        yAt: () => y + 4.16,
      });
      this._addAABB(x - 6.0, x - 5.55, y, y + 7.5, z - 5.0, z + 5.0);
      this._addAABB(x + 5.55, x + 6.0, y, y + 4.5, z - 5.0, z + 5.0);
      this._addAABB(x - 6.0, x - 1.5, y, y + 4.0, z + 4.55, z + 5.05);
      this._addAABB(x + 1.5, x + 6.0, y, y + 4.0, z + 4.55, z + 5.05);
      this._addAABB(x - 6.0, x - 1.3, y, y + 6.5, z - 5.05, z - 4.55);
      this._addAABB(x + 1.7, x + 6.0, y, y + 5.0, z - 5.05, z - 4.55);
    } else {
      this._addAABB(x - bw * 0.5, x - bw * 0.44, y, y + 6.2, z - bd * 0.5, z + bd * 0.5);
      this._addAABB(x - bw * 0.5, x + bw * 0.5, y, y + 5.8, z - bd * 0.5, z - bd * 0.43);
    }

    this.coverPoints.push(new THREE.Vector3(x - bw * 0.52, y, z + bd * 0.52));
    this.coverPoints.push(new THREE.Vector3(x + bw * 0.52, y, z + bd * 0.52));
    this.coverPoints.push(new THREE.Vector3(x - 2.2, y + 0.36, z + bd * 0.38));
  }

  _buildInstancedPropsAndTrees() {
    const rockTpl = this.assets.models.get('env_rock');
    let rockMeshSrc = null;
    if (rockTpl) {
      rockTpl.scene.traverse((c) => { if (c.isMesh && !rockMeshSrc) rockMeshSrc = c; });
    }
    if (rockMeshSrc) {
      const rockCount = 110;
      const instRocks = new THREE.InstancedMesh(rockMeshSrc.geometry, rockMeshSrc.material, rockCount);
      instRocks.castShadow = true;
      instRocks.receiveShadow = true;
      let idx = 0;
      for (let i = 0; i < 160 && idx < rockCount; i++) {
        const s1 = Math.sin(i * 12.9898) * 43758.5453;
        const s2 = Math.sin(i * 78.233 + 1.7) * 24634.6345;
        const rx = ((s1 - Math.floor(s1)) - 0.5) * 310;
        const rz = ((s2 - Math.floor(s2)) - 0.5) * 310;
        if (Math.abs(rx) < 15) continue;
        if (rz > 92 && Math.abs(rx) < 32) continue;
        if (rz < -42 && Math.abs(rx) < 36) continue;

        const ry = this.getTerrainHeight(rx, rz);
        const scale = 0.65 + ((i * 17) % 10) * 0.14;
        this._dummy.position.set(rx, ry - 0.15, rz);
        this._dummy.rotation.set(0, i * 1.1, 0);
        this._dummy.scale.set(scale, scale * 0.85, scale);
        this._dummy.updateMatrix();
        instRocks.setMatrixAt(idx++, this._dummy.matrix);

        if (scale > 1.25) {
          this._addAABB(rx - scale, rx + scale, ry, ry + scale * 1.4, rz - scale, rz + scale);
          this.coverPoints.push(new THREE.Vector3(rx, ry, rz + scale + 0.8));
        }
      }
      instRocks.count = idx;
      instRocks.instanceMatrix.needsUpdate = true;
      this.scene.add(instRocks);
    }

    const treeTpl = this.assets.models.get('env_tree');
    if (treeTpl) {
      const treeCoords = [
        [-22, 14], [-28, 8], [-19, -14], [21, 12], [27, -11], [34, 6],
        [-32, 96], [30, 98], [-35, 62], [33, 58], [-15, -34], [15, -34],
        [-32, -62], [32, -64], [-34, -92], [34, -90], [-28, 128], [28, 126],
      ];
      for (let i = 0; i < treeCoords.length; i++) {
        const [tx, tz] = treeCoords[i];
        const ty = this.getTerrainHeight(tx, tz);
        const tClone = treeTpl.scene.clone(true);
        tClone.position.set(tx, ty - 0.1, tz);
        tClone.rotation.y = i * 1.3;
        const sc = 0.85 + (i % 4) * 0.12;
        tClone.scale.setScalar(sc);
        tClone.traverse((c) => { if (c.isMesh) c.castShadow = true; });
        this.scene.add(tClone);
        this._addAABB(tx - 0.35, tx + 0.35, ty, ty + 5.2, tz - 0.35, tz + 0.35);
      }
    }
  }

  _buildVFXPools() {
    const decalGeo = new THREE.PlaneGeometry(0.24, 0.24);
    const decalMat = new THREE.MeshBasicMaterial({
      map: this.assets.textures.get('bullet_hole'),
      transparent: true,
      depthWrite: false,
      polygonOffset: true,
      polygonOffsetFactor: -4,
    });
    this.decalMesh = new THREE.InstancedMesh(decalGeo, decalMat, this.maxDecals);
    this.decalMesh.frustumCulled = false;
    this._dummy.scale.set(0, 0, 0);
    this._dummy.updateMatrix();
    for (let i = 0; i < this.maxDecals; i++) {
      this.decalMesh.setMatrixAt(i, this._dummy.matrix);
    }
    this.scene.add(this.decalMesh);

    this.explosionLight = new THREE.PointLight(0xff7b24, 0, 42);
    this.scene.add(this.explosionLight);
  }

  _buildMenuDiorama() {
    const ay = this.getTerrainHeight(this.menuAnchor.x, this.menuAnchor.z);
    this.menuAnchor.y = ay;
    this.pedestalPos.y = this.getTerrainHeight(this.pedestalPos.x, this.pedestalPos.z);
    this.vehicleStagePos.y = this.getTerrainHeight(this.vehicleStagePos.x, this.vehicleStagePos.z);

    this.scene.add(this.menuDioramaGroup);

    const allyGltf = this.assets.models.get('soldier_ally');
    if (allyGltf) {
      this.menuSoldier = SkeletonUtils.clone(allyGltf.scene);
      this.menuSoldier.position.set(this.menuAnchor.x, ay, this.menuAnchor.z);
      this.menuSoldier.rotation.y = 0.24;
      this.menuSoldier.traverse((c) => {
        if (c.isMesh) {
          c.castShadow = true;
          c.receiveShadow = true;
        }
      });
      this.menuDioramaGroup.add(this.menuSoldier);

      if (allyGltf.animations && allyGltf.animations.length > 0) {
        const mixer = new THREE.AnimationMixer(this.menuSoldier);
        const idleClip = allyGltf.animations.find((a) => a.name === 'Idle') || allyGltf.animations[0];
        if (idleClip) mixer.clipAction(idleClip).play();
        this.menuMixers.push(mixer);
      }
    }

    const rimLight = new THREE.PointLight(0xff7a1a, 4.5, 14);
    rimLight.position.set(this.menuAnchor.x - 2.2, ay + 2.4, this.menuAnchor.z - 2.4);
    this.menuDioramaGroup.add(rimLight);

    const fillLight = new THREE.PointLight(0x60a5fa, 2.2, 10);
    fillLight.position.set(this.menuAnchor.x + 2.2, ay + 1.9, this.menuAnchor.z + 2.2);
    this.menuDioramaGroup.add(fillLight);

    const tankGltf = this.assets.models.get('vehicle_tank');
    if (tankGltf) {
      this.menuTank = tankGltf.scene.clone(true);
      this.menuTank.traverse((c) => { if (c.isMesh) c.castShadow = true; });
      this.menuDioramaGroup.add(this.menuTank);
    }

    const jetGltf = this.assets.models.get('vehicle_jet');
    if (jetGltf) {
      this.menuJet = jetGltf.scene.clone(true);
      this.menuDioramaGroup.add(this.menuJet);
    }
    const heliGltf = this.assets.models.get('vehicle_heli');
    if (heliGltf) {
      this.menuHeli = heliGltf.scene.clone(true);
      this.menuDioramaGroup.add(this.menuHeli);
    }

    const pedBase = new THREE.Mesh(
      new THREE.CylinderGeometry(0.65, 0.78, 1.15, 20),
      new THREE.MeshStandardMaterial({ color: 0x161e29, metalness: 0.7, roughness: 0.3 })
    );
    pedBase.position.set(this.pedestalPos.x, this.pedestalPos.y + 0.57, this.pedestalPos.z);
    this.menuDioramaGroup.add(pedBase);

    this.armoryWeaponMount.position.set(this.pedestalPos.x, this.pedestalPos.y + 1.38, this.pedestalPos.z);
    this.menuDioramaGroup.add(this.armoryWeaponMount);

    const pedLight = new THREE.PointLight(0xfbbf24, 3.2, 8);
    pedLight.position.set(this.pedestalPos.x, this.pedestalPos.y + 2.4, this.pedestalPos.z + 1.2);
    this.menuDioramaGroup.add(pedLight);

    this.armoryVehicleMount.position.copy(this.vehicleStagePos);
    this.menuDioramaGroup.add(this.armoryVehicleMount);
  }

  setMenuDioramaVisible(flag) {
    this.menuDioramaGroup.visible = flag;
  }

  showcaseWeaponModel(weaponKey) {
    while (this.armoryWeaponMount.children.length) {
      this.armoryWeaponMount.remove(this.armoryWeaponMount.children[0]);
    }
    const gltf = this.assets.models.get(`weapon_${weaponKey}`);
    if (!gltf) return;
    const clone = gltf.scene.clone(true);
    clone.scale.setScalar(1.35);
    this.armoryWeaponMount.add(clone);
  }

  showcaseSoldierTint(colorHex) {
    if (!this.menuSoldier) return;
    this.menuSoldier.traverse((c) => {
      if (c.isMesh && c.material && c.material.name && c.material.name.startsWith('VestArmor')) {
        c.material = c.material.clone();
        c.material.color.setHex(colorHex);
      }
    });
  }

  showcaseVehicleModel(vehicleKey) {
    while (this.armoryVehicleMount.children.length) {
      this.armoryVehicleMount.remove(this.armoryVehicleMount.children[0]);
    }
    const gltf = this.assets.models.get(`vehicle_${vehicleKey}`);
    if (!gltf) return;
    const clone = gltf.scene.clone(true);
    if (vehicleKey === 'heli' || vehicleKey === 'jet') {
      clone.position.y = 1.4;
      clone.scale.setScalar(0.75);
    }
    this.armoryVehicleMount.add(clone);
  }

  _addAABB(minX, maxX, minY, maxY, minZ, maxZ, blockBullets = true) {
    this.aabbBoxes.push({ minX, maxX, minY, maxY, minZ, maxZ, blockBullets });
  }

  resolveHorizontalCollision(pos, radius = 0.42, footY = 0, height = 1.7) {
    pos.x = THREE.MathUtils.clamp(pos.x, -162, 162);
    pos.z = THREE.MathUtils.clamp(pos.z, -162, 162);

    const topY = footY + height;
    for (let i = 0; i < this.aabbBoxes.length; i++) {
      const b = this.aabbBoxes[i];
      if (topY <= b.minY + 0.15 || footY >= b.maxY - 0.25) continue;

      const cx = THREE.MathUtils.clamp(pos.x, b.minX, b.maxX);
      const cz = THREE.MathUtils.clamp(pos.z, b.minZ, b.maxZ);
      const dx = pos.x - cx;
      const dz = pos.z - cz;
      const distSq = dx * dx + dz * dz;

      if (distSq < radius * radius) {
        if (distSq > 1e-6) {
          const dist = Math.sqrt(distSq);
          const push = radius - dist;
          pos.x += (dx / dist) * push;
          pos.z += (dz / dist) * push;
        } else {
          const penLeft = Math.abs(pos.x - b.minX);
          const penRight = Math.abs(b.maxX - pos.x);
          const penBack = Math.abs(pos.z - b.minZ);
          const penFront = Math.abs(b.maxZ - pos.z);
          const m = Math.min(penLeft, penRight, penBack, penFront);
          if (m === penLeft) pos.x = b.minX - radius;
          else if (m === penRight) pos.x = b.maxX + radius;
          else if (m === penBack) pos.z = b.minZ - radius;
          else pos.z = b.maxZ + radius;
        }
      }
    }
  }

  hasLineOfSight(p1, p2) {
    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;
    const dz = p2.z - p1.z;
    for (let i = 0; i < this.aabbBoxes.length; i++) {
      const b = this.aabbBoxes[i];
      if (!b.blockBullets) continue;
      let tmin = 0.0;
      let tmax = 1.0;

      if (Math.abs(dx) < 1e-6) {
        if (p1.x < b.minX || p1.x > b.maxX) continue;
      } else {
        let t1 = (b.minX - p1.x) / dx;
        let t2 = (b.maxX - p1.x) / dx;
        if (t1 > t2) { const tmp = t1; t1 = t2; t2 = tmp; }
        tmin = Math.max(tmin, t1);
        tmax = Math.min(tmax, t2);
        if (tmin > tmax) continue;
      }

      if (Math.abs(dy) < 1e-6) {
        if (p1.y < b.minY || p1.y > b.maxY) continue;
      } else {
        let t1 = (b.minY - p1.y) / dy;
        let t2 = (b.maxY - p1.y) / dy;
        if (t1 > t2) { const tmp = t1; t1 = t2; t2 = tmp; }
        tmin = Math.max(tmin, t1);
        tmax = Math.min(tmax, t2);
        if (tmin > tmax) continue;
      }

      if (Math.abs(dz) < 1e-6) {
        if (p1.z < b.minZ || p1.z > b.maxZ) continue;
      } else {
        let t1 = (b.minZ - p1.z) / dz;
        let t2 = (b.maxZ - p1.z) / dz;
        if (t1 > t2) { const tmp = t1; t1 = t2; t2 = tmp; }
        tmin = Math.max(tmin, t1);
        tmax = Math.min(tmax, t2);
        if (tmin > tmax) continue;
      }

      if (tmin <= tmax && tmax > 0.02 && tmin < 0.98) return false;
    }
    return true;
  }

  findNearestCover(fromPos, threatPos, maxSearchDist = 26) {
    let best = null;
    let bestScore = Infinity;
    for (let i = 0; i < this.coverPoints.length; i++) {
      const cp = this.coverPoints[i];
      const d = fromPos.distanceTo(cp);
      if (d > maxSearchDist) continue;
      const testEye = { x: cp.x, y: cp.y + 0.9, z: cp.z };
      const threatEye = { x: threatPos.x, y: threatPos.y + 1.4, z: threatPos.z };
      const exposed = this.hasLineOfSight(testEye, threatEye);
      const score = d + (exposed ? 18 : 0);
      if (score < bestScore) {
        bestScore = score;
        best = cp;
      }
    }
    return best;
  }

  spawnTracer(start, end, colorHex = 0xffd27d) {
    const dir = new THREE.Vector3().subVectors(end, start);
    const len = Math.max(0.5, dir.length());
    const tracerLen = Math.min(4.2, len * 0.45);
    const geo = new THREE.CylinderGeometry(0.018, 0.018, tracerLen, 5);
    geo.rotateX(Math.PI / 2);
    const mat = new THREE.MeshBasicMaterial({ color: colorHex, transparent: true, opacity: 0.92 });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.copy(start);
    mesh.lookAt(end);
    this.scene.add(mesh);
    this.tracers.push({
      mesh,
      start: start.clone(),
      end: end.clone(),
      t: 0,
      speed: Math.max(4.5, 210 / len),
    });
  }

  spawnImpact(point, normal, { isBlood = false } = {}) {
    if (!isBlood && normal && this.decalMesh) {
      this._dummy.position.copy(point).addScaledVector(normal, 0.025);
      const target = point.clone().add(normal);
      this._dummy.lookAt(target);
      this._dummy.scale.setScalar(0.8 + Math.random() * 0.5);
      this._dummy.updateMatrix();
      this.decalMesh.setMatrixAt(this.decalCursor, this._dummy.matrix);
      this.decalMesh.instanceMatrix.needsUpdate = true;
      this.decalCursor = (this.decalCursor + 1) % this.maxDecals;
    }

    const count = this.quality === 'LOW' ? 2 : 5;
    for (let i = 0; i < count; i++) {
      this.spawnPuff(point, {
        color: isBlood ? 0x991b1b : 0xcab38c,
        size: isBlood ? 0.32 : 0.42,
        vel: new THREE.Vector3(
          (Math.random() - 0.5) * 2.6 + (normal ? normal.x * 1.6 : 0),
          Math.random() * 2.2 + (normal ? normal.y * 1.4 : 0.5),
          (Math.random() - 0.5) * 2.6 + (normal ? normal.z * 1.6 : 0)
        ),
        life: 0.42 + Math.random() * 0.25,
      });
    }
  }

  spawnPuff(pos, { color = 0x55524d, size = 0.8, vel = null, life = 1.2, grow = 1.6 } = {}) {
    if (this.particles.length > (this.quality === 'LOW' ? 45 : 140)) return;
    const mat = new THREE.SpriteMaterial({
      map: this.assets.textures.get('smoke_puff'),
      color,
      transparent: true,
      opacity: 0.72,
      depthWrite: false,
    });
    const sp = new THREE.Sprite(mat);
    sp.position.copy(pos);
    sp.scale.setScalar(size);
    this.scene.add(sp);
    this.particles.push({
      sprite: sp,
      vel: vel || new THREE.Vector3((Math.random() - 0.5) * 0.8, 1.4 + Math.random(), (Math.random() - 0.5) * 0.8),
      age: 0,
      life,
      startSize: size,
      grow,
    });
  }

  spawnExplosion(pos, scale = 1.0, playAudio = true) {
    if (playAudio && this.audio) {
      this.audio.playSpatial('explosion_heavy', pos, { volume: 1.0, refDist: 24, maxDist: 320 });
      this.audio.vibrate([45, 30, 85]);
    }

    const core = new THREE.Mesh(
      new THREE.SphereGeometry(1.1 * scale, 12, 10),
      new THREE.MeshBasicMaterial({ color: 0xffaa33, transparent: true, opacity: 0.95 })
    );
    core.position.copy(pos);
    core.position.y += 0.6 * scale;
    this.scene.add(core);

    const ring = new THREE.Mesh(
      new THREE.RingGeometry(0.4 * scale, 1.2 * scale, 20),
      new THREE.MeshBasicMaterial({ color: 0xffd27d, side: THREE.DoubleSide, transparent: true, opacity: 0.85 })
    );
    ring.rotation.x = -Math.PI / 2;
    ring.position.set(pos.x, pos.y + 0.18, pos.z);
    this.scene.add(ring);

    this.explosionLight.position.set(pos.x, pos.y + 2.2, pos.z);
    this.explosionLight.intensity = 12 * scale;

    this.explosions.push({ core, ring, age: 0, life: 0.55, scale });

    const puffCount = this.quality === 'LOW' ? 5 : 12;
    for (let i = 0; i < puffCount; i++) {
      const hot = i < puffCount * 0.4;
      this.spawnPuff(
        new THREE.Vector3(
          pos.x + (Math.random() - 0.5) * 2.2 * scale,
          pos.y + 0.5 + Math.random() * 1.5 * scale,
          pos.z + (Math.random() - 0.5) * 2.2 * scale
        ),
        {
          color: hot ? 0xff6b1a : 0x2a2725,
          size: (hot ? 1.6 : 2.1) * scale,
          vel: new THREE.Vector3(
            (Math.random() - 0.5) * 5.5 * scale,
            (2.8 + Math.random() * 4.5) * scale,
            (Math.random() - 0.5) * 5.5 * scale
          ),
          life: hot ? 0.65 : 2.1,
          grow: 2.4,
        }
      );
    }
  }

  update(dt, focusPos, isMenuMode = false) {
    const t = performance.now() * 0.001;
    this.skyUniforms.uTime.value = t;

    if (focusPos) {
      this.skyDome.position.set(focusPos.x, 0, focusPos.z);
      this.sunLight.target.position.set(focusPos.x, 0, focusPos.z);
      this.dustPoints.position.set(
        focusPos.x + Math.sin(t * 0.7) * 4,
        0,
        focusPos.z + ((t * (3 + this.sandstorm * 14)) % 18) - 9
      );
    }

    if (this.explosionLight.intensity > 0.05) {
      this.explosionLight.intensity = Math.max(0, this.explosionLight.intensity - dt * 28);
    }

    if (isMenuMode && this.menuDioramaGroup.visible) {
      for (const m of this.menuMixers) m.update(dt);

      this.armoryWeaponMount.rotation.y += dt * 0.75;
      this.armoryVehicleMount.rotation.y += dt * 0.35;

      if (this.menuTank) {
        const tz = 108 - ((t * 4.2) % 34);
        const tx = -4.5;
        const ty = this.getTerrainHeight(tx, tz);
        this.menuTank.position.set(tx, ty, tz);
        this.menuTank.rotation.y = Math.PI;
        const tur = this.menuTank.getObjectByName('Turret');
        if (tur) tur.rotation.y = Math.sin(t * 0.6) * 0.45;
      }

      if (this.menuJet) {
        const jz = 160 - ((t * 48) % 260);
        this.menuJet.position.set(-18 + Math.sin(t * 0.4) * 12, 34, jz);
        this.menuJet.rotation.set(0.04, Math.PI, -0.18);
      }
      if (this.menuHeli) {
        const ha = t * 0.38;
        this.menuHeli.position.set(16 + Math.cos(ha) * 22, 16 + Math.sin(t * 1.2) * 0.6, 92 + Math.sin(ha) * 18);
        this.menuHeli.rotation.y = -ha;
        const mr = this.menuHeli.getObjectByName('MainRotor');
        const tr = this.menuHeli.getObjectByName('TailRotor');
        if (mr) mr.rotation.y += dt * 24;
        if (tr) tr.rotation.x += dt * 28;
      }

      this.menuArtilleryTimer -= dt;
      if (this.menuArtilleryTimer <= 0) {
        this.menuArtilleryTimer = 2.6 + Math.random() * 2.4;
        const ex = this.menuAnchor.x - 16 + (Math.random() - 0.5) * 28;
        const ez = this.menuAnchor.z - 28 - Math.random() * 26;
        const ey = this.getTerrainHeight(ex, ez);
        this.spawnExplosion(new THREE.Vector3(ex, ey, ez), 1.35, false);
      }
    }

    if (Math.random() < (this.quality === 'LOW' ? 0.12 : 0.35) && this.wreckFires.length > 0) {
      const wf = this.wreckFires[(Math.random() * this.wreckFires.length) | 0];
      if (!focusPos || wf.distanceToSquared(focusPos) < 130 * 130) {
        this.spawnPuff(wf, {
          color: Math.random() < 0.25 ? 0xe85d04 : 0x262423,
          size: 0.75,
          vel: new THREE.Vector3((Math.random() - 0.5) * 0.7, 1.8 + Math.random(), (Math.random() - 0.5) * 0.7),
          life: 2.0,
          grow: 2.2,
        });
      }
    }

    for (const c of this.ammoCrates) {
      if (c.cooldown > 0) c.cooldown = Math.max(0, c.cooldown - dt);
    }

    for (let i = this.tracers.length - 1; i >= 0; i--) {
      const tr = this.tracers[i];
      tr.t += dt * tr.speed;
      if (tr.t >= 1) {
        this.scene.remove(tr.mesh);
        tr.mesh.geometry.dispose();
        tr.mesh.material.dispose();
        this.tracers.splice(i, 1);
      } else {
        tr.mesh.position.lerpVectors(tr.start, tr.end, tr.t);
      }
    }

    for (let i = this.explosions.length - 1; i >= 0; i--) {
      const ex = this.explosions[i];
      ex.age += dt;
      const k = ex.age / ex.life;
      if (k >= 1) {
        this.scene.remove(ex.core);
        this.scene.remove(ex.ring);
        ex.core.geometry.dispose();
        ex.core.material.dispose();
        ex.ring.geometry.dispose();
        ex.ring.material.dispose();
        this.explosions.splice(i, 1);
      } else {
        ex.core.scale.setScalar(1 + k * 2.4);
        ex.core.material.opacity = (1 - k) * 0.9;
        ex.ring.scale.setScalar(1 + k * 5.2);
        ex.ring.material.opacity = (1 - k) * 0.8;
      }
    }

    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.age += dt;
      const k = p.age / p.life;
      if (k >= 1) {
        this.scene.remove(p.sprite);
        p.sprite.material.dispose();
        this.particles.splice(i, 1);
      } else {
        p.sprite.position.addScaledVector(p.vel, dt);
        p.vel.multiplyScalar(0.96);
        p.sprite.scale.setScalar(p.startSize * (1 + k * p.grow));
        p.sprite.material.opacity = (1 - k) * 0.68;
      }
    }
  }
}
