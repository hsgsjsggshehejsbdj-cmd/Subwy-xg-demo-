// main.js — Core Engine Bootstrap, Progressive Asset Loader & Adaptive 30-60 FPS Game Loop
import * as THREE from 'three';
import { GLTFLoader } from './lib/GLTFLoader.js';
import { AudioEngine } from './audio.js';
import { InputControls } from './controls.js';
import { CameraSystem } from './camera.js';
import { WarWorld } from './world.js';
import { PlayerController } from './player.js';
import { WeaponSystem } from './weapons.js';
import { AIManager } from './enemies.js';
import { VehicleManager } from './vehicles.js';
import { MissionDirector, CAMPAIGN_MISSIONS } from './missions.js';
import { UIManager } from './ui.js';

const MODEL_MANIFEST = [
  ['soldier_ally', './assets/models/soldier_ally.glb'],
  ['soldier_enemy', './assets/models/soldier_enemy.glb'],
  ['fps_arms', './assets/models/fps_arms.glb'],
  ['weapon_ar', './assets/models/weapon_ar.glb'],
  ['weapon_sniper', './assets/models/weapon_sniper.glb'],
  ['weapon_lmg', './assets/models/weapon_lmg.glb'],
  ['weapon_shotgun', './assets/models/weapon_shotgun.glb'],
  ['weapon_pistol', './assets/models/weapon_pistol.glb'],
  ['weapon_rpg', './assets/models/weapon_rpg.glb'],
  ['vehicle_tank', './assets/models/vehicle_tank.glb'],
  ['vehicle_jeep', './assets/models/vehicle_jeep.glb'],
  ['vehicle_truck', './assets/models/vehicle_truck.glb'],
  ['vehicle_apc', './assets/models/vehicle_apc.glb'],
  ['vehicle_heli', './assets/models/vehicle_heli.glb'],
  ['vehicle_jet', './assets/models/vehicle_jet.glb'],
  ['env_building_ruin1', './assets/models/env_building_ruin1.glb'],
  ['env_building_ruin2', './assets/models/env_building_ruin2.glb'],
  ['env_watchtower', './assets/models/env_watchtower.glb'],
  ['env_barrier', './assets/models/env_barrier.glb'],
  ['env_tree', './assets/models/env_tree.glb'],
  ['env_rock', './assets/models/env_rock.glb'],
  ['env_wreck', './assets/models/env_wreck.glb'],
  ['env_crate', './assets/models/env_crate.glb'],
];

const TEXTURE_MANIFEST = [
  ['desert_sand_diff', './assets/textures/desert_sand_diff.jpg', true],
  ['desert_sand_norm', './assets/textures/desert_sand_norm.jpg', false],
  ['asphalt_road_diff', './assets/textures/asphalt_road_diff.jpg', true],
  ['asphalt_road_norm', './assets/textures/asphalt_road_norm.jpg', false],
  ['concrete_ruin_diff', './assets/textures/concrete_ruin_diff.jpg', true],
  ['concrete_ruin_norm', './assets/textures/concrete_ruin_norm.jpg', false],
  ['smoke_puff', './assets/textures/smoke_puff.png', true],
  ['bullet_hole', './assets/textures/bullet_hole.png', true],
];

export class SubwyGame {
  constructor() {
    this.canvasWrap = document.getElementById('canvas-wrap');
    this.scene = new THREE.Scene();

    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
      stencil: false,
    });
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.canvasWrap.appendChild(this.renderer.domElement);

    const gpuBadge = document.getElementById('gpu-badge');
    if (gpuBadge) {
      gpuBadge.textContent = navigator.gpu ? 'WEBGPU / WEBGL2 PBR' : 'WEBGL2 PBR';
    }

    this.assets = {
      models: new Map(),
      textures: new Map(),
    };

    this.audio = new AudioEngine();
    this.cameraSys = new CameraSystem(window.innerWidth / window.innerHeight);
    this.scene.add(this.cameraSys.camera);
    this.controls = new InputControls(this.canvasWrap);
    this.ui = new UIManager(this);

    this.world = null;
    this.player = null;
    this.weaponSys = null;
    this.enemyMgr = null;
    this.vehicleMgr = null;
    this.missions = null;

    this.isPlaying = false;
    this.isPaused = false;
    this.standbyExited = false;

    this.lastFrameTime = performance.now();
    this.fpsCounter = 60;
    this._fpsFrames = 0;
    this._fpsAccum = 0;
    this._weatherCycleIdx = 0;

    window.addEventListener('resize', () => this._onResize());
    document.addEventListener('visibilitychange', () => {
      if (document.hidden && this.isPlaying && !this.isPaused) {
        this.setPaused(true);
      }
    });
  }

  async init() {
    const totalSteps = MODEL_MANIFEST.length + TEXTURE_MANIFEST.length + 14;
    let completed = 0;
    const stepDone = (label) => {
      completed++;
      this.ui.updateBootProgress(completed / totalSteps, `Loaded ${label}`);
    };

    // 1. Load PBR Textures
    const texLoader = new THREE.TextureLoader();
    await Promise.all(
      TEXTURE_MANIFEST.map(
        ([key, url, isSRGB]) =>
          new Promise((resolve) => {
            texLoader.load(
              url,
              (tex) => {
                if (isSRGB) tex.colorSpace = THREE.SRGBColorSpace;
                this.assets.textures.set(key, tex);
                stepDone(key);
                resolve();
              },
              undefined,
              () => {
                stepDone(key);
                resolve();
              }
            );
          })
      )
    );

    // 2. Load All 23 Blender .GLB Models progressively in batches of 6 (smooth mobile memory spike control!)
    const gltfLoader = new GLTFLoader();
    for (let i = 0; i < MODEL_MANIFEST.length; i += 6) {
      const batch = MODEL_MANIFEST.slice(i, i + 6);
      await Promise.all(
        batch.map(
          ([key, url]) =>
            new Promise((resolve) => {
              gltfLoader.load(
                url,
                (gltf) => {
                  this.assets.models.set(key, gltf);
                  stepDone(`${key}.glb`);
                  resolve();
                },
                undefined,
                (err) => {
                  console.error(`Failed loading ${url}`, err);
                  stepDone(`${key}.glb`);
                  resolve();
                }
              );
            })
        )
      );
    }

    // 3. Preload 3D Spatial Audio WAVs
    await this.audio.preloadAll((_ratio, key) => stepDone(`${key}.wav`));

    // 4. Construct World & Gameplay Subsystems
    this.world = new WarWorld(this.scene, this.renderer, this.assets, this.audio);
    this.player = new PlayerController(this.scene, this.assets, this.audio, this.cameraSys);
    this.weaponSys = new WeaponSystem(this.scene, this.cameraSys.camera, this.assets, this.audio, this.world);
    this.enemyMgr = new AIManager(this.scene, this.assets, this.audio, this.world);
    this.vehicleMgr = new VehicleManager(this.scene, this.assets, this.audio, this.world, this.weaponSys);
    this.missions = new MissionDirector({
      world: this.world,
      player: this.player,
      weaponSys: this.weaponSys,
      enemyMgr: this.enemyMgr,
      vehicleMgr: this.vehicleMgr,
      cameraSys: this.cameraSys,
      audio: this.audio,
      ui: this.ui,
    });

    // Wire damage & hitmarker UI callbacks
    this.weaponSys.onHitEnemy = ({ isHeadshot }) => {
      this.ui.showHitmarker(isHeadshot);
    };
    this.player.onDamageCallback = (_amt, attackerPos) => {
      this.ui.showDamageDirection(this.player, attackerPos);
    };

    // Apply saved user graphics/audio/perspective settings
    this.applySettings(this.ui.settings);

    // Transition to Legendary Main Menu!
    this.cameraSys.state = 'MENU';
    this.cameraSys.setMenuFocus('HOME');
    this.world.applyAtmosphere('SUNSET', 0.12);
    this.audio.startMenuMusic();
    this.ui.finishBootToMainMenu();

    this.lastFrameTime = performance.now();
    requestAnimationFrame((t) => this._loop(t));
  }

  applySettings(s) {
    this.controls.sensitivity = s.sensitivity;
    this.cameraSys.setPerspective(s.defaultPerspective);
    this.ui.syncPerspectiveBadges(this.cameraSys.perspective);

    const maxDpr = s.quality === 'LOW' ? 1.0 : 2.0;
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, maxDpr) * (s.resScale || 1));

    if (this.world) this.world.setQuality(s.quality, s.shadows);
    if (this.enemyMgr) this.enemyMgr.setDifficulty(s.difficulty || 'VETERAN');

    this.audio.setSettings({
      masterVolume: s.masterVol,
      sfxVolume: s.sfxVol,
      musicVolume: s.musicVol,
      vibrationEnabled: s.vibration,
      quality: s.quality,
    });
  }

  togglePerspectiveMode() {
    const mode = this.cameraSys.togglePerspective();
    this.ui.settings.defaultPerspective = mode;
    this.ui.syncPerspectiveBadges(mode);
    this.audio.playUIClick(true);
    return mode;
  }

  cycleAtmospherePreset() {
    const presets = [
      ['DAY', 0.05],
      ['DAY', 0.65], // Heavy Sandstorm!
      ['SUNSET', 0.18],
      ['NIGHT', 0.08],
    ];
    this._weatherCycleIdx = (this._weatherCycleIdx + 1) % presets.length;
    const [p, storm] = presets[this._weatherCycleIdx];
    this.world.applyAtmosphere(p, storm);
    this.audio.playUIClick();
  }

  startCampaignMission(missionId = 'mission1', opts = {}) {
    this.standbyExited = false;
    this.isPlaying = true;
    this.isPaused = false;
    document.getElementById('main-menu')?.classList.add('hidden');
    document.getElementById('pause-modal')?.classList.add('hidden');
    document.getElementById('result-modal')?.classList.add('hidden');

    this.cameraSys.setPerspective(this.ui.settings.defaultPerspective);
    this.missions.startMissionById(missionId, opts);
    this.controls.setEnabled(!this.missions.inCutscene);
  }

  startVehicleTest(vehicleType) {
    this.startCampaignMission('mission1', { skipCutscene: true, testVehicleType: vehicleType });
  }

  restartCurrentMission() {
    const id = this.missions.activeMission ? this.missions.activeMission.id : 'mission1';
    this.startCampaignMission(id, { skipCutscene: true });
  }

  launchNextMission() {
    document.getElementById('result-modal')?.classList.add('hidden');
    const curId = this.missions.activeMission ? this.missions.activeMission.id : 'mission1';
    const idx = CAMPAIGN_MISSIONS.findIndex((m) => m.id === curId);
    const nextMission = CAMPAIGN_MISSIONS[(idx + 1) % CAMPAIGN_MISSIONS.length];
    this.ui.selectedCampaignId = nextMission.id;
    this.startCampaignMission(nextMission.id);
  }

  setPaused(flag) {
    if (!this.isPlaying) return;
    this.isPaused = flag;
    this.controls.setEnabled(!flag);
    document.getElementById('pause-modal')?.classList.toggle('hidden', !flag);
    if (flag && this.missions.activeMission) {
      document.getElementById('pause-mission-label').textContent =
        this.ui.lang === 'ar' ? this.missions.activeMission.titleAr : this.missions.activeMission.title;
    }
  }

  quitToMainMenu() {
    this.isPlaying = false;
    this.isPaused = false;
    this.controls.setEnabled(false);
    document.body.style.filter = '';
    if (this.player && this.player.activeVehicle) {
      this.player.exitVehicle(this.world);
    }
    if (this.player && this.player.tpsModel) {
      this.player.tpsModel.visible = false;
    }
    if (this.weaponSys && this.weaponSys.viewmodelRoot) {
      this.weaponSys.viewmodelRoot.visible = false;
    }
    this.enemyMgr.clearAll();
    this.vehicleMgr.clearAll();

    this.world.setMenuDioramaVisible(true);
    this.world.applyAtmosphere('SUNSET', 0.12);
    this.cameraSys.state = 'MENU';
    this.cameraSys.setMenuFocus('HOME');
    this.audio.stopWindAmbience();
    this.audio.startMenuMusic();
    this.ui.showMainMenu();
  }

  returnToMenuAndOpen(panelName) {
    this.quitToMainMenu();
    this.ui.handleMenuAction(panelName);
  }

  enterStandbyExit() {
    this.standbyExited = true;
    this.audio.stopMenuMusic();
    this.audio.stopWindAmbience();
    const modal = document.getElementById('exit-modal');
    if (modal) {
      modal.innerHTML = `
        <div class="modal-card">
          <h2>SUBWY XG // STANDBY</h2>
          <p class="modal-sub">${this.ui.lang === 'ar' ? 'تم إيقاف المحرك وحفظ الإعدادات بنجاح. يمكنك إغلاق التبويب أو إعادة التشغيل.' : 'Engine safely halted and all progress saved. Close browser tab or relaunch below.'}</p>
          <button id="btn-wake-engine" class="tac-btn primary">${this.ui.lang === 'ar' ? 'إعادة تشغيل اللعبة ▶' : 'RELAUNCH ENGINE ▶'}</button>
        </div>
      `;
      modal.querySelector('#btn-wake-engine')?.addEventListener('click', () => {
        window.location.reload();
      });
    }
  }

  _onResize() {
    const w = window.innerWidth;
    const h = window.innerHeight;
    this.renderer.setSize(w, h);
    this.cameraSys.onResize(w, h);
  }

  _handlePlayerPulses() {
    const p = this.controls.consumePulses();
    if (p.pause) {
      this.setPaused(!this.isPaused);
      return;
    }
    if (this.isPaused || this.missions.inCutscene) return;

    if (p.toggleView) this.togglePerspectiveMode();
    if (p.jump) this.player.jump();
    if (p.crouch) this.player.toggleCrouch();
    if (p.reload) this.weaponSys.startReload(this.player);
    if (p.switchWeapon) {
      this.weaponSys.cycleWeapon();
      this.ui._renderWeaponSlotButtons();
    }
    if (p.slotIndex >= 0) {
      this.weaponSys.equipSlot(p.slotIndex);
      this.ui._renderWeaponSlotButtons();
    }
    if (p.nvg) {
      document.getElementById('btn-hud-nvg')?.click();
    }
    if (p.interact) {
      if (this.player.activeVehicle) {
        this.player.exitVehicle(this.world);
      } else {
        const veh = this.vehicleMgr.findNearestDrivable(this.player.position, 6.2);
        if (veh) this.player.enterVehicle(veh);
      }
    }
  }

  _loop(now) {
    requestAnimationFrame((t) => this._loop(t));
    if (this.standbyExited) return;

    const rawDt = (now - this.lastFrameTime) / 1000;
    this.lastFrameTime = now;
    const dt = Math.min(rawDt, 0.05); // Clamp max step for physics stability

    // FPS Telemetry
    this._fpsFrames++;
    this._fpsAccum += rawDt;
    if (this._fpsAccum >= 0.5) {
      this.fpsCounter = Math.round(this._fpsFrames / this._fpsAccum);
      this._fpsFrames = 0;
      this._fpsAccum = 0;
    }

    if (this.isPlaying && !this.isPaused) {
      const wasInCutscene = this.missions.inCutscene;
      this.missions.update(dt);
      if (wasInCutscene && !this.missions.inCutscene) {
        this.controls.setEnabled(true);
      }

      if (!this.missions.inCutscene) {
        this._handlePlayerPulses();
        this.player.update(dt, this.controls, this.world, this.weaponSys);
        this.enemyMgr.update(dt, this.player);
        this.vehicleMgr.update(dt, {
          controls: this.controls,
          player: this.player,
          cameraSys: this.cameraSys,
          enemyMgr: this.enemyMgr,
          isPlaying: true,
        });
      }

      this.cameraSys.update(dt, {
        player: this.player,
        world: this.world,
        activeVehicle: this.player.activeVehicle,
        weaponDef: this.weaponSys.currentWeapon,
        isAds: this.controls.ads,
      });

      this.weaponSys.update(dt, {
        controls: this.controls,
        player: this.player,
        cameraSys: this.cameraSys,
        enemyMgr: this.enemyMgr,
        vehicleMgr: this.vehicleMgr,
        isPlaying: !this.missions.inCutscene,
      });

      this.world.update(dt, this.player.position, false);

      if (!this.missions.inCutscene) {
        this.ui.updateHudFrame({
          player: this.player,
          weaponSys: this.weaponSys,
          controls: this.controls,
          missions: this.missions,
          enemyMgr: this.enemyMgr,
          vehicleMgr: this.vehicleMgr,
          cameraSys: this.cameraSys,
          fps: this.fpsCounter,
        });
      }
    } else if (!this.isPlaying) {
      // Main Menu live 3D war scene!
      this.cameraSys.update(dt, {
        player: this.player,
        world: this.world,
        activeVehicle: null,
        weaponDef: null,
        isAds: false,
      });
      this.world.update(dt, this.world.menuAnchor, true);
    }

    this.audio.updateListener(this.cameraSys.camera);
    this.renderer.render(this.scene, this.cameraSys.camera);
  }
}

window.addEventListener('DOMContentLoaded', () => {
  const game = new SubwyGame();
  window.SUBWY_GAME = game;
  game.init().catch((err) => {
    console.error('SUBWY XG Boot Error:', err);
  });
});
