// player.js — Dual-Perspective (FPS & TPS) Rigged 3D Soldier Controller, Health/Armor & Operator Perks
import * as THREE from 'three';
import * as SkeletonUtils from './lib/SkeletonUtils.js';

export const SOLDIER_OPERATORS = {
  vanguard: {
    id: 'vanguard',
    name: 'VANGUARD ASSAULT',
    nameAr: 'فانغارد هجومي',
    role: 'Balanced Frontline Rifleman',
    roleAr: 'مقاتل خط أمامي متوازن (+درع تكتيكي)',
    maxHp: 110,
    maxArmor: 50,
    speedMult: 1.0,
    recoilMult: 0.92,
    vestColor: 0x6b5d45,
  },
  ghost: {
    id: 'ghost',
    name: 'GHOST RECON',
    nameAr: 'الشبح القناص',
    role: 'Marksman & High Mobility (+15% Speed)',
    roleAr: 'قناص استطلاع (+15% سرعة وثبات تصويب)',
    maxHp: 100,
    maxArmor: 35,
    speedMult: 1.15,
    recoilMult: 0.78,
    vestColor: 0x3b4942,
  },
  heavy: {
    id: 'heavy',
    name: 'TITAN HEAVY',
    nameAr: 'تايتن المدرع',
    role: 'Armored Breacher (135 HP + 80 Armor)',
    roleAr: 'مدرع ثقيل (135 صحة + 80 درع مضاد للشظايا)',
    maxHp: 135,
    maxArmor: 80,
    speedMult: 0.92,
    recoilMult: 0.88,
    vestColor: 0x2f353d,
  },
  commando: {
    id: 'commando',
    name: 'DESERT COMMANDO',
    nameAr: 'كوماندوز الصحراء',
    role: 'SpecOps Raider (+Fast Reload & Sprint)',
    roleAr: 'قوات خاصة صحراوية (+سرعة ركض وإعادة تلقيم)',
    maxHp: 115,
    maxArmor: 45,
    speedMult: 1.08,
    recoilMult: 0.85,
    vestColor: 0x8c7248,
  },
};

export class PlayerController {
  constructor(scene, assets, audio, cameraSys) {
    this.scene = scene;
    this.assets = assets;
    this.audio = audio;
    this.cameraSys = cameraSys;

    this.operatorId = 'vanguard';
    this.operator = SOLDIER_OPERATORS.vanguard;

    this.position = new THREE.Vector3(0, 0, 118);
    this.velocity = new THREE.Vector3();
    this.yaw = 0;   // 0 = looking along -Z (North toward bridge & ruined city!)
    this.pitch = 0;

    this.hp = this.operator.maxHp;
    this.maxHp = this.operator.maxHp;
    this.armor = this.operator.maxArmor;
    this.maxArmor = this.operator.maxArmor;
    this.dead = false;
    this.regenDelay = 0;

    this.onGround = true;
    this.isCrouching = false;
    this.isSprinting = false;
    this.standEyeHeight = 1.62;
    this.crouchEyeHeight = 1.06;
    this.currentEyeHeight = 1.62;
    this.stepAccum = 0;

    this.activeVehicle = null;
    this.nvgActive = false;

    //Callbacks
    this.onDamageCallback = null;
    this.onDeathCallback = null;

    // Build TPS 3D Rigged Soldier Mesh + Skeletal Animations!
    this.tpsModel = null;
    this.mixer = null;
    this.actions = {};
    this.currentAnim = '';
    this._oneShotTimer = 0;
    this._buildTpsModel();

    // Tactical Helmet Flashlight attached to Camera
    this.flashlight = new THREE.SpotLight(0xfff6e0, 0, 42, Math.PI / 5.5, 0.45, 1.2);
    this.flashlight.position.set(0.15, -0.1, 0);
    this.flashlight.target.position.set(0, 0, -10);
    this.cameraSys.camera.add(this.flashlight);
    this.cameraSys.camera.add(this.flashlight.target);
  }

  _buildTpsModel() {
    const gltf = this.assets.models.get('soldier_ally');
    if (!gltf) return;

    this.tpsModel = SkeletonUtils.clone(gltf.scene);
    this.tpsModel.traverse((c) => {
      if (c.isMesh) {
        c.castShadow = true;
        c.receiveShadow = true;
        c.frustumCulled = false;
      }
    });
    this.tpsModel.visible = false;
    this.scene.add(this.tpsModel);

    if (gltf.animations && gltf.animations.length > 0) {
      this.mixer = new THREE.AnimationMixer(this.tpsModel);
      for (const clip of gltf.animations) {
        const act = this.mixer.clipAction(clip);
        if (['Shoot', 'Reload', 'Hit', 'Jump', 'Death'].includes(clip.name)) {
          act.setLoop(THREE.LoopOnce, 1);
          act.clampWhenFinished = clip.name === 'Death';
        }
        this.actions[clip.name] = act;
      }
      this.playAnim('Idle');
    }
  }

  setOperator(opId) {
    if (!SOLDIER_OPERATORS[opId]) return;
    this.operatorId = opId;
    this.operator = SOLDIER_OPERATORS[opId];
    this.maxHp = this.operator.maxHp;
    this.maxArmor = this.operator.maxArmor;
    this.hp = this.maxHp;
    this.armor = this.maxArmor;

    if (this.tpsModel) {
      this.tpsModel.traverse((c) => {
        if (c.isMesh && c.material && c.material.name && c.material.name.startsWith('VestArmor')) {
          c.material = c.material.clone();
          c.material.color.setHex(this.operator.vestColor);
        }
      });
    }
  }

  spawnAt(x, z, yaw = 0, world = null) {
    const y = world ? world.getTerrainHeight(x, z) : 0;
    this.position.set(x, y, z);
    this.velocity.set(0, 0, 0);
    this.yaw = yaw;
    this.pitch = 0;
    this.dead = false;
    this.isCrouching = false;
    this.isSprinting = false;
    this.activeVehicle = null;
    this.hp = this.maxHp;
    this.armor = this.maxArmor;
    this._oneShotTimer = 0;
    if (this.actions.Death) this.actions.Death.stop();
    this.playAnim('Idle', true);
  }

  playAnim(name, force = false) {
    if (!this.mixer || !this.actions[name]) return;
    if (this.currentAnim === name && !force) return;
    const next = this.actions[name];
    const prev = this.actions[this.currentAnim];
    if (prev && prev !== next) {
      prev.fadeOut(0.14);
    }
    next.reset().fadeIn(0.14).play();
    this.currentAnim = name;
  }

  triggerActionAnim(name, duration = 0.35) {
    if (this.dead) return;
    this._oneShotTimer = duration;
    this.playAnim(name, true);
  }

  toggleNightVision() {
    this.nvgActive = !this.nvgActive;
    this.flashlight.intensity = this.nvgActive ? 6.5 : 0;
    return this.nvgActive;
  }

  takeDamage(amount, attackerPos = null) {
    if (this.dead) return;
    // If inside an armored vehicle, route damage to vehicle hull first!
    if (this.activeVehicle && !this.activeVehicle.destroyed) {
      this.activeVehicle.takeDamage(amount * 0.45);
      this.cameraSys.addShake(0.18);
      return;
    }

    this.regenDelay = 4.8;
    let remaining = amount;
    if (this.armor > 0) {
      const absorbed = Math.min(this.armor, remaining * 0.65);
      this.armor -= absorbed;
      remaining -= absorbed;
    }
    this.hp = Math.max(0, this.hp - remaining);

    this.cameraSys.addShake(Math.min(0.45, amount * 0.014));
    this.audio.vibrate(45);
    if (this._oneShotTimer <= 0 && this.hp > 0) {
      this.triggerActionAnim('Hit', 0.28);
    }

    if (this.onDamageCallback) {
      this.onDamageCallback(amount, attackerPos);
    }

    if (this.hp <= 0 && !this.dead) {
      this.dead = true;
      this.playAnim('Death', true);
      this.audio.vibrate([80, 40, 140]);
      if (this.onDeathCallback) this.onDeathCallback();
    }
  }

  healAndResupply(weaponSys) {
    this.hp = this.maxHp;
    this.armor = this.maxArmor;
    if (weaponSys) weaponSys.refillAllAmmo();
    this.audio.play2D('reload_mech', { volume: 0.75, rate: 1.15 });
  }

  update(dt, controls, world, weaponSys) {
    if (this.dead) {
      if (this.mixer) this.mixer.update(dt);
      return;
    }

    // Health auto-recovery out of combat after 4.8s
    if (this.regenDelay > 0) {
      this.regenDelay -= dt;
    } else if (this.hp < this.maxHp) {
      this.hp = Math.min(this.maxHp, this.hp + dt * 9.5);
    }

    // Apply look delta
    const look = controls.consumeLookDelta(controls.ads);
    this.yaw += look.dx;
    this.pitch = THREE.MathUtils.clamp(this.pitch + look.dy, -1.35, 1.35);

    // If driving a Tank / APC / Jeep, sync player position to vehicle & hide infantry mesh
    if (this.activeVehicle) {
      if (this.activeVehicle.destroyed) {
        this.exitVehicle(world);
        this.takeDamage(45);
      } else {
        this.position.copy(this.activeVehicle.root.position);
        if (this.tpsModel) this.tpsModel.visible = false;
        return;
      }
    }

    // Stance eye-height smoothing
    const targetEye = this.isCrouching ? this.crouchEyeHeight : this.standEyeHeight;
    this.currentEyeHeight = THREE.MathUtils.lerp(this.currentEyeHeight, targetEye, Math.min(1, dt * 12));

    // Horizontal movement vector in world space (yaw = 0 faces -Z)
    controls.updateMovementState();
    const forwardX = -Math.sin(this.yaw);
    const forwardZ = -Math.cos(this.yaw);
    const rightX = Math.cos(this.yaw);
    const rightZ = -Math.sin(this.yaw);

    const wishX = rightX * controls.moveX + forwardX * controls.moveZ;
    const wishZ = rightZ * controls.moveX + forwardZ * controls.moveZ;

    this.isSprinting = controls.sprint && !this.isCrouching && !controls.ads && controls.moveZ > 0.25;
    let moveSpeed = 5.4 * this.operator.speedMult;
    if (this.isSprinting) moveSpeed *= 1.52;
    else if (this.isCrouching) moveSpeed *= 0.56;
    else if (controls.ads) moveSpeed *= 0.68;
    if (weaponSys && weaponSys.currentWeapon) {
      moveSpeed *= weaponSys.currentWeapon.mobility || 1.0;
    }

    const accel = this.onGround ? 14.0 : 4.0;
    this.velocity.x = THREE.MathUtils.lerp(this.velocity.x, wishX * moveSpeed, Math.min(1, dt * accel));
    this.velocity.z = THREE.MathUtils.lerp(this.velocity.z, wishZ * moveSpeed, Math.min(1, dt * accel));

    // Gravity
    if (!this.onGround) {
      this.velocity.y -= 21.0 * dt;
    }

    this.position.x += this.velocity.x * dt;
    this.position.z += this.velocity.z * dt;
    this.position.y += this.velocity.y * dt;

    // World horizontal & vertical floor collision (supports terrain, canyon bridge, and 2nd-story building ramps!)
    if (world) {
      world.resolveHorizontalCollision(this.position, 0.42, this.position.y, this.isCrouching ? 1.2 : 1.75);
      const floorY = world.getFloorHeightAt(this.position.x, this.position.z, this.position.y);
      if (this.position.y <= floorY + 0.03 && this.velocity.y <= 0) {
        this.position.y = floorY;
        this.velocity.y = 0;
        this.onGround = true;
      } else if (this.position.y > floorY + 0.12) {
        this.onGround = false;
      }

      // Auto-check Ammo Crate proximity resupply
      for (const crate of world.ammoCrates) {
        if (crate.cooldown <= 0 && crate.pos.distanceToSquared(this.position) < 2.4 * 2.4) {
          if (this.hp < this.maxHp || (weaponSys && weaponSys.needsAmmo())) {
            crate.cooldown = 18.0;
            this.healAndResupply(weaponSys);
          }
        }
      }
    }

    // Footstep audio cadence
    const horizSpeed = Math.hypot(this.velocity.x, this.velocity.z);
    if (this.onGround && horizSpeed > 0.8) {
      this.stepAccum += horizSpeed * dt;
      const stride = this.isSprinting ? 2.55 : 2.05;
      if (this.stepAccum >= stride) {
        this.stepAccum = 0;
        this.audio.play2D('footstep_sand', {
          volume: this.isCrouching ? 0.18 : 0.36,
          rate: 0.92 + Math.random() * 0.16,
        });
      }
    }

    // Update TPS 3D Soldier Model Visibility, Transform & Skeletal Animations!
    const sniperScopeActive =
      controls.ads && weaponSys && weaponSys.currentWeapon && weaponSys.currentWeapon.scopeOverlay;
    const showTpsBody = this.cameraSys.perspective === 'TPS' && !sniperScopeActive && !this.activeVehicle;

    if (this.tpsModel) {
      this.tpsModel.visible = showTpsBody;
      this.tpsModel.position.copy(this.position);
      // Soldier mesh built facing +Z in glTF; player yaw=0 looks along -Z, so add Math.PI!
      this.tpsModel.rotation.y = this.yaw + Math.PI;

      if (this._oneShotTimer > 0) {
        this._oneShotTimer -= dt;
      } else if (!this.onGround) {
        this.playAnim('Jump');
      } else if (this.isCrouching) {
        this.playAnim('Crouch');
      } else if (horizSpeed > 5.8) {
        this.playAnim('Run');
      } else if (horizSpeed > 0.55) {
        this.playAnim('Walk');
      } else {
        this.playAnim('Idle');
      }

      if (this.mixer) this.mixer.update(dt);
    }
  }

  jump() {
    if (this.dead || this.activeVehicle || !this.onGround) return;
    if (this.isCrouching) {
      this.isCrouching = false;
      return;
    }
    this.velocity.y = 7.4;
    this.onGround = false;
    this.triggerActionAnim('Jump', 0.45);
    this.audio.play2D('footstep_sand', { volume: 0.45, rate: 0.8 });
  }

  toggleCrouch() {
    if (this.dead || this.activeVehicle) return;
    this.isCrouching = !this.isCrouching;
  }

  enterVehicle(vehicle) {
    this.activeVehicle = vehicle;
    vehicle.driver = 'player';
    this.isCrouching = false;
    this.audio.play2D('reload_mech', { volume: 0.7, rate: 0.85 });
  }

  exitVehicle(world) {
    if (!this.activeVehicle) return;
    const v = this.activeVehicle;
    v.driver = null;
    this.activeVehicle = null;
    // Step out safely to the right side of the hull
    const sideX = Math.cos(v.root.rotation.y) * 3.2;
    const sideZ = -Math.sin(v.root.rotation.y) * 3.2;
    this.position.set(v.root.position.x + sideX, v.root.position.y + 0.4, v.root.position.z + sideZ);
    if (world) {
      world.resolveHorizontalCollision(this.position, 0.45, this.position.y, 1.75);
      this.position.y = world.getFloorHeightAt(this.position.x, this.position.z, this.position.y + 1.0);
    }
    this.audio.play2D('footstep_sand', { volume: 0.5 });
  }

  getStanceLabel() {
    if (this.activeVehicle) return 'ARMOR';
    if (!this.onGround) return 'AIR';
    if (this.isSprinting) return 'SPRINT';
    if (this.isCrouching) return 'CROUCH';
    return 'STAND';
  }
}
