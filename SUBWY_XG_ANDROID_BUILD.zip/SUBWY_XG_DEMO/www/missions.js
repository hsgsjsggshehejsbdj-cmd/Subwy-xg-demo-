// missions.js — Campaign Story Operations, Cinematic Cutscenes, Objectives & Victory/Defeat System
import * as THREE from 'three';

export const CAMPAIGN_MISSIONS = [
  {
    id: 'mission1',
    code: 'MISSION 01',
    title: 'THE DESERT WAR',
    titleAr: 'المهمة 01: حرب الصحراء',
    desc: 'Deploy from Forward Base Alpha across the scorching desert trenches and capture the strategic Canyon Bridge.',
    descAr: 'انطلق من القاعدة العسكرية الصحراوية، طهّر خط الخنادق الأمامي، وسيطر على جسر الوادي الاستراتيجي.',
    atmosphere: { preset: 'DAY', sandstorm: 0.08 },
    spawn: { x: 0, z: 116, yaw: 0 },
    cutscene: {
      from: [16, 12, 134],
      to: [4, 4.5, 108],
      look: [0, 2.0, 65],
      subtitle: 'HQ COMMAND: Alpha-1, enemy recon has seized the trench line and canyon bridge. Advance and clear all hostiles!',
      subtitleAr: 'القيادة: ألفا-1، قوات معادية تسيطر على الخنادق وجسر الوادي. تقدم وطهّر المنطقة بالكامل!',
    },
  },
  {
    id: 'mission2',
    code: 'MISSION 02',
    title: 'DESTROYED CITY',
    titleAr: 'المهمة 02: المدينة المدمرة',
    desc: 'Fight street-by-street through bombed multi-story buildings under a desert sandstorm and crush the enemy APC.',
    descAr: 'تقدم داخل شوارع ومباني المدينة المدمرة وسط عاصفة رملية، واقضِ على القناصة والمدرعة المعادية.',
    atmosphere: { preset: 'DAY', sandstorm: 0.58 },
    spawn: { x: 0, z: -22, yaw: 0 },
    cutscene: {
      from: [-14, 11, -30],
      to: [6, 5.5, -46],
      look: [0, 3.5, -82],
      subtitle: 'HQ COMMAND: Sandstorm incoming! Snipers spotted in the ruined upper floors. Clear the avenue and secure the plaza!',
      subtitleAr: 'القيادة: عاصفة رملية تقترب! تم رصد قناصة في الطوابق العلوية المدمرة. طهّر الشارع الرئيسي!',
    },
  },
  {
    id: 'mission3',
    code: 'MISSION 03',
    title: 'FINAL ASSAULT',
    titleAr: 'المهمة 03: الهجوم النهائي',
    desc: 'All-out combined arms war at sunset! Board the M1A3 Abrams Tank, destroy enemy armor & gunship, and take the Citadel.',
    descAr: 'معركة شاملة عند الغروب! قُد دبابة أبرامز M1A3، دمّر الدبابات والمروحية المعادية، واقتحم القلعة الشمالية.',
    atmosphere: { preset: 'SUNSET', sandstorm: 0.22 },
    spawn: { x: -3.5, z: -36, yaw: 0 },
    cutscene: {
      from: [20, 14, -32],
      to: [-6, 5.2, -48],
      look: [0, 2.5, -108],
      subtitle: 'HQ COMMAND: Air strike inbound! Board the M1A3 Battle Tank or use RPGs to crush their armored division!',
      subtitleAr: 'القيادة: غارة جوية صديقة في الطريق! استخدم الدبابة أو قاذف الصواريخ لتدمير المدرعات المعادية!',
    },
  },
];

export class MissionDirector {
  constructor({ world, player, weaponSys, enemyMgr, vehicleMgr, cameraSys, audio, ui }) {
    this.world = world;
    this.player = player;
    this.weaponSys = weaponSys;
    this.enemyMgr = enemyMgr;
    this.vehicleMgr = vehicleMgr;
    this.cameraSys = cameraSys;
    this.audio = audio;
    this.ui = ui;

    this.activeMission = null;
    this.stageIndex = 0;
    this.stages = [];
    this.inCutscene = false;
    this.cutsceneDuration = 4.6;
    this.cutsceneElapsed = 0;
    this.completed = false;
    this.failed = false;

    // Match Telemetry Stats
    this.stats = {
      kills: 0,
      headshots: 0,
      vehiclesDestroyed: 0,
      startTime: 0,
    };

    // Hook kill callbacks
    this.enemyMgr.onEnemyKilled = (_agent, isHeadshot) => {
      this.stats.kills++;
      if (isHeadshot) this.stats.headshots++;
      this.ui.pushKillfeed(isHeadshot ? 'HEADSHOT ELIMINATION +150' : 'HOSTILE NEUTRALIZED +100', isHeadshot);
    };

    this.vehicleMgr.onVehicleDestroyed = (veh) => {
      if (veh.team === 'enemy') {
        this.stats.vehiclesDestroyed++;
        this.ui.pushKillfeed(`DESTROYED ${veh.spec.name} +500`, true);
      }
    };
  }

  startMissionById(missionId, { skipCutscene = false, testVehicleType = null } = {}) {
    const def = CAMPAIGN_MISSIONS.find((m) => m.id === missionId) || CAMPAIGN_MISSIONS[0];
    this.activeMission = def;
    this.stageIndex = 0;
    this.completed = false;
    this.failed = false;
    this.stats = { kills: 0, headshots: 0, vehiclesDestroyed: 0, startTime: performance.now() };

    this.enemyMgr.clearAll();
    this.vehicleMgr.clearAll();
    this.world.setMenuDioramaVisible(false);
    this.world.applyAtmosphere(def.atmosphere.preset, def.atmosphere.sandstorm);

    this.player.spawnAt(def.spawn.x, def.spawn.z, def.spawn.yaw, this.world);
    this.weaponSys.refillAllAmmo();
    this.weaponSys.equipSlot(0);

    if (testVehicleType) {
      this._setupVehicleProvingGround(testVehicleType);
      this.finishCutscene();
      return;
    }

    this._populateMissionStages(def.id);

    // Launch Fighter Jet flyby for cinematic spectacle!
    this.vehicleMgr.spawnFighterJetFlyby(def.spawn.z - 55, def.id === 'mission3');

    if (skipCutscene) {
      this.finishCutscene();
    } else {
      this.inCutscene = true;
      this.cutsceneElapsed = 0;
      const cs = def.cutscene;
      this.cameraSys.startCutscene(
        new THREE.Vector3(...cs.from),
        new THREE.Vector3(...cs.to),
        new THREE.Vector3(...cs.look)
      );
      this.ui.showCutscene(def);
      this.audio.play2D('radio_chatter', { volume: 0.7 });
    }
  }

  _setupVehicleProvingGround(vehicleType) {
    this.player.spawnAt(-4, 112, Math.PI, this.world);
    const vType = vehicleType === 'heli' || vehicleType === 'jet' ? 'tank' : vehicleType;
    const spawned = this.vehicleMgr.spawnVehicle({
      type: vType,
      team: 'ally',
      x: 0,
      z: 106,
      yaw: Math.PI,
    });
    if (vehicleType === 'heli') {
      this.vehicleMgr.spawnVehicle({ type: 'heli', team: 'ally', x: 10, z: 75 });
    } else if (vehicleType === 'jet') {
      this.vehicleMgr.spawnFighterJetFlyby(40, true);
    }
    this.player.enterVehicle(spawned);

    // Spawn target drones/enemies & enemy APC across trench & bridge!
    for (const [ex, ez] of [[-12, 46], [12, 46], [-5, 18], [6, 16], [0, -34]]) {
      this.enemyMgr.spawnEnemy({ x: ex, z: ez, role: 'rifleman' });
    }
    this.vehicleMgr.spawnVehicle({ type: 'apc', team: 'enemy', x: 0, z: -48, yaw: 0, aiDriver: true });

    this.stages = [
      {
        objectiveEn: 'Destroy enemy patrol & test vehicle weapons across the warzone',
        objectiveAr: 'اختبر قيادة المركبة وأسلحتها ودمّر الأهداف المعادية في الميدان',
        waypoint: new THREE.Vector3(0, 2, -30),
        checkComplete: () => this.enemyMgr.aliveEnemyCount === 0 && !this._hasAliveEnemyArmor(),
      },
    ];
  }

  _populateMissionStages(id) {
    if (id === 'mission1') {
      // Allied Squad + Drivable Desert Recon Jeep at FOB!
      this.enemyMgr.spawnAlly({ x: -3.5, z: 112 });
      this.enemyMgr.spawnAlly({ x: 3.5, z: 112 });
      this.vehicleMgr.spawnVehicle({ type: 'jeep', team: 'ally', x: 6.5, z: 110, yaw: Math.PI });

      // Stage 1 Trench & Desert Scouts
      for (const [x, z, role] of [
        [-18, 52, 'rifleman'], [-11, 43, 'rifleman'], [0, 56, 'rifleman'],
        [12, 43, 'rifleman'], [21, 49, 'heavy'], [-4, 34, 'rifleman'],
      ]) {
        this.enemyMgr.spawnEnemy({ x, z, role });
      }

      this.stages = [
        {
          objectiveEn: 'Clear enemy scouts holding the Desert Trench Line',
          objectiveAr: 'طهّر خط الخنادق الصحراوي من جنود الاستطلاع الأعداء',
          waypoint: new THREE.Vector3(0, 1.5, 44),
          checkComplete: () => this.enemyMgr.aliveEnemyCount === 0,
          onComplete: () => {
            this.ui.showRadio('HQ COMMAND', this.ui.lang === 'ar'
              ? 'أحسنت! تعزيزات معادية وقناص يتمركزون عند جسر الوادي. تقدم وسيطر على الجسر!'
              : 'Trench line clear! Hostile sniper & squad fortified at Canyon Bridge. Push north!');
            // Spawn Bridge Garrison + Watchtower Sniper + Enemy Jeep!
            const towerGround = this.world.getTerrainHeight(17, -25);
            this.enemyMgr.spawnEnemy({ x: 17, z: -25, y: towerGround + 6.65, role: 'sniper' });
            for (const [x, z, role] of [
              [-4, 8, 'rifleman'], [4, 2, 'rifleman'], [-7, -18, 'heavy'],
              [7, -19, 'rifleman'], [0, -28, 'rpg'],
            ]) {
              this.enemyMgr.spawnEnemy({ x, z, role });
            }
            this.vehicleMgr.spawnVehicle({ type: 'jeep', team: 'enemy', x: -3, z: -32, yaw: 0, aiDriver: true });
          },
        },
        {
          objectiveEn: 'Capture Canyon Bridge & eliminate the Watchtower Sniper',
          objectiveAr: 'سيطر على جسر الوادي واقضِ على القناص والحامية المعادية',
          waypoint: new THREE.Vector3(0, 2.2, -12),
          checkComplete: () => this.enemyMgr.aliveEnemyCount === 0,
        },
      ];
    } else if (id === 'mission2') {
      // Allied Urban Assault Squad
      this.enemyMgr.spawnAlly({ x: -3, z: -25 });
      this.enemyMgr.spawnAlly({ x: 3, z: -25 });

      // Stage 1: Urban Avenue + 2nd-Floor Ruined Building Snipers!
      const b1Y = this.world.getTerrainHeight(-19, -54) + 4.2;
      const b2Y = this.world.getTerrainHeight(-19, -98) + 4.2;
      this.enemyMgr.spawnEnemy({ x: -17.5, z: -50.2, y: b1Y, role: 'sniper' });
      this.enemyMgr.spawnEnemy({ x: -17.5, z: -94.2, y: b2Y, role: 'sniper' });
      for (const [x, z, role] of [
        [-6, -48, 'rifleman'], [7, -52, 'rifleman'], [16, -54, 'heavy'],
        [-9, -64, 'rifleman'], [9, -66, 'rifleman'],
      ]) {
        this.enemyMgr.spawnEnemy({ x, z, role });
      }

      this.stages = [
        {
          objectiveEn: 'Breach the Destroyed City & neutralize upper-floor Snipers',
          objectiveAr: 'اخترق شوارع المدينة المدمرة واقضِ على القناصة في المباني',
          waypoint: new THREE.Vector3(0, 2.0, -56),
          checkComplete: () => this.enemyMgr.aliveEnemyCount <= 1,
          onComplete: () => {
            this.ui.showRadio('HQ COMMAND', this.ui.lang === 'ar'
              ? 'تحذير! مدرعة معادية BTR-XG دخلت الساحة المركزية. استخدم قاذف RPG-7X لتدميرها!'
              : 'WARNING! Enemy BTR-XG 8x8 APC rolling into Central Plaza. Use RPG-7X or explosives!');
            this.vehicleMgr.spawnVehicle({ type: 'apc', team: 'enemy', x: 0, z: -92, yaw: 0, aiDriver: true });
            for (const [x, z, role] of [
              [-11, -82, 'rifleman'], [11, -82, 'rifleman'],
              [-5, -95, 'heavy'], [6, -95, 'rpg'],
            ]) {
              this.enemyMgr.spawnEnemy({ x, z, role });
            }
          },
        },
        {
          objectiveEn: 'Destroy Enemy BTR-XG APC & secure City Plaza',
          objectiveAr: 'دمّر المدرعة المعادية BTR-XG وطهّر ساحة المدينة',
          waypoint: new THREE.Vector3(0, 2.0, -88),
          checkComplete: () => this.enemyMgr.aliveEnemyCount === 0 && !this._hasAliveEnemyArmor(),
        },
      ];
    } else {
      // MISSION 03: FINAL ASSAULT — Combined Arms Tank, APC, Helicopter & Citadel Battle!
      this.enemyMgr.spawnAlly({ x: -7, z: -40 });
      this.enemyMgr.spawnAlly({ x: 7, z: -40 });
      this.enemyMgr.spawnAlly({ x: -10, z: -42 });

      // Player's Drivable M1A3 Abrams-XG Tank + Tactical APC ready at the frontline!
      this.vehicleMgr.spawnVehicle({ type: 'tank', team: 'ally', x: 2.5, z: -42, yaw: Math.PI });
      this.vehicleMgr.spawnVehicle({ type: 'apc', team: 'ally', x: -9.5, z: -38, yaw: Math.PI });

      // Enemy Armored Division + Attack Helicopter Gunship!
      this.vehicleMgr.spawnVehicle({ type: 'tank', team: 'enemy', x: -8, z: -92, yaw: 0, aiDriver: true });
      this.vehicleMgr.spawnVehicle({ type: 'tank', team: 'enemy', x: 9, z: -108, yaw: 0, aiDriver: true });
      this.vehicleMgr.spawnVehicle({ type: 'heli', team: 'enemy', x: 0, z: -98 });

      for (const [x, z, role] of [
        [-12, -74, 'rpg'], [12, -74, 'rifleman'], [0, -84, 'heavy'],
        [-14, -104, 'rifleman'], [14, -104, 'rifleman'],
      ]) {
        this.enemyMgr.spawnEnemy({ x, z, role });
      }

      this.stages = [
        {
          objectiveEn: 'Board M1A3 Tank [F / ENTER] & destroy Enemy Tanks + Helicopter',
          objectiveAr: 'اركب دبابة M1A3 ودمّر الدبابات والمروحية المعادية',
          waypoint: new THREE.Vector3(0, 2.5, -94),
          checkComplete: () => !this._hasAliveEnemyArmor(),
          onComplete: () => {
            this.ui.showRadio('HQ COMMAND', this.ui.lang === 'ar'
              ? 'المدرعات المعادية دُمّرت! اقتحم مقر القيادة الشمالي لحسم الحرب!'
              : 'Enemy armor neutralized! Storm the Northern Command Stronghold to finish the war!');
            this.vehicleMgr.spawnFighterJetFlyby(-125, true);
            const citY = this.world.getTerrainHeight(0, -132) + 4.2;
            this.enemyMgr.spawnEnemy({ x: -1.8, z: -127.5, y: citY, role: 'sniper' });
            for (const [x, z, role] of [
              [-8, -122, 'heavy'], [8, -122, 'heavy'],
              [-3, -130, 'rifleman'], [3, -130, 'rifleman'], [0, -135, 'rpg'],
            ]) {
              this.enemyMgr.spawnEnemy({ x, z, role });
            }
          },
        },
        {
          objectiveEn: 'Storm the Northern Command Stronghold & eliminate all defenders',
          objectiveAr: 'اقتحم القلعة الشمالية واقضِ على حرس القيادة',
          waypoint: new THREE.Vector3(0, 2.5, -128),
          checkComplete: () => this.enemyMgr.aliveEnemyCount === 0,
        },
      ];
    }
  }

  _hasAliveEnemyArmor() {
    return this.vehicleMgr.vehicles.some((v) => v.team === 'enemy' && !v.destroyed);
  }

  finishCutscene() {
    if (!this.inCutscene && this.cameraSys.state === 'GAME') return;
    this.inCutscene = false;
    this.cameraSys.state = 'GAME';
    this.ui.hideCutscene();
    this.ui.showGameHud(true);
    this.audio.stopMenuMusic();
    this.audio.startWindAmbience(this.world.sandstorm);
  }

  get currentStage() {
    return this.stages[this.stageIndex] || null;
  }

  getElapsedSeconds() {
    return Math.max(0, Math.floor((performance.now() - this.stats.startTime) / 1000));
  }

  update(dt) {
    if (!this.activeMission || this.completed || this.failed) return;

    if (this.inCutscene) {
      this.cutsceneElapsed += dt;
      this.cameraSys.cutsceneProgress = Math.min(1, this.cutsceneElapsed / this.cutsceneDuration);
      if (this.cutsceneElapsed >= this.cutsceneDuration) {
        this.finishCutscene();
      }
      return;
    }

    // Check Player Defeat
    if (this.player.dead) {
      this.failed = true;
      setTimeout(() => {
        this.ui.showMissionResult(false, this.activeMission, this.stats, this.getElapsedSeconds());
      }, 1100);
      return;
    }

    // Check Current Stage Objective Completion
    const st = this.currentStage;
    if (st && st.checkComplete()) {
      if (st.onComplete) st.onComplete();
      this.stageIndex++;
      if (this.stageIndex >= this.stages.length) {
        this.completed = true;
        this.audio.play2D('radio_chatter', { volume: 0.8 });
        setTimeout(() => {
          this.ui.showMissionResult(true, this.activeMission, this.stats, this.getElapsedSeconds());
        }, 900);
      }
    }
  }
}
