// controls.js — Unified Android/iOS Multi-Touch & Windows Keyboard/Mouse Controls
const TOUCH_LAYOUT_KEY = 'subwy_xg_touch_layout_v1';

export class InputControls {
  constructor(canvasWrap) {
    this.canvasWrap = canvasWrap;
    this.enabled = false;
    this.editLayoutMode = false;

    // Normalized continuous state
    this.moveX = 0; // -1 left .. +1 right
    this.moveZ = 0; // -1 back .. +1 forward
    this.sprint = false;
    this.firing = false;
    this.ads = false;

    // Frame-accumulated look deltas (radians)
    this.lookDX = 0;
    this.lookDY = 0;

    // Settings
    this.sensitivity = 1.0;
    this.adsSensitivity = 0.58;

    // One-shot action pulses consumed each frame
    this.pulses = {
      jump: false,
      crouch: false,
      reload: false,
      switchWeapon: false,
      slotIndex: -1,
      toggleView: false,
      interact: false,
      pause: false,
      nvg: false,
    };

    // Internal tracking
    this.keys = new Set();
    this.mouseButtons = new Set();
    this.joyTouchId = null;
    this.joyOrigin = { x: 0, y: 0 };
    this.joyVec = { x: 0, y: 0 };
    this.joySprint = false;

    this.lookTouchId = null;
    this.lookLast = { x: 0, y: 0 };
    this.fireTouchIds = new Set();
    this.dragTarget = null;
    this.dragOffset = { x: 0, y: 0 };

    this._bindKeyboardMouse();
    this._bindTouchControls();
    this.loadTouchLayout();
  }

  setEnabled(flag) {
    this.enabled = flag;
    if (!flag) {
      this.keys.clear();
      this.mouseButtons.clear();
      this.firing = false;
      this.ads = false;
      this.moveX = 0;
      this.moveZ = 0;
      this.joyTouchId = null;
      this.lookTouchId = null;
      this.fireTouchIds.clear();
      this._resetJoystickVisual();
      if (document.pointerLockElement) {
        try { document.exitPointerLock(); } catch (_) {}
      }
    }
  }

  consumePulses() {
    const out = { ...this.pulses };
    this.pulses.jump = false;
    this.pulses.crouch = false;
    this.pulses.reload = false;
    this.pulses.switchWeapon = false;
    this.pulses.slotIndex = -1;
    this.pulses.toggleView = false;
    this.pulses.interact = false;
    this.pulses.pause = false;
    this.pulses.nvg = false;
    return out;
  }

  consumeLookDelta(isAds = false) {
    const mult = this.sensitivity * (isAds ? this.adsSensitivity : 1.0);
    const dx = this.lookDX * mult;
    const dy = this.lookDY * mult;
    this.lookDX = 0;
    this.lookDY = 0;
    return { dx, dy };
  }

  updateMovementState() {
    if (!this.enabled || this.editLayoutMode) {
      this.moveX = 0;
      this.moveZ = 0;
      this.sprint = false;
      return;
    }

    let kx = 0;
    let kz = 0;
    if (this.keys.has('KeyA') || this.keys.has('ArrowLeft')) kx -= 1;
    if (this.keys.has('KeyD') || this.keys.has('ArrowRight')) kx += 1;
    if (this.keys.has('KeyW') || this.keys.has('ArrowUp')) kz += 1;
    if (this.keys.has('KeyS') || this.keys.has('ArrowDown')) kz -= 1;

    if (kx !== 0 || kz !== 0) {
      const len = Math.hypot(kx, kz) || 1;
      this.moveX = kx / len;
      this.moveZ = kz / len;
      this.sprint = (this.keys.has('ShiftLeft') || this.keys.has('ShiftRight')) && kz > 0.2;
    } else {
      this.moveX = this.joyVec.x;
      this.moveZ = this.joyVec.y;
      this.sprint = this.joySprint;
    }

    const mouseFire = this.mouseButtons.has(0);
    this.firing = mouseFire || this.fireTouchIds.size > 0;
  }

  _bindKeyboardMouse() {
    window.addEventListener('contextmenu', (e) => e.preventDefault());

    window.addEventListener('keydown', (e) => {
      if (e.code === 'Escape' || e.code === 'KeyP') {
        if (this.enabled) this.pulses.pause = true;
        return;
      }
      if (!this.enabled || this.editLayoutMode) return;

      this.keys.add(e.code);
      if (e.repeat) return;

      switch (e.code) {
        case 'Space':
          e.preventDefault();
          this.pulses.jump = true;
          break;
        case 'KeyC':
        case 'ControlLeft':
          this.pulses.crouch = true;
          break;
        case 'KeyR':
          this.pulses.reload = true;
          break;
        case 'KeyV':
          this.pulses.toggleView = true;
          break;
        case 'KeyQ':
          this.pulses.switchWeapon = true;
          break;
        case 'Digit1':
          this.pulses.slotIndex = 0;
          break;
        case 'Digit2':
          this.pulses.slotIndex = 1;
          break;
        case 'Digit3':
          this.pulses.slotIndex = 2;
          break;
        case 'KeyF':
        case 'KeyE':
          this.pulses.interact = true;
          break;
        case 'KeyN':
          this.pulses.nvg = true;
          break;
        default:
          break;
      }
    });

    window.addEventListener('keyup', (e) => {
      this.keys.delete(e.code);
    });

    // Pointer lock + desktop mouse firing & aiming
    this.canvasWrap.addEventListener('mousedown', (e) => {
      if (!this.enabled || this.editLayoutMode) return;
      if (document.pointerLockElement !== this.canvasWrap && this.canvasWrap.requestPointerLock) {
        try {
          const p = this.canvasWrap.requestPointerLock();
          if (p && typeof p.catch === 'function') p.catch(() => {});
        } catch (_) {}
      }
      this.mouseButtons.add(e.button);
      if (e.button === 2) {
        this.ads = true;
        this._syncAdsBtn();
      }
    });

    window.addEventListener('mouseup', (e) => {
      this.mouseButtons.delete(e.button);
      if (e.button === 2 && this.enabled) {
        this.ads = false;
        this._syncAdsBtn();
      }
    });

    window.addEventListener('mousemove', (e) => {
      if (!this.enabled || this.editLayoutMode) return;
      if (document.pointerLockElement === this.canvasWrap) {
        this.lookDX -= e.movementX * 0.0022;
        this.lookDY -= e.movementY * 0.0022;
      } else if (this.mouseButtons.has(0) || this.mouseButtons.has(2)) {
        // Smooth fallback if browser/iframe blocks PointerLock
        this.lookDX -= e.movementX * 0.0032;
        this.lookDY -= e.movementY * 0.0032;
      }
    });

    window.addEventListener(
      'wheel',
      (e) => {
        if (!this.enabled || this.editLayoutMode) return;
        if (Math.abs(e.deltaY) > 8) this.pulses.switchWeapon = true;
      },
      { passive: true }
    );
  }

  _bindTouchControls() {
    const joyZone = document.getElementById('joystick-zone');
    const joyStick = document.getElementById('joystick-stick');
    const lookZone = document.getElementById('touch-look-zone');

    // 1. Virtual Left Joystick (walk inner ring, sprint outer ring)
    if (joyZone && joyStick) {
      joyZone.addEventListener(
        'touchstart',
        (e) => {
          if (this.editLayoutMode) return;
          e.preventDefault();
          const t = e.changedTouches[0];
          this.joyTouchId = t.identifier;
          const rect = joyZone.getBoundingClientRect();
          this.joyOrigin = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
          this._updateJoystick(t.clientX, t.clientY, rect.width * 0.42);
        },
        { passive: false }
      );

      window.addEventListener(
        'touchmove',
        (e) => {
          if (this.joyTouchId === null || this.editLayoutMode) return;
          for (const t of e.changedTouches) {
            if (t.identifier === this.joyTouchId) {
              const rect = joyZone.getBoundingClientRect();
              this._updateJoystick(t.clientX, t.clientY, rect.width * 0.42);
            }
          }
        },
        { passive: false }
      );

      const endJoy = (e) => {
        if (this.joyTouchId === null) return;
        for (const t of e.changedTouches) {
          if (t.identifier === this.joyTouchId) {
            this.joyTouchId = null;
            this._resetJoystickVisual();
          }
        }
      };
      window.addEventListener('touchend', endJoy);
      window.addEventListener('touchcancel', endJoy);
    }

    // 2. Right Touch Look Pad
    if (lookZone) {
      lookZone.addEventListener(
        'touchstart',
        (e) => {
          if (!this.enabled || this.editLayoutMode) return;
          e.preventDefault();
          const t = e.changedTouches[0];
          this.lookTouchId = t.identifier;
          this.lookLast = { x: t.clientX, y: t.clientY };
        },
        { passive: false }
      );

      window.addEventListener(
        'touchmove',
        (e) => {
          if (!this.enabled || this.editLayoutMode) return;
          for (const t of e.changedTouches) {
            if (t.identifier === this.lookTouchId) {
              const dx = t.clientX - this.lookLast.x;
              const dy = t.clientY - this.lookLast.y;
              this.lookLast = { x: t.clientX, y: t.clientY };
              this.lookDX -= dx * 0.0046;
              this.lookDY -= dy * 0.0042;
            }
          }
        },
        { passive: false }
      );

      const endLook = (e) => {
        for (const t of e.changedTouches) {
          if (t.identifier === this.lookTouchId) this.lookTouchId = null;
        }
      };
      window.addEventListener('touchend', endLook);
      window.addEventListener('touchcancel', endLook);
    }

    // 3. Fire Buttons (Right Main Trigger + Left Claw Trigger — supports drag-aim while holding Fire!)
    for (const btnId of ['tbtn-fire', 'tbtn-fire-left']) {
      const btn = document.getElementById(btnId);
      if (!btn) continue;
      const fireDragPrev = new Map();

      btn.addEventListener(
        'touchstart',
        (e) => {
          if (this.editLayoutMode) return;
          e.preventDefault();
          e.stopPropagation();
          btn.classList.add('pressed');
          for (const t of e.changedTouches) {
            this.fireTouchIds.add(t.identifier);
            fireDragPrev.set(t.identifier, { x: t.clientX, y: t.clientY });
          }
        },
        { passive: false }
      );

      btn.addEventListener(
        'touchmove',
        (e) => {
          if (this.editLayoutMode) return;
          e.preventDefault();
          for (const t of e.changedTouches) {
            const prev = fireDragPrev.get(t.identifier);
            if (prev && btnId === 'tbtn-fire') {
              this.lookDX -= (t.clientX - prev.x) * 0.0042;
              this.lookDY -= (t.clientY - prev.y) * 0.0038;
              fireDragPrev.set(t.identifier, { x: t.clientX, y: t.clientY });
            }
          }
        },
        { passive: false }
      );

      const releaseFire = (e) => {
        for (const t of e.changedTouches) {
          this.fireTouchIds.delete(t.identifier);
          fireDragPrev.delete(t.identifier);
        }
        if (this.fireTouchIds.size === 0) btn.classList.remove('pressed');
      };
      btn.addEventListener('touchend', releaseFire);
      btn.addEventListener('touchcancel', releaseFire);
    }

    // 4. Tactical Action Buttons (works with both Touch AND Click for hybrid devices/testing!)
    const bindPulseBtn = (id, onTrigger) => {
      const el = document.getElementById(id);
      if (!el) return;
      const handler = (e) => {
        if (this.editLayoutMode) return;
        e.preventDefault();
        e.stopPropagation();
        onTrigger(el);
      };
      el.addEventListener('touchstart', handler, { passive: false });
      el.addEventListener('click', handler);
    };

    bindPulseBtn('tbtn-ads', () => {
      this.ads = !this.ads;
      this._syncAdsBtn();
    });
    bindPulseBtn('tbtn-jump', () => { this.pulses.jump = true; });
    bindPulseBtn('tbtn-crouch', () => { this.pulses.crouch = true; });
    bindPulseBtn('tbtn-reload', () => { this.pulses.reload = true; });
    bindPulseBtn('tbtn-switch', () => { this.pulses.switchWeapon = true; });
    bindPulseBtn('tbtn-view', () => { this.pulses.toggleView = true; });
    bindPulseBtn('tbtn-interact', () => { this.pulses.interact = true; });

    // 5. Drag-to-Customize Touch Layout Mode
    this._bindHudLayoutEditor();
  }

  _syncAdsBtn() {
    const btn = document.getElementById('tbtn-ads');
    if (btn) btn.classList.toggle('toggled-on', this.ads);
  }

  _updateJoystick(clientX, clientY, maxRadius) {
    const stick = document.getElementById('joystick-stick');
    let dx = clientX - this.joyOrigin.x;
    let dy = clientY - this.joyOrigin.y;
    const dist = Math.hypot(dx, dy);
    const clamped = Math.min(dist, maxRadius);
    const angle = Math.atan2(dy, dx);
    const cx = Math.cos(angle) * clamped;
    const cy = Math.sin(angle) * clamped;

    if (stick) {
      stick.style.transform = `translate(${cx.toFixed(1)}px, ${cy.toFixed(1)}px)`;
    }

    const norm = maxRadius > 0 ? clamped / maxRadius : 0;
    if (norm < 0.1) {
      this.joyVec.x = 0;
      this.joyVec.y = 0;
      this.joySprint = false;
    } else {
      this.joyVec.x = (cx / maxRadius);
      this.joyVec.y = -(cy / maxRadius);
      this.joySprint = norm > 0.82 && this.joyVec.y > 0.45;
    }
  }

  _resetJoystickVisual() {
    const stick = document.getElementById('joystick-stick');
    if (stick) stick.style.transform = 'translate(0px, 0px)';
    this.joyVec.x = 0;
    this.joyVec.y = 0;
    this.joySprint = false;
  }

  _bindHudLayoutEditor() {
    const draggables = document.querySelectorAll('.touch-draggable');
    draggables.forEach((el) => {
      el.addEventListener('pointerdown', (e) => {
        if (!this.editLayoutMode) return;
        e.preventDefault();
        e.stopPropagation();
        const rect = el.getBoundingClientRect();
        this.dragTarget = el;
        this.dragOffset = { x: e.clientX - rect.left, y: e.clientY - rect.top };
        el.setPointerCapture(e.pointerId);
      });

      el.addEventListener('pointermove', (e) => {
        if (!this.editLayoutMode || this.dragTarget !== el) return;
        const leftPct = ((e.clientX - this.dragOffset.x) / window.innerWidth) * 100;
        const topPct = ((e.clientY - this.dragOffset.y) / window.innerHeight) * 100;
        el.style.left = `${Math.max(1, Math.min(92, leftPct)).toFixed(1)}%`;
        el.style.top = `${Math.max(4, Math.min(88, topPct)).toFixed(1)}%`;
        el.style.right = 'auto';
        el.style.bottom = 'auto';
      });

      el.addEventListener('pointerup', () => {
        this.dragTarget = null;
      });
    });
  }

  saveTouchLayout() {
    const data = {};
    document.querySelectorAll('.touch-draggable').forEach((el) => {
      const id = el.dataset.controlId;
      if (id && el.style.left && el.style.top) {
        data[id] = { left: el.style.left, top: el.style.top };
      }
    });
    try {
      localStorage.setItem(TOUCH_LAYOUT_KEY, JSON.stringify(data));
    } catch (_) {}
  }

  loadTouchLayout() {
    try {
      const raw = localStorage.getItem(TOUCH_LAYOUT_KEY);
      if (!raw) return;
      const data = JSON.parse(raw);
      document.querySelectorAll('.touch-draggable').forEach((el) => {
        const id = el.dataset.controlId;
        if (id && data[id]) {
          el.style.left = data[id].left;
          el.style.top = data[id].top;
          el.style.right = 'auto';
          el.style.bottom = 'auto';
        }
      });
    } catch (_) {}
  }

  resetTouchLayout() {
    try { localStorage.removeItem(TOUCH_LAYOUT_KEY); } catch (_) {}
    document.querySelectorAll('.touch-draggable').forEach((el) => {
      el.style.left = '';
      el.style.top = '';
      el.style.right = '';
      el.style.bottom = '';
    });
  }
}
