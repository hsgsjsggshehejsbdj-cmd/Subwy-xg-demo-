#!/usr/bin/env python3
"""
SUBWY XG DEMO — Portable Local & Wi-Fi Mobile HTTP Server
Works on Windows, Linux, macOS, and Termux (Android) with zero external packages.
"""
import http.server
import mimetypes
import os
import socket
import socketserver
import sys

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8080

mimetypes.add_type("application/javascript", ".js")
mimetypes.add_type("model/gltf-binary", ".glb")
mimetypes.add_type("audio/wav", ".wav")
mimetypes.add_type("application/manifest+json", ".json")


class GameHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "public, max-age=60")
        super().end_headers()

    def log_message(self, fmt, *args):
        pass


def get_lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


if __name__ == "__main__":
    os.chdir(os.path.dirname(os.path.abspath(__file__)) or ".")
    socketserver.TCPServer.allow_reuse_address = True
    lan_ip = get_lan_ip()
    with socketserver.ThreadingTCPServer(("0.0.0.0", PORT), GameHTTPRequestHandler) as httpd:
        print("=====================================================", flush=True)
        print("  SUBWY XG DEMO — 3D TACTICAL WAR SERVER RUNNING", flush=True)
        print(f"  Windows / PC Browser : http://localhost:{PORT}", flush=True)
        print(f"  Android / iPhone WiFi: http://{lan_ip}:{PORT}", flush=True)
        print("=====================================================", flush=True)
        httpd.serve_forever()
