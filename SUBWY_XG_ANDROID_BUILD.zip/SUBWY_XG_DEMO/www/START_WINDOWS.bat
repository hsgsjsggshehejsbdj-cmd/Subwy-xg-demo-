@echo off
title SUBWY XG DEMO - 3D Tactical War Server
echo Starting SUBWY XG DEMO local server on http://localhost:8080 ...
start "" "http://localhost:8080"
python START_SERVER.py 8080 || py START_SERVER.py 8080 || npx --yes serve -l 8080 .
pause
