// vehicles.js — Drivable Tanks, APCs, Jeeps, Trucks, Attack Helicopters & Fighter Jet Flybys
import * as THREE from 'three';

export const VEHICLE_CATALOG = {
  tank: {
    id: 'tank',
    name: 'M1A3 ABRAMS-XG',
    nameAr: 'دبابة قتال رئيسية M1A3',
    role: 'Main Battle Tank • 120mm Cannon',
    roleAr: 'دبابة قتال ثقيلة بمدفع 120 ملم ودوران برج 360°',
    maxHp: 780,
    maxSpeed: 12.5,
    turnRate: 1.35,
    drivable: true,
    fireCooldown: 2.1,
    shellDamage: 520,
    shellRadius: 10.5,
    stats: { armor: 100, speed: 58, power: 100 },
  },
  apc: {
    id: 'apc',
    name: 'BTR-XG 8x8 APC',
    nameAr: 'ناقلة جنود مدرعة BTR-XG',
    role: 'Armored Carrier • 30mm Autocannon',
    roleAr: 'مدرعة ثمانية الدفع بمدفع آلي 30 ملم سريع',
    maxHp: 540,
    maxSpeed: 16.5,
    turnRate: 1.65,
    drivable: true,
    fireCooldown: 0.28,
    shellDamage: 95,
    shellRadius: 4.5,
    stats: { armor: 82, speed: 78, power: 76 },
  },
  jeep: {
    id: 'jeep',
    name: 'JLTV TACTICAL 4x4',
    nameAr: 'جيب عسكري مصفح JLTV',
    role: 'Fast Recon Jeep • .50 Cal Roof MG',
    roleAr: 'مركبة استطلاع سريعة برشاش ثقيل عيار 50',
    maxHp: 340,
    maxSpeed: 22.0,
    turnRate: 2.15,
    drivable: true,
    fireCooldown: 0.13,
    hitscanDamage: 38,
    stats: { armor: 54, speed: 98, power: 58 },
  },
  truck: {
    id: 'truck',
    name: 'M939 TROOP TRUCK',
    nameAr: 'شاحنة نقل جنود M939',
    role: '6x6 Heavy Troop Transport',
    roleAr: 'شاحنة نقل عسكرية سداسية الدفع',
    maxHp: 320,
    maxSpeed: 17.5,
    turnRate: 1.45,
    drivable: true,
    fireCooldown: 0.5,
    stats: { armor: 48, speed: 72, power: 25 },
  },
  heli: {
    id: 'heli',
    name: 'AH-64X VIPER GUNSHIP',
    nameAr: 'مروحية هجومية AH-64X',
    role: 'Close Air Support Attack Helicopter',
    roleAr: 'مروحية قتالية مسلحة بصواريخ هيدرا ومدفع 30 ملم',
    maxHp: 420,
    maxSpeed: 24.0,
    drivable: false,
    stats: { armor: 62, speed: 92, power: 94 },
  },
  jet: {
    id: 'jet',
    name: 'F-22X STRIKE RAPTOR',
    nameAr: 'مقاتلة حربية F-22X',
    role: 'Supersonic Tactical Strike Fighter',
    roleAr: 'طائرة مقاتلة أسرع من الصوت للضربات الجوية',
    maxHp: 500,
    maxSpeed: 75.0,
    drivable: false,
    stats: { armor: 60, speed: 100, power: 100 },
  },
};

export class VehicleInstance {
  constructor({ type, team = 'ally', pos, yaw = 0, assets, scene, audio }) {
    this.type = type;
    this.spec = VEHICLE_CATALOG[type] || VEHICLE_CATALOG.jeep;
    this.team = team; // 'ally' | 'enemy'
    this.driver = null; // null | 'player' | 'ai'

    this.hp = this.spec.maxHp;
    this.maxHp = this.spec.maxHp;
    this.destroyed = false;
    this.speed = 0;
    this.yaw = yaw;
    this.fireTimer = 1.0;
    this.smokeTimer = 0;
    this.orbitAngle = Math.random() * Math.PI * 2;
    this.orbitCenter = pos.clone();

    const gltf = assets.models.get(`vehicle_${type}`);
    this.root = gltf ? gltf.scene.clone(true) : new THREE.Group();
    this.root.position.copy(pos);
    this.root.rotation.y = yaw;

    // Tint enemy armor darker iron-gray so friend vs foe armor is unmistakable!
    if (team === 'enemy') {
      this.root.traverse((c) => {
        if (c.isMesh && c.material && c.material.name && c.material.name.startsWith('Armor')) {
          c.material = c.material.clone();
          c.material.color.setHex(0x52575e);
        }
      });
    }

    this.root.traverse((c) => {
      if (c.isMesh) {
        c.castShadow = true;
        c.receiveShadow = true;
      }
    });

    this.turret = this.root.getObjectByName('Turret');
    this.barrel = this.root.getObjectByName('Barrel');
    this.mainRotor = this.root.getObjectByName('MainRotor');
    this.tailRotor = this.root.getObjectByName('TailRotor');
    this.wheels = [];
    this.root.traverse((c) => {
      if (c.name && c.name.startsWith('Wheel')) this.wheels.push(c);
    });

    scene.add(this.root);

    // Spatial looping diesel engine sound
    this.engineLoop = audio.createSpatialLoop('tank_engine', pos, {
      volume: type === 'tank' ? 0.52 : 0.36,
      refDist: 16,
      rate: type === 'heli' ? 1.55 : type === 'jeep' ? 1.28 : 0.95,
    });
  }

  takeDamage(amount) {
    if (this.destroyed) return false;
    this.hp = Math.max(0, this.hp - amount);
    if (this.hp <= 0) {
      this.destroyed = true;
      if (this.engineLoop) {
        this.engineLoop.stop();
        this.engineLoop = null;
      }
      return true;
    }
    return false;
  }

  dispose(scene) {
    if (this.engineLoop) {
      this.engineLoop.stop();
      this.engineLoop = null;
    }
    scene.remove(this.root);
  }
}

export class VehicleManager {
  constructor(scene, assets, audio, world, weaponSys) {
    this.scene = scene;
    this.assets = assets;
    this.audio = audio;
    this.world = world;
    this.weaponSys = weaponSys;

    this.vehicles = [];
    this.jets = [];
    this.jetFlybyTimer = 14.0;
    this.onVehicleDestroyed = null;

    this._raycaster = new THREE.Raycaster();
  }

  clearAll() {
    for (const v of this.vehicles) v.dispose(this.scene);
    this.vehicles = [];
    for (const j of this.jets) this.scene.remove(j.mesh);
    this.jets = [];
  }

  spawnVehicle({ type = 'tank', team = 'ally', x = 0, z = 0, y = null, yaw = 0, aiDriver = false }) {
    const fy = y !== null ? y : this.world.getFloorHeightAt(x, z, 12);
    const inst = new VehicleInstance({
      type,
      team,
      pos: new THREE.Vector3(x, fy, z),
      yaw,
      assets: this.assets,
      scene: this.scene,
      audio: this.audio,
    });
    if (aiDriver) inst.driver = 'ai';
    this.vehicles.push(inst);
    return inst;
  }

  spawnFighterJetFlyby(targetZ = -40, dropStrike = false) {
    const gltf = this.assets.models.get('vehicle_jet');
    if (!gltf) return;
    const mesh = gltf.scene.clone(true);
    const startPos = new THREE.Vector3((Math.random() - 0.5) * 45, 38 + Math.random() * 10, 175);
    mesh.position.copy(startPos);
    mesh.rotation.y = Math.PI; // fly north (-Z) across the battlefield!
    this.scene.add(mesh);

    this.audio.playSpatial('jet_flyby', new THREE.Vector3(startPos.x, 22, targetZ), {
      volume: 0.85,
      refDist: 38,
      maxDist: 360,
    });

    this.jets.push({
      mesh,
      speed: 88,
      dropStrike,
      strikeZ: targetZ,
      dropped: false,
    });
  }

  findNearestDrivable(pos, maxDist = 5.8) {
    let best = null;
    let bestD = maxDist;
    for (const v of this.vehicles) {
      if (v.destroyed || !v.spec.drivable) continue;
      if (v.team === 'enemy' && v.driver === 'ai') continue;
      const d = v.root.position.distanceTo(pos);
      if (d < bestD) {
        bestD = d;
        best = v;
      }
    }
    return best;
  }

  raycastVehicles(origin, dir, maxDist = 320, filterTeam = 'enemy') {
    let best = null;
    let bestT = maxDist;

    for (const v of this.vehicles) {
      if (v.destroyed) continue;
      if (filterTeam && v.team !== filterTeam) continue;

      const radius = v.type === 'tank' || v.type === 'apc' ? 3.2 : v.type === 'heli' ? 3.5 : 2.3;
      const center = v.root.position.clone().add(new THREE.Vector3(0, 1.35, 0));
      const oc = center.clone().sub(origin);
      const tProj = oc.dot(dir);
      if (tProj < 0.5 || tProj > bestT) continue;

      const closestPt = origin.clone().addScaledVector(dir, tProj);
      if (closestPt.distanceToSquared(center) <= radius * radius) {
        bestT = tProj;
        best = {
          vehicle: this._wrapDamageable(v),
          distance: tProj,
          point: closestPt,
        };
      }
    }
    return best;
  }

  _wrapDamageable(v) {
    return {
      instance: v,
      takeDamage: (dmg) => this._damageVehicle(v, dmg),
    };
  }

  _damageVehicle(v, dmg) {
    if (v.destroyed) return false;
    const killed = v.takeDamage(dmg);
    if (killed) {
      this.world.spawnExplosion(v.root.position, 2.2, true);
      // Scorch hull dark & pop turret tilted!
      v.root.traverse((c) => {
        if (c.isMesh && c.material) {
          c.material = c.material.clone();
          c.material.color.setHex(0x1f1d1b);
        }
      });
      if (v.turret) {
        v.turret.rotation.z = 0.28;
        v.turret.position.y += 0.35;
      }
      if (v.type === 'heli') {
        v.root.position.y = this.world.getTerrainHeight(v.root.position.x, v.root.position.z);
        v.root.rotation.z = 0.55;
      }
      if (this.onVehicleDestroyed) this.onVehicleDestroyed(v);
    }
    return killed;
  }

  applyExplosionDamage(center, radius, maxDamage, owner = 'player') {
    let destroyedCount = 0;
    for (const v of this.vehicles) {
      if (v.destroyed) continue;
      if (owner === 'player' && v.driver === 'player') continue;
      const d = v.root.position.distanceTo(center);
      if (d <= radius) {
        const dmg = maxDamage * (1.0 - (d / radius) * 0.65);
        if (this._damageVehicle(v, dmg) && v.team === 'enemy') {
          destroyedCount++;
        }
      }
    }
    return destroyedCount;
  }

  update(dt, { controls, player, cameraSys, enemyMgr, isPlaying }) {
    // Periodic ambient Fighter Jet supersonic flyby during active combat!
    if (isPlaying) {
      this.jetFlybyTimer -= dt;
      if (this.jetFlybyTimer <= 0) {
        this.jetFlybyTimer = 22 + Math.random() * 14;
        this.spawnFighterJetFlyby(player ? player.position.z - 35 : -40, false);
      }
    }

    // Update flying Fighter Jets
    for (let i = this.jets.length - 1; i >= 0; i--) {
      const j = this.jets[i];
      j.mesh.position.z -= j.speed * dt;
      if (j.dropStrike && !j.dropped && j.mesh.position.z <= j.strikeZ) {
        j.dropped = true;
        const bx = j.mesh.position.x;
        const bz = j.strikeZ;
        const by = this.world.getTerrainHeight(bx, bz);
        this.world.spawnExplosion(new THREE.Vector3(bx, by, bz), 2.1, true);
      }
      if (j.mesh.position.z < -220) {
        this.scene.remove(j.mesh);
        this.jets.splice(i, 1);
      }
    }

    // Update Ground Vehicles & Attack Helicopters
    for (const v of this.vehicles) {
      if (v.destroyed) {
        // Rising black wreck smoke
        v.smokeTimer -= dt;
        if (v.smokeTimer <= 0) {
          v.smokeTimer = 0.28;
          this.world.spawnPuff(v.root.position.clone().add(new THREE.Vector3(0, 1.4, 0)), {
            color: 0x22201e,
            size: 1.25,
            life: 1.8,
            grow: 2.2,
          });
        }
        continue;
      }

      // Damaged vehicle warning smoke (<55% HP)
      if (v.hp < v.maxHp * 0.55) {
        v.smokeTimer -= dt;
        if (v.smokeTimer <= 0) {
          v.smokeTimer = 0.22;
          this.world.spawnPuff(v.root.position.clone().add(new THREE.Vector3(0, 1.6, 0)), {
            color: v.hp < v.maxHp * 0.28 ? 0xff5a14 : 0x3b3835,
            size: 0.9,
            life: 1.2,
          });
        }
      }

      if (v.type === 'heli') {
        this._updateHelicopter(v, dt, player);
        continue;
      }

      if (v.driver === 'player' && isPlaying) {
        this._updatePlayerDrivenVehicle(v, dt, controls, player, cameraSys, enemyMgr);
      } else if (v.driver === 'ai' && isPlaying && player) {
        this._updateAIVehicle(v, dt, player);
      } else if (v.engineLoop) {
        v.engineLoop.update(v.root.position, 0.05, 0.45);
      }
    }
  }

  _updatePlayerDrivenVehicle(v, dt, controls, player, cameraSys, enemyMgr) {
    controls.updateMovementState();
    const throttle = controls.moveZ;
    const steer = -controls.moveX;

    const targetSpeed = throttle * v.spec.maxSpeed;
    v.speed = THREE.MathUtils.lerp(v.speed, targetSpeed, Math.min(1, dt * 3.8));

    if (Math.abs(v.speed) > 0.2 || Math.abs(steer) > 0.05) {
      const revSign = v.speed >= -0.2 ? 1 : -1;
      v.yaw += steer * v.spec.turnRate * revSign * dt;
    }

    // Vehicle forward in Three.js glTF (+Z is forward when yaw=0; let's align with sin(yaw), cos(yaw))
    const fwdX = Math.sin(v.yaw);
    const fwdZ = Math.cos(v.yaw);
    v.root.position.x += fwdX * v.speed * dt;
    v.root.position.z += fwdZ * v.speed * dt;

    this.world.resolveHorizontalCollision(v.root.position, 2.1, v.root.position.y, 2.6);
    const groundY = this.world.getFloorHeightAt(v.root.position.x, v.root.position.z, v.root.position.y + 1.5);
    v.root.position.y = THREE.MathUtils.lerp(v.root.position.y, groundY, Math.min(1, dt * 14));

    // Align vehicle pitch/roll subtly to terrain slope!
    const hFront = this.world.getFloorHeightAt(v.root.position.x + fwdX * 2.2, v.root.position.z + fwdZ * 2.2, groundY + 1.5);
    const slopePitch = Math.atan2(hFront - groundY, 2.2);
    v.root.rotation.set(-slopePitch * 0.65, v.yaw, 0, 'YXZ');

    // Spin Wheels + Tread Exhaust Dust
    for (const w of v.wheels) {
      w.rotation.x += (v.speed / 0.52) * dt;
    }
    if (Math.abs(v.speed) > 2.5 && Math.random() < 0.45) {
      this.world.spawnPuff(
        v.root.position.clone().addScaledVector(new THREE.Vector3(fwdX, 0, fwdZ), -2.6),
        { color: 0xcbb389, size: 0.75, life: 0.75, grow: 1.8 }
      );
    }

    if (v.engineLoop) {
      v.engineLoop.update(v.root.position, Math.abs(v.speed) / v.spec.maxSpeed, 1.0);
    }

    // Aim Independent 360° Turret & Barrel toward Camera Aim Direction!
    if (v.turret) {
      // Player camera yaw=0 looks along -Z, which corresponds to world angle Math.PI for a +Z-forward mesh!
      const desiredWorldYaw = player.yaw + Math.PI;
      const relYaw = desiredWorldYaw - v.yaw;
      v.turret.rotation.y = relYaw;
      if (v.barrel) {
        v.barrel.rotation.x = THREE.MathUtils.clamp(-player.pitch, -0.45, 0.16);
      }
    }

    // Fire Tank 120mm Cannon / APC 30mm Autocannon / Jeep .50 Cal HMG!
    if (v.fireTimer > 0) v.fireTimer -= dt;
    if (controls.firing && v.fireTimer <= 0 && v.type !== 'truck') {
      v.fireTimer = v.spec.fireCooldown;
      const camOrigin = new THREE.Vector3();
      const camDir = new THREE.Vector3();
      cameraSys.camera.getWorldPosition(camOrigin);
      cameraSys.camera.getWorldDirection(camDir);

      const muzzlePos = v.root.position.clone().add(new THREE.Vector3(0, 2.15, 0)).addScaledVector(camDir, 3.8);

      if (v.spec.shellDamage) {
        this.audio.play2D('explosion_heavy', { volume: v.type === 'tank' ? 0.9 : 0.55, rate: v.type === 'tank' ? 1.15 : 1.65 });
        cameraSys.addShake(v.type === 'tank' ? 0.55 : 0.18);
        this.world.spawnPuff(muzzlePos, { color: 0xffb74d, size: v.type === 'tank' ? 1.5 : 0.7, life: 0.45 });
        this.weaponSys.spawnExplosiveProjectile(muzzlePos, camDir, {
          speed: 92,
          damage: v.spec.shellDamage,
          radius: v.spec.shellRadius,
          owner: 'player',
          scale: v.type === 'tank' ? 1.85 : 0.95,
        });
      } else if (v.spec.hitscanDamage) {
        this.audio.play2D('rifle_shot', { volume: 0.85, rate: 0.78 });
        cameraSys.addShake(0.06);
        this.weaponSys._tmpMuzzle.copy(muzzlePos);
        this.weaponSys._fireRay(
          camOrigin,
          camDir,
          { damage: v.spec.hitscanDamage, headMult: 2.0, armorDamage: 22, range: 240 },
          enemyMgr,
          this
        );
      }
    }
  }

  _updateAIVehicle(v, dt, player) {
    const toPlayer = player.position.clone().sub(v.root.position);
    const dist = toPlayer.length();

    // Patrol slowly along road or advance to engage within 115m
    if (dist < 120 && !player.dead) {
      if (dist > 38) {
        const goalYaw = Math.atan2(toPlayer.x, toPlayer.z);
        v.yaw = THREE.MathUtils.lerp(v.yaw, goalYaw, Math.min(1, dt * 1.1));
        v.speed = THREE.MathUtils.lerp(v.speed, 4.2, dt * 2);
      } else {
        v.speed = THREE.MathUtils.lerp(v.speed, 0, dt * 3);
      }

      v.root.position.x += Math.sin(v.yaw) * v.speed * dt;
      v.root.position.z += Math.cos(v.yaw) * v.speed * dt;
      v.root.position.y = this.world.getFloorHeightAt(v.root.position.x, v.root.position.z, v.root.position.y + 1.5);
      v.root.rotation.y = v.yaw;

      for (const w of v.wheels) w.rotation.x += v.speed * dt * 1.8;

      if (v.turret) {
        const aimYaw = Math.atan2(toPlayer.x, toPlayer.z);
        v.turret.rotation.y = aimYaw - v.yaw;
      }

      v.fireTimer -= dt;
      if (v.fireTimer <= 0 && dist < 105) {
        v.fireTimer = v.type === 'tank' ? 4.4 : 1.6;
        const muzzle = v.root.position.clone().add(new THREE.Vector3(0, 2.1, 0));
        const aimTarget = player.position.clone().add(
          new THREE.Vector3((Math.random() - 0.5) * 4.5, 0.8, (Math.random() - 0.5) * 4.5)
        );
        const dir = aimTarget.sub(muzzle).normalize();
        this.audio.playSpatial('explosion_heavy', muzzle, { volume: 0.75, refDist: 22 });
        this.weaponSys.spawnExplosiveProjectile(muzzle.addScaledVector(dir, 3.6), dir, {
          speed: 62,
          damage: v.type === 'tank' ? 42 : 20,
          radius: 7.5,
          owner: 'enemy',
          scale: v.type === 'tank' ? 1.45 : 0.85,
        });
      }
    }

    if (v.engineLoop) {
      v.engineLoop.update(v.root.position, Math.abs(v.speed) / 12, 0.75);
    }
  }

  _updateHelicopter(v, dt, player) {
    if (v.mainRotor) v.mainRotor.rotation.y += dt * 26;
    if (v.tailRotor) v.tailRotor.rotation.x += dt * 30;

    v.orbitAngle += dt * 0.36;
    const radius = 34;
    const gx = v.orbitCenter.x + Math.cos(v.orbitAngle) * radius;
    const gz = v.orbitCenter.z + Math.sin(v.orbitAngle) * radius;
    v.root.position.set(gx, 22 + Math.sin(v.orbitAngle * 2.3) * 1.4, gz);
    v.root.rotation.set(0.12, -v.orbitAngle, 0.14, 'YXZ');

    if (v.engineLoop) v.engineLoop.update(v.root.position, 0.8, 0.85);

    if (v.team === 'enemy' && player && !player.dead) {
      const dist = v.root.position.distanceTo(player.position);
      v.fireTimer -= dt;
      if (v.fireTimer <= 0 && dist < 115) {
        v.fireTimer = 2.6 + Math.random();
        const muz = v.root.position.clone().add(new THREE.Vector3(0, -0.8, 0));
        const aim = player.position.clone().add(new THREE.Vector3((Math.random() - 0.5) * 3.5, 1.0, (Math.random() - 0.5) * 3.5));
        this.world.spawnTracer(muz, aim, 0xff5722);
        this.audio.playSpatial('rifle_shot', muz, { volume: 0.75, refDist: 22 });
        if (aim.distanceTo(player.position) < 2.2) {
          player.takeDamage(12, v.root.position);
        }
      }
    }
  }
}
