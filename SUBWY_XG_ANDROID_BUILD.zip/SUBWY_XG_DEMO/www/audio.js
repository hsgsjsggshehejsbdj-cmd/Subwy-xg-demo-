// audio.js — 3D Spatial Web Audio Engine & Haptic Feedback for SUBWY XG DEMO
import * as THREE from 'three';

const AUDIO_MANIFEST = {
  menu_theme: './assets/audio/menu_theme.wav',
  rifle_shot: './assets/audio/rifle_shot.wav',
  sniper_shot: './assets/audio/sniper_shot.wav',
  shotgun_shot: './assets/audio/shotgun_shot.wav',
  pistol_shot: './assets/audio/pistol_shot.wav',
  rpg_launch: './assets/audio/rpg_launch.wav',
  explosion_heavy: './assets/audio/explosion_heavy.wav',
  reload_mech: './assets/audio/reload_mech.wav',
  footstep_sand: './assets/audio/footstep_sand.wav',
  tank_engine: './assets/audio/tank_engine.wav',
  jet_flyby: './assets/audio/jet_flyby.wav',
  wind_desert: './assets/audio/wind_desert.wav',
  radio_chatter: './assets/audio/radio_chatter.wav',
  bullet_whiz: './assets/audio/bullet_whiz.wav',
};

export class AudioEngine {
  constructor() {
    this.ctx = null;
    this.masterGain = null;
    this.sfxGain = null;
    this.musicGain = null;

    this.buffers = new Map();
    this.rawArrayBuffers = new Map();
    this.muted = false;
    this.masterVolume = 0.85;
    this.sfxVolume = 0.90;
    this.musicVolume = 0.65;
    this.vibrationEnabled = true;
    this.useHRTF = true;

    this.menuSource = null;
    this.windSource = null;
    this.windGainNode = null;
    this.wantMenuMusic = false;
    this.wantWindAmbience = false;

    this._camPos = new THREE.Vector3();
    this._camFwd = new THREE.Vector3(0, 0, -1);
    this._camUp = new THREE.Vector3(0, 1, 0);
    this._camQuat = new THREE.Quaternion();

    this._bindUnlockGesture();
  }

  _bindUnlockGesture() {
    const unlock = () => {
      this.ensureContext();
      if (this.ctx && this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }
      this._decodePendingBuffers().then(() => {
        if (this.wantMenuMusic && !this.menuSource) this.startMenuMusic();
        if (this.wantWindAmbience && !this.windSource) this.startWindAmbience();
      });
    };
    window.addEventListener('pointerdown', unlock, { passive: true });
    window.addEventListener('touchstart', unlock, { passive: true });
    window.addEventListener('keydown', unlock, { passive: true });
  }

  ensureContext() {
    if (this.ctx) return this.ctx;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    this.ctx = new AC();

    // Dynamics compressor keeps intense multi-explosion gunfights crisp without clipping on mobile speakers
    const comp = this.ctx.createDynamicsCompressor();
    comp.threshold.value = -10;
    comp.knee.value = 18;
    comp.ratio.value = 4;
    comp.attack.value = 0.003;
    comp.release.value = 0.18;

    this.masterGain = this.ctx.createGain();
    this.sfxGain = this.ctx.createGain();
    this.musicGain = this.ctx.createGain();

    this.sfxGain.connect(comp);
    this.musicGain.connect(comp);
    comp.connect(this.masterGain);
    this.masterGain.connect(this.ctx.destination);
    this._applyVolumes();
    return this.ctx;
  }

  async preloadAll(onProgress) {
    const entries = Object.entries(AUDIO_MANIFEST);
    let loaded = 0;
    await Promise.all(
      entries.map(async ([key, url]) => {
        try {
          const res = await fetch(url);
          if (res.ok) {
            const arr = await res.arrayBuffer();
            this.rawArrayBuffers.set(key, arr);
          }
        } catch (err) {
          console.warn('Audio fetch fallback for', key, err);
        } finally {
          loaded++;
          if (onProgress) onProgress(loaded / entries.length, key);
        }
      })
    );
    // Attempt immediate decode if AudioContext can be constructed
    this.ensureContext();
    await this._decodePendingBuffers();
  }

  async _decodePendingBuffers() {
    if (!this.ctx || this.rawArrayBuffers.size === 0) return;
    const jobs = [];
    for (const [key, raw] of this.rawArrayBuffers.entries()) {
      if (this.buffers.has(key)) continue;
      const copy = raw.slice(0);
      jobs.push(
        this.ctx
          .decodeAudioData(copy)
          .then((buf) => {
            this.buffers.set(key, buf);
            this.rawArrayBuffers.delete(key);
          })
          .catch(() => {})
      );
    }
    await Promise.all(jobs);
  }

  _applyVolumes() {
    if (!this.masterGain || !this.ctx) return;
    const now = this.ctx.currentTime;
    this.masterGain.gain.setTargetAtTime(this.muted ? 0 : this.masterVolume, now, 0.03);
    this.sfxGain.gain.setTargetAtTime(this.sfxVolume, now, 0.03);
    this.musicGain.gain.setTargetAtTime(this.musicVolume, now, 0.05);
  }

  setSettings({ masterVolume, sfxVolume, musicVolume, vibrationEnabled, quality }) {
    if (typeof masterVolume === 'number') this.masterVolume = masterVolume;
    if (typeof sfxVolume === 'number') this.sfxVolume = sfxVolume;
    if (typeof musicVolume === 'number') this.musicVolume = musicVolume;
    if (typeof vibrationEnabled === 'boolean') this.vibrationEnabled = vibrationEnabled;
    if (quality) this.useHRTF = quality !== 'LOW';
    this._applyVolumes();
  }

  toggleMute() {
    this.muted = !this.muted;
    this._applyVolumes();
    return !this.muted;
  }

  /** Updates the 3D Web Audio listener position & orientation from the active Three.js camera */
  updateListener(camera) {
    if (!this.ctx || !camera) return;
    camera.getWorldPosition(this._camPos);
    camera.getWorldQuaternion(this._camQuat);
    this._camFwd.set(0, 0, -1).applyQuaternion(this._camQuat).normalize();
    this._camUp.set(0, 1, 0).applyQuaternion(this._camQuat).normalize();

    const L = this.ctx.listener;
    const t = this.ctx.currentTime;
    if (L.positionX) {
      L.positionX.setTargetAtTime(this._camPos.x, t, 0.015);
      L.positionY.setTargetAtTime(this._camPos.y, t, 0.015);
      L.positionZ.setTargetAtTime(this._camPos.z, t, 0.015);
      L.forwardX.setTargetAtTime(this._camFwd.x, t, 0.015);
      L.forwardY.setTargetAtTime(this._camFwd.y, t, 0.015);
      L.forwardZ.setTargetAtTime(this._camFwd.z, t, 0.015);
      L.upX.setTargetAtTime(this._camUp.x, t, 0.015);
      L.upY.setTargetAtTime(this._camUp.y, t, 0.015);
      L.upZ.setTargetAtTime(this._camUp.z, t, 0.015);
    } else if (L.setPosition) {
      L.setPosition(this._camPos.x, this._camPos.y, this._camPos.z);
      L.setOrientation(
        this._camFwd.x, this._camFwd.y, this._camFwd.z,
        this._camUp.x, this._camUp.y, this._camUp.z
      );
    }
  }

  /** Plays a non-spatial 2D sound (player's own viewmodel gunshots, UI clicks, hitmarkers) */
  play2D(soundId, { volume = 1.0, rate = 1.0, detune = 0 } = {}) {
    if (!this.ensureContext() || this.muted) return;
    const buf = this.buffers.get(soundId);
    if (!buf) return;
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    src.playbackRate.value = rate;
    if (detune) src.detune.value = detune;

    const gain = this.ctx.createGain();
    gain.gain.value = volume;
    src.connect(gain);
    gain.connect(this.sfxGain);
    src.start(0);
  }

  /** Plays a true 3D spatialized sound at `worldPos` with distance attenuation & HRTF directional panning */
  playSpatial(soundId, worldPos, { volume = 1.0, rate = 1.0, refDist = 12, maxDist = 260, rolloff = 1.15 } = {}) {
    if (!this.ensureContext() || this.muted) return;
    const buf = this.buffers.get(soundId);
    if (!buf) return;

    // Cull extremely distant quiet sounds to save mobile audio voices
    const distSq = this._camPos.distanceToSquared(worldPos);
    if (distSq > maxDist * maxDist * 1.35) return;

    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    src.playbackRate.value = rate * (0.95 + Math.random() * 0.10);

    const panner = this.ctx.createPanner();
    panner.panningModel = this.useHRTF ? 'HRTF' : 'equalpower';
    panner.distanceModel = 'inverse';
    panner.refDistance = refDist;
    panner.maxDistance = maxDist;
    panner.rolloffFactor = rolloff;
    if (panner.positionX) {
      panner.positionX.value = worldPos.x;
      panner.positionY.value = worldPos.y;
      panner.positionZ.value = worldPos.z;
    } else {
      panner.setPosition(worldPos.x, worldPos.y, worldPos.z);
    }

    const gain = this.ctx.createGain();
    gain.gain.value = volume;

    src.connect(panner);
    panner.connect(gain);
    gain.connect(this.sfxGain);
    src.start(0);
  }

  /** Creates a continuous 3D spatial looping emitter for Tank/APC/Jeep/Helicopter engines */
  createSpatialLoop(soundId, initialPos, { volume = 0.55, refDist = 14, rate = 1.0 } = {}) {
    if (!this.ensureContext()) return null;
    const buf = this.buffers.get(soundId);
    if (!buf) return null;

    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    src.loop = true;
    src.playbackRate.value = rate;

    const panner = this.ctx.createPanner();
    panner.panningModel = 'equalpower';
    panner.distanceModel = 'inverse';
    panner.refDistance = refDist;
    panner.maxDistance = 220;
    panner.rolloffFactor = 1.25;

    const gain = this.ctx.createGain();
    gain.gain.value = volume;

    src.connect(panner);
    panner.connect(gain);
    gain.connect(this.sfxGain);

    const setPos = (p) => {
      if (!p) return;
      if (panner.positionX) {
        panner.positionX.value = p.x;
        panner.positionY.value = p.y;
        panner.positionZ.value = p.z;
      } else {
        panner.setPosition(p.x, p.y, p.z);
      }
    };
    setPos(initialPos);
    src.start(0);

    return {
      update: (pos, speedRatio = 0, volScale = 1) => {
        setPos(pos);
        if (this.ctx) {
          src.playbackRate.setTargetAtTime(rate * (0.85 + Math.min(1.4, speedRatio * 0.55)), this.ctx.currentTime, 0.08);
          gain.gain.setTargetAtTime(volume * volScale, this.ctx.currentTime, 0.08);
        }
      },
      stop: () => {
        try {
          src.stop();
          src.disconnect();
          panner.disconnect();
          gain.disconnect();
        } catch (_) {}
      },
    };
  }

  startMenuMusic() {
    this.wantMenuMusic = true;
    if (!this.ensureContext()) return;
    const buf = this.buffers.get('menu_theme');
    if (!buf || this.menuSource) return;

    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    src.loop = true;
    const fade = this.ctx.createGain();
    fade.gain.setValueAtTime(0.01, this.ctx.currentTime);
    fade.gain.linearRampToValueAtTime(0.95, this.ctx.currentTime + 1.2);

    src.connect(fade);
    fade.connect(this.musicGain);
    src.start(0);
    this.menuSource = { src, fade };
  }

  stopMenuMusic() {
    this.wantMenuMusic = false;
    if (!this.menuSource || !this.ctx) return;
    const { src, fade } = this.menuSource;
    this.menuSource = null;
    try {
      fade.gain.setTargetAtTime(0.0001, this.ctx.currentTime, 0.25);
      setTimeout(() => {
        try { src.stop(); src.disconnect(); } catch (_) {}
      }, 650);
    } catch (_) {}
  }

  startWindAmbience(sandstormLevel = 0.0) {
    this.wantWindAmbience = true;
    if (!this.ensureContext()) return;
    const buf = this.buffers.get('wind_desert');
    if (!buf) return;
    if (!this.windSource) {
      const src = this.ctx.createBufferSource();
      src.buffer = buf;
      src.loop = true;
      const g = this.ctx.createGain();
      g.gain.value = 0.22 + sandstormLevel * 0.48;
      src.connect(g);
      g.connect(this.sfxGain);
      src.start(0);
      this.windSource = src;
      this.windGainNode = g;
    } else if (this.windGainNode) {
      this.windGainNode.gain.setTargetAtTime(0.22 + sandstormLevel * 0.52, this.ctx.currentTime, 0.4);
    }
  }

  stopWindAmbience() {
    this.wantWindAmbience = false;
    if (!this.windSource) return;
    try {
      this.windSource.stop();
      this.windSource.disconnect();
    } catch (_) {}
    this.windSource = null;
    this.windGainNode = null;
  }

  /** Synthesizes crisp tactile UI click & hitmarker ticks with zero latency */
  playUIClick(accent = false) {
    if (!this.ensureContext() || this.muted) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(accent ? 880 : 620, t);
    osc.frequency.exponentialRampToValueAtTime(accent ? 1320 : 320, t + 0.045);
    g.gain.setValueAtTime(0.16, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.05);
    osc.connect(g);
    g.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.055);
  }

  playHitmarker(isHeadshot = false) {
    if (!this.ensureContext() || this.muted) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = isHeadshot ? 'sawtooth' : 'sine';
    osc.frequency.setValueAtTime(isHeadshot ? 1750 : 1180, t);
    osc.frequency.exponentialRampToValueAtTime(isHeadshot ? 920 : 640, t + 0.055);
    g.gain.setValueAtTime(isHeadshot ? 0.28 : 0.18, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.06);
    osc.connect(g);
    g.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.065);
  }

  /** Triggers mobile haptic vibration on explosions, heavy sniper/RPG recoil, and damage */
  vibrate(pattern = 35) {
    if (!this.vibrationEnabled) return;
    if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
      try {
        navigator.vibrate(pattern);
      } catch (_) {}
    }
  }
}
